import json,os,subprocess,time
from pathlib import Path
job=Path(__file__).resolve().parent
data=json.loads((job/'submission.json').read_text())
env={k:v for k,v in os.environ.items() if not k.startswith('FLEET_')}
env['REPO']=data['source']
started=time.time()
p=subprocess.run(data['command'],cwd=data['source'],env=env,stdin=subprocess.DEVNULL)
(job/'exit.json').write_text(json.dumps(dict(returncode=p.returncode,started=started,ended=time.time()))+'\n')
