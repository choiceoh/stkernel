#!/usr/bin/env python3
"""60-minute read-only ready snapshot observer. B/A and optional ABASE; no live tails, HTTP, workload or fleet changes. PREP readiness is configuration proof only."""
import argparse, ast, base64, hashlib, json, os, signal, subprocess, sys, threading, time
from pathlib import Path

SESSION='epdecode76onepass0910v1'
TICKET='17890049831014600'
OWNER_PID='1014600'
OWNER_START_TICK='50737395'
REV='b41d0da24059379d41c079626cc67c3e83cd14e3'
SOURCE='/home/choiceoh/stkernel-ep-tiled-0909-ring'
ROOT=Path('/tmp/glm53-ep76-onepass1-streams')
SNAPSHOT=Path('/tmp/glm53_ep76_snapshot1.py')
SSH=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','choiceoh@srv2','python3 -B -']
COMMON=r'''
def valid_sf6_finalized(receipt):
    expected={'layers':42,'raw_bytes_released':42*72*768*2048,
              'packed_bytes':42*72*768*1552,'storage_bytes_saved':42*72*768*(2048-1552)}
    return (isinstance(receipt,dict) and receipt.get('format')=='sf6_v1'
            and receipt.get('packed_only') is True and not any(k.endswith('error') for k in receipt)
            and all(type(receipt.get(k)) is int and receipt[k]==v for k,v in expected.items()))

def prep_configuration(env, expected):
    # These are the frozen module defaults when a knob is absent, not an
    # assertion that PREP ran. Canonical window proof owns execution evidence.
    defaults={'VLLM_GLM53_PREP_FUSED_KERNEL':'cuda',
              'VLLM_GLM53_PREP_FUSED_SHADOW_EVERY':'1',
              'VLLM_GLM53_PREP_FUSED_SELFCHECK_EVERY':'64'}
    if env.get('VLLM_GLM53_PREP_FUSED') != expected:
        raise RuntimeError('actual PREP mode differs')
    if any(env.get(key, value) != value for key,value in defaults.items()):
        raise RuntimeError('actual PREP backend/check cadence differs')
    return {'mode':expected,'kernel':'cuda','shadow_every':1,'selfcheck_every':64,
            'raw_environment':{key:env.get(key) for key in ('VLLM_GLM53_PREP_FUSED',*defaults)},
            'defaulted':[key for key in defaults if key not in env],
            'scope':'configured values only; canonical onepass proof establishes actual PREP execution'}

def exact_speculation(receipt, expected_k, expected_rank, command_sha):
    import re
    return (isinstance(receipt,dict) and set(receipt)=={'method','num_speculative_tokens','config_sha256','command_sha256','node_rank'}
            and receipt['method']=='dflash' and type(receipt['num_speculative_tokens']) is int
            and receipt['num_speculative_tokens']==expected_k and type(receipt['node_rank']) is int
            and receipt['node_rank']==expected_rank and receipt['command_sha256']==command_sha
            and all(isinstance(receipt[k],str) and re.fullmatch('[0-9a-f]{64}',receipt[k]) is not None
                    for k in ('config_sha256','command_sha256')))

def global_route_canary_contract(receipt, expected_decode_sha256, expected_decode_opt):
    try:
        import ast
        if type(expected_decode_opt) is not bool: return False
        if receipt['source']['source']['tiled_decode']['sha256'] != expected_decode_sha256: return False
        import math
        cases=(('mixed6',6),('balanced12',12),('concentrated24',24),('zeros32',32),
               ('remote33',33),('balanced2128',2128),('balanced4096',4096),
               ('concentrated6912',6912),('balanced8192',8192),
               ('mixed4',4),('balanced8',8),('concentrated16',16))
        if (receipt.get('verdict')!='PASS' or receipt.get('phase')!='complete'
                or receipt.get('actual_weight_owner') is not True or receipt.get('caller_preserved') is not True
                or receipt.get('actual_packed_owner') is not True
                or receipt.get('packed_before')!=receipt.get('packed_after')
                or any(k in receipt for k in ('error','cleanup_error','diagnostic_error'))
                or type(receipt.get('cases')) is not list or len(receipt['cases'])!=len(cases)):return False
        before=receipt.get('packed_before')
        if (not isinstance(before,dict) or before.get('raw_sources_retained') is not True
                or before.get('raw_release_acceptance') is not False
                or not isinstance(before.get('planes'),dict) or set(before['planes'])!={'fc1','fc2'}):return False
        import re
        for name,blocks in (('fc1',512),('fc2',256)):
            plane=before['planes'][name]
            if (not isinstance(plane,dict) or plane.get('shape')!=[72,blocks,1552]
                    or plane.get('dtype')!='torch.uint8' or type(plane.get('data_ptr')) is not int
                    or plane['data_ptr']<=0 or not isinstance(plane.get('sha256'),str)
                    or re.fullmatch('[0-9a-f]{64}',plane['sha256']) is None):return False
        if before['planes']['fc1']['data_ptr']==before['planes']['fc2']['data_ptr']:return False
        def metrics(item,names):
            return (isinstance(item,dict) and type(item.get('bad_rows')) is int and item['bad_rows']==0
                    and all(type(item.get(k)) in (int,float) and math.isfinite(item[k]) and item[k]>=0 for k in names)
                    and not any(k in item for k in ('error','cleanup_error','diagnostic_error')))
        for cell,(name,rows) in zip(receipt['cases'],cases):
            if (not isinstance(cell,dict) or cell.get('case')!=name or type(cell.get('rows')) is not int
                    or cell['rows']!=rows or cell.get('phase')!='complete' or cell.get('verdict')!='PASS'
                    or any(k in cell for k in ('error','cleanup_error','diagnostic_error','first_failure_rows'))):return False
            graph=rows<=33 or rows==8192
            if cell.get('graph_replay') is not graph:return False
            labels=('C1-eager','C2-graph-current' if graph else 'C2-eager','C3-graph-side' if graph else 'C3-side')
            phases=[phase+'-'+label for phase in ('initial','changed') for label in labels]
            candidates=cell.get('candidate');controls=cell.get('controls')
            if type(candidates) is not list or len(candidates)!=6:return False
            if type(controls) is not list or len(controls)!=2 or any(type(x) is not list or len(x)!=3 for x in controls):return False
            if not all(metrics(x,('max_row_relative_l2','max_row_relative_abs','stock_max_row_relative_l2','stock_max_row_relative_abs'))
                       and x.get('phase')==phase for x,phase in zip(candidates,phases)):return False
            if not all(metrics(x,('max_row_relative_l2','max_row_relative_abs')) for group in controls for x in group):return False
        seen=set()
        for cell in receipt['cases']:
            rows=cell['rows']
            if rows>32: continue
            if type(rows) is not int or rows not in (4,6,8,12,16,24,32) or rows in seen: return False
            seen.add(rows)
            expected=('glm53_ep_static_tiled_fp32_v1',rows,256,48,'torch.int32',False,True,
                      (16,128,256) if rows<=8 else (32,64,512),
                      (16,256,128) if rows<=8 else (32,128,128),
                      'nvfp4','sf6_v1','swigluoai_uninterleave',1.,0.,10.,
                      'bf16_scatter' if rows<=8 else 'fp32_scatter')
            if rows<=8: expected+=('glm53_ep_static_sf6_a_ring_v1','glm53_ep_static_sf6_word_unpack_v1','glm53_ep_static_bf16_scatter_v1')
            expected+=('glm53_ep_static_fused_route_v1',288,'torch.int32',0)
            if rows<=8 and expected_decode_opt: expected+=('glm53_ep_static_sf6_fc2_out_of_place_v1',)
            if cell['cache_evidence'].get('decode_opt') is not (rows<=8 and expected_decode_opt):return False
            keys=cell['cache_evidence']['keys']
            if type(keys) is not list or len(keys)!=1 or not isinstance(keys[0],str):return False
            actual=ast.literal_eval(keys[0])
            if type(actual) is not tuple or actual!=expected:return False
        return seen=={4,6,8,12,16,24,32}
    except (KeyError,TypeError,ValueError,SyntaxError,AttributeError): return False

def exact_mm_limit(argv):
    values=[]
    for index,arg in enumerate(argv):
        key,equal,value=arg.partition('=')
        if key!='--limit-mm-per-prompt': continue
        if not equal:
            if index+1>=len(argv): raise RuntimeError('missing multimodal limit value')
            value=argv[index+1]
        values.append(json.loads(value))
    if len(values)!=1 or not isinstance(values[0],dict):
        raise RuntimeError('missing or duplicate multimodal limit')
    value=values[0]
    if set(value)!={'image','video'} or any(type(v) is not int or v<0 for v in value.values()):
        raise RuntimeError('multimodal limits must be exact nonnegative integer image/video fields')
    return value
import math
def valid_startup_trim(receipt,rank,created):
    try:
        if (type(receipt.get('schema')) is not int or receipt['schema']!=1
                or receipt.get('verdict')!='COMPLETE' or type(receipt.get('rank')) is not int
                or receipt['rank']!=rank or receipt.get('measurement_errors')!=[]
                or any(k in receipt for k in ('error','failed_stage'))): return False
        stages=receipt['stages']
        if ([x['stage'] for x in stages]!=['synchronize','gc_collect','empty_cache','malloc_trim']
                or any(x['status']!='COMPLETE' or 'error' in x for x in stages)
                or type(stages[-1]['returned']) is not int or stages[-1]['returned'] not in (0,1)
                or type(stages[1]['collected']) is not int or stages[1]['collected']<0): return False
        for phase in ('before','after'):
            if set(receipt[phase])!={'allocated','reserved','mem_available','vm_rss'}: return False
            if any(type(v) is not int or v<0 for v in receipt[phase].values()): return False
        started,finished=receipt['started_at'],receipt['completed_at']
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in (started,finished)): return False
        return created<=started<=finished<=time.time()
    except (KeyError,TypeError,ValueError,AttributeError): return False

def current_arm_event(session, ticket, owner_pid):
    import datetime, hashlib, json, pathlib, re, stat
    fleet=pathlib.Path('/home/choiceoh/glm53-logs/fleet')
    pending=json.loads((fleet/'pending'/(hashlib.sha256(session.encode()).hexdigest()+'.json')).read_text())
    if pending.get('session')!=session or str(pending.get('ticket'))!=ticket or str(pending.get('pid'))!=str(owner_pid) or str(pending.get('start'))!=owner_start_tick:
        raise RuntimeError('arm reservation identity differs')
    fields=pathlib.Path('/proc/'+str(owner_pid)+'/stat').read_bytes().rsplit(b')',1)[1].split()
    if fields[0]==b'Z' or fields[19].decode('ascii')!=str(pending.get('start')):
        raise RuntimeError('arm supervisor start differs or exited')
    if pending.get('payload_returncode') is not None or pending.get('returncode') is not None:
        raise RuntimeError('arm payload is already terminal')
    holder=(fleet/'holder').read_text().strip().split('|')
    if len(holder)<2 or holder[:2]!=[session,str(owner_pid)]:
        raise RuntimeError('arm is not held by this supervisor')
    path=fleet/'run-logs'/(hashlib.sha256((session+'\0'+ticket).encode()).hexdigest()+'.log')
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size>16*2**20:
        raise RuntimeError('unsafe or oversized canonical run log')
    with path.open('rb') as stream: raw=stream.read(before.st_size)
    after=path.lstat()
    if len(raw)!=before.st_size or (before.st_dev,before.st_ino)!=(after.st_dev,after.st_ino) or after.st_size<before.st_size:
        raise RuntimeError('canonical run log changed identity')
    if raw and not raw.endswith(b'\n'): raw=raw.rsplit(b'\n',1)[0]+b'\n' if b'\n' in raw else b''
    events=list(re.finditer(rb'(?m)^== ([0-9]{2}:[0-9]{2}:[0-9]{2}) (?:arm (?P<regular>[^ :\r\n]+):[^\r\n]*|defaults arm (?P<automatic>[^ \r\n]+) \(baseline sample [0-9]+/[0-9]+ on this build; the verdict needs it\))$',raw))
    expected=['EPDECODE76'+arm for arm in ('B','A','ABASE')]
    names=[(e['regular'] or e['automatic']).decode() for e in events]
    if (not names or names!=expected[:len(names)]
            or any(bool(e['automatic']) != (name=='EPDECODE76ABASE') for e,name in zip(events,names))):
        raise RuntimeError('canonical arm order/type is absent or differs')
    event=events[-1]; hour,minute,second=map(int,event[1].split(b':'))
    now=datetime.datetime.now().astimezone()
    born=now.replace(hour=hour,minute=minute,second=second,microsecond=0)
    if born>now: born-=datetime.timedelta(days=1)
    if (now-born).total_seconds()>3*3600:
        raise RuntimeError('arm event is stale or clock differs')
    marker={'path':str(path),'device':before.st_dev,'inode':before.st_ino,'offset':event.start(),'line':event[0].decode()}
    return dict(arm=names[-1].removeprefix('EPDECODE76'),started_at=born.timestamp(),
                started_at_local=born.isoformat(),key=hashlib.sha256(json.dumps(marker,sort_keys=True).encode()).hexdigest(),**marker)
import hashlib,json,os,pathlib,re,subprocess,time
F=pathlib.Path('/home/choiceoh/glm53-logs/fleet')
def holder_fields():
    try: return (F/'holder').read_text().strip().split('|')
    except FileNotFoundError: return []
def state():
    holder=holder_fields()
    p=F/'pending'/(hashlib.sha256(session.encode()).hexdigest()+'.json')
    try: pending=json.loads(p.read_text())
    except FileNotFoundError: pending={'session':session,'ticket':ticket,'pid':owner_pid,'state':'record_absent','phase':'record_absent','start':owner_start_tick}
    if pending.get('session')!=session or pending.get('ticket')!=ticket or str(pending.get('pid'))!=str(owner_pid) or str(pending.get('start'))!=owner_start_tick: raise RuntimeError('reservation identity changed')
    own=len(holder)>1 and holder[0]==session and holder[1]==str(pending['pid'])
    if own:
        fields=pathlib.Path('/proc/'+str(owner_pid)+'/stat').read_bytes().rsplit(b')',1)[1].split()
        if fields[0]==b'Z' or fields[19].decode('ascii')!=str(pending.get('start')):raise RuntimeError('owned supervisor start differs')
    terminal=pending.get('payload_returncode') is not None or pending.get('returncode') is not None or pending.get('state') in ('finished','succeeded','failed','cancelled','interrupted')
    path=F/'run-logs'/(hashlib.sha256((session+'\0'+ticket).encode()).hexdigest()+'.log')
    lines=path.read_text(errors='replace') if path.exists() else ''
    go=bool(re.search(r'(?m)^GO '+re.escape(session)+r' [0-9]{4}-[0-9]{2}-[0-9]{2}_[0-9]{2}:[0-9]{2}:[0-9]{2}$',lines))
    return {'own':own,'go':go,'terminal':terminal or (go and not own),'phase':pending.get('phase'),'state':pending.get('state'),
            'payload_returncode':pending.get('payload_returncode'),'returncode':pending.get('returncode'),'at':time.time()}
'''
STATUS=r'''
s=state()
if s['own'] and s['go'] and not s['terminal']:
    try:
        arm_event=current_arm_event(session,ticket,owner_pid)
        c=json.loads(subprocess.check_output(['docker','inspect','glm53'],stderr=subprocess.DEVNULL,timeout=10))[0]
        env={}; duplicate=False
        for item in c['Config']['Env']:
            k,v=item.split('=',1); duplicate=duplicate or k in env; env[k]=v
        manifest=pathlib.Path('/home/choiceoh/overlays/glm53/manifest.tsv').read_bytes()
        frozen=pathlib.Path(source+'/build/glm53/manifest.tsv').read_bytes()
        exact=manifest==b'# source_commit='+revision.encode()+b'\n'+frozen
        exact=exact and len([line for line in frozen.splitlines() if line and not line.startswith(b'#')])==71
        exact=exact and subprocess.check_output(['git','-C',source,'rev-parse','HEAD'],timeout=10).decode().strip()==revision
        exact=exact and not subprocess.check_output(['git','-C',source,'status','--porcelain','--untracked-files=no'],timeout=10).strip()
        born=__import__('datetime').datetime.fromisoformat(c['State']['StartedAt'].replace('Z','+00:00')).timestamp()
        created=__import__('datetime').datetime.fromisoformat(c['Created'].replace('Z','+00:00')).timestamp()
        path=pathlib.Path('/home/choiceoh/glm53-logs/glm53.log'); a=path.stat()
        log=''
        if a.st_mtime>=born and a.st_size<=128*2**20: log=path.read_text(errors='replace')
        again=json.loads(subprocess.check_output(['docker','inspect',c['Id']],stderr=subprocess.DEVNULL,timeout=10))[0]
        stable=current_arm_event(session,ticket,owner_pid)['key']==arm_event['key'] and c['Id']==again['Id'] and c['Created']==again['Created'] and c['State']['StartedAt']==again['State']['StartedAt'] and again['State']['Running'] is True
        graph=bool(re.search(r'Graph capturing finished in [0-9]+ secs, took ',log))
        namespace={'__name__':'observer_launch_parser'}
        exec(compile(pathlib.Path(source+'/bench/glm53_launch_metadata.py').read_bytes(),'<frozen-launch-parser>','exec'),namespace)
        topology=namespace['launch_parallelism'](c['Config']['Cmd'])
        payload=namespace['_WRAPPER'].fullmatch(c['Config']['Cmd'][1])[1]
        script=__import__('base64').b64decode(payload,validate=True).decode()
        line=script[len(namespace['_GID_PRELUDE']):].removesuffix('\n')
        argv=namespace['_literal_argv'](line[:-len(namespace['_REDIRECTION'])])
        mm_limit=exact_mm_limit(argv)
        speculation=namespace['launch_speculation'](c['Config']['Cmd'])
        spec_exact=exact_speculation(speculation,5,0,topology['command_sha256'])
        ep_topology_exact=all(topology.get(k)==v for k,v in {'enabled':True,'tensor_parallel_size':4,'nnodes':4,'node_rank':0}.items())
        image_exact=c['Image']=='sha256:a3dd4c0f6cbb053097d65d10cd8ff8f6ae0cb9115cf0ff142e1cafe124c09211'
        pass_receipts=[]
        marker='[ep-tiled-selftest] PASS '
        failmarker=marker.replace('PASS ','FAIL ')
        for line in log.splitlines():
            if marker not in line:continue
            receipt,_=json.JSONDecoder().raw_decode(line.split(marker,1)[1])
            if isinstance(receipt,dict) and receipt.get('verdict')=='PASS' and receipt.get('phase')=='complete':pass_receipts.append(receipt)
        q0_pass=bool(pass_receipts) and failmarker not in log
        if arm_event['arm'] in ('B','A','ABASE'):
            expected_decode=hashlib.sha256(pathlib.Path(source+'/build/glm53/moe_static_ep_tiled.py').read_bytes()).hexdigest()
            q0_pass=q0_pass and len(pass_receipts)==1 and global_route_canary_contract(pass_receipts[0],expected_decode,arm_event['arm']=='A')
        finalized=True
        if arm_event['arm'] in ('B','A','ABASE'):
            finals=[json.JSONDecoder().raw_decode(line.split('[ep-tiled-sf6] FINALIZED ',1)[1])[0] for line in log.splitlines() if '[ep-tiled-sf6] FINALIZED ' in line]
            finalized=len(finals)==1 and valid_sf6_finalized(finals[0]) and not re.search(r'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)',log)
        trim_receipts=[]
        for line in log.splitlines():
            if '[glm53-startup-trim] ' not in line:continue
            receipt,_=json.JSONDecoder().raw_decode(line.split('[glm53-startup-trim] ',1)[1])
            trim_receipts.append(receipt)
        trim_complete=(len(trim_receipts)==1 and valid_startup_trim(trim_receipts[0],0,created))

        prep=prep_configuration(env,'1')
        flags={k:env.get(k) for k in ('VLLM_GLM53_PREP_FUSED','VLLM_GLM53_SPEC_K','VLLM_GLM53_EP_PREFILL_LOCAL','VLLM_B12X_EP_WARM_COMPACT','VLLM_GLM53_SKIP_UNUSED_GRAPH_PROFILE','VLLM_B12X_EP_ZERO_WEIGHT_MICRO','VLLM_GLM53_TP_SF6_Q0','VLLM_GLM53_STARTUP_TRIM','VLLM_GLM53_EP_TILED','VLLM_GLM53_EP_DECODE_OPT','VLLM_GLM53_B12X_STATIC_V2')}
        s['head']={'id':c['Id'],'created_at':c['Created'],'started_at':c['State']['StartedAt'],'running':c['State']['Running'],'stable':stable,
                   'arm_event':arm_event,'born_after_arm':born>=created>=arm_event['started_at'],
                   'flags':flags,'preparation':prep,'speculation':speculation,'speculation_exact':spec_exact,'manifest_exact':exact,'duplicate_env':duplicate,'graph_finished':graph,
                   'canary_pass':q0_pass,'sf6_finalized_marker':finalized,'ep_topology_exact':ep_topology_exact,'image_exact':image_exact,'mm_limit':mm_limit,
                   'startup_trim_complete':trim_complete,
                   'log_inode':a.st_ino,'log_bytes':a.st_size}
    except Exception as exc: s['head_unavailable']=type(exc).__name__+': '+str(exc)
path=pathlib.Path('/tmp/glm53-ep76-onepass-0910-1/onepass.jsonl')
if path.exists():
    st=path.stat()
    if st.st_size<=32*2**20:
        raw=path.read_bytes()
        s['records']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'data':__import__('base64').b64encode(raw).decode()}
print(json.dumps(s))
'''
STREAM=r'''
import base64,selectors,signal
children=[]; sel=selectors.DefaultSelector(); reason='timeout'
def emit(value): print(json.dumps(value),flush=True)
def interrupted(signum,frame): raise InterruptedError('stream interrupted')
signal.signal(signal.SIGTERM,interrupted); signal.signal(signal.SIGINT,interrupted); signal.signal(signal.SIGHUP,interrupted)
try:
    s=state()
    if not(s['own'] and s['go'] and not s['terminal']): raise RuntimeError('owned GO not active')
    for node in ('local','10.10.10.1','10.10.10.3','10.10.10.4'):
        cmd=['tail','-n','0','-F','/home/choiceoh/glm53-logs/glm53.log']
        if node!='local': cmd=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','choiceoh@'+node,'exec tail -n 0 -F /home/choiceoh/glm53-logs/glm53.log']
        p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True); children.append(p)
        for channel,pipe in (('stdout',p.stdout),('stderr',p.stderr)):
            sel.register(pipe,selectors.EVENT_READ,(node,channel))
        emit({'kind':'stream_start','node':node,'pid':p.pid,'at':time.time(),'attribution':'UNASSIGNED: owned reservation window only; logs may precede this arm boot'})
    next_check=0
    while time.time()<deadline and sel.get_map():
        if time.time()>=next_check:
            s=state(); next_check=time.time()+1
            if not s['own'] or s['terminal']:
                reason='release_or_terminal'; break
        for key,_ in sel.select(timeout=.5):
            current_holder=holder_fields()
            if len(current_holder)<2 or current_holder[0]!=session or current_holder[1]!=str(owner_pid):
                reason='release'; raise InterruptedError('reservation released')
            raw=os.read(key.fileobj.fileno(),65536)
            if not raw: sel.unregister(key.fileobj); continue
            node,channel=key.data
            emit({'kind':'chunk','node':node,'channel':channel,'at':time.time(),'data':base64.b64encode(raw).decode()})
    if not sel.get_map(): reason='all_streams_closed'
except BaseException as exc:
    reason=reason if reason!='timeout' else type(exc).__name__
finally:
    for p in children:
        if p.poll() is None:
            try: os.killpg(p.pid,signal.SIGTERM)
            except ProcessLookupError: pass
    for p in children:
        try: p.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try: os.killpg(p.pid,signal.SIGKILL)
            except ProcessLookupError: pass
            p.wait()
    emit({'kind':'stream_end','at':time.time(),'reason':reason})
'''


def remote_code(body,deadline):
    return ('session='+repr(SESSION)+'\nticket='+repr(TICKET)+'\nrevision='+repr(REV)+
            '\nsource='+repr(SOURCE)+'\nowner_pid='+repr(OWNER_PID)+'\nowner_start_tick='+repr(OWNER_START_TICK)+'\ndeadline='+repr(deadline)+'\n'+COMMON+body)


def canonical_record_order(raw, session):
    try:
        rows=[json.loads(line) for line in raw.splitlines() if line.strip()]
        names=[row['name'] for row in rows]
        expected=['EPDECODE76'+arm for arm in ('B','A','ABASE')]
        valid=bool(names) and len(names)<=3 and names==expected[:len(names)] and all(row.get('session')==session for row in rows)
        return {'rows':len(rows),'valid_expected_prefix':valid,'complete_primary_arms':valid and len(rows)>=2,'complete_auto_baseline':valid and len(rows)==3}
    except (ValueError,TypeError,KeyError):
        return {'rows':None,'valid_expected_prefix':False,'complete_primary_arms':False,'complete_auto_baseline':False}

def main():
    args=argparse.ArgumentParser(); args.add_argument('--syntax-check',action='store_true'); options=args.parse_args()
    for body in (STATUS,STREAM): ast.parse(remote_code(body,0))
    if options.syntax_check:
        print('outer + status + stream AST PASS; no remote execution'); return
    if len(REV)!=40 or any(c not in '0123456789abcdef' for c in REV) or not TICKET.isdecimal() or not OWNER_PID.isdecimal() or int(OWNER_PID)<=0 or not OWNER_START_TICK.isdecimal():
        args.error('bind actual ep76-onepass1 revision, ticket, owner PID and start tick before observing')
    os.umask(0o077); ROOT.mkdir(mode=0o700,exist_ok=False)
    (ROOT/'observer.pid').write_text(str(os.getpid())+'\n')
    (ROOT/'README.private.txt').write_text('All stream bytes are UNASSIGNED raw evidence from the owned reservation window. They are not attributed to B/A/ABASE by arrival time. Use strict immutable snapshots and container start/source identities; tail stderr preserves truncation/replacement notices. This observer issues no HTTP/GPU requests.\n')
    events=(ROOT/'events.jsonl').open('x',buffering=1)
    lock=threading.Lock(); stopped=threading.Event(); processes=[]; tasks=[]; deadline=time.time()+60*60
    def event(value):
        with lock: events.write(json.dumps(dict(value,local_at=time.time()))+'\n')
    def stop(signum=None,frame=None): stopped.set()
    signal.signal(signal.SIGTERM,stop); signal.signal(signal.SIGINT,stop)
    def stream_reader(p):
        handles={}
        try:
            for line in p.stdout:
                value=json.loads(line)
                if value['kind']=='chunk':
                    key=(value['node'],value['channel'])
                    if key not in handles: handles[key]=(ROOT/(key[0]+'.'+key[1]+'.raw')).open('xb')
                    raw=base64.b64decode(value.pop('data'),validate=True); handle=handles[key]
                    value.update(offset=handle.tell(),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),attribution='UNASSIGNED')
                    handle.write(raw); handle.flush()
                event(value)
        except Exception as exc: event({'kind':'stream_reader_error','error':type(exc).__name__})
        finally:
            for h in handles.values(): h.close()
    def snapshot(arm, head, phase):
        cmd=[sys.executable,str(SNAPSHOT),'--arm',arm,'--revision',REV,'--session',SESSION,'--suffix',phase+'-'+head['id'][:12], '--capture-phase',phase,
             '--head-id',head['id'],'--head-started-at',head['started_at'],
             '--arm-event-key',head['arm_event']['key']]
        with (ROOT/(arm+'.'+phase+'.snapshot.private.log')).open('xb') as log:
            p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True); processes.append(p)
            try: rc=p.wait(timeout=240)
            except subprocess.TimeoutExpired: os.killpg(p.pid,signal.SIGTERM); rc=p.wait(timeout=10)
        event({'kind':'strict_snapshot_finished','arm':arm,'phase':phase,'returncode':rc,'path':'/tmp/glm53-ep76-onepass1-live-'+arm+'-'+phase+'-'+head['id'][:12]})
    event({'kind':'observer_start','pid':os.getpid(),'session':SESSION,'ticket':TICKET,'revision':REV,'owner_start_tick':OWNER_START_TICK,'deadline':deadline})
    seen_go=False; attempted=set(); old_state=None
    try:
        while not stopped.is_set() and time.time()<deadline:
            try:
                p=subprocess.run(SSH,input=remote_code(STATUS,deadline).encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=40)
                if p.returncode: raise RuntimeError('status unavailable')
                status=json.loads(p.stdout)
            except Exception as exc:
                event({'kind':'status_error','error':type(exc).__name__}); stopped.wait(60); continue
            compact={k:status[k] for k in ('own','go','terminal','phase','state','payload_returncode','returncode')}
            if compact!=old_state: event({'kind':'status','status':{k:v for k,v in status.items() if k!='records'}}); old_state=compact
            records=status.get('records')
            if records:
                path=ROOT/('records-'+records['sha256']+'.jsonl')
                if not path.exists():
                    raw=base64.b64decode(records['data'],validate=True)
                    if len(raw)!=records['bytes'] or hashlib.sha256(raw).hexdigest()!=records['sha256']:raise RuntimeError('record transport differs')
                    path.write_bytes(raw); event({'kind':'canonical_records_prefix','path':str(path),'bytes':len(raw),'sha256':records['sha256'],'arm_order':canonical_record_order(raw,SESSION)})
            if status['terminal'] or(seen_go and not status['own']): event({'kind':'observer_stop','reason':'terminal_or_release'}); break
            if status['own'] and status['go'] and not seen_go:
                seen_go=True
                event({'kind':'owned_go_seen','streams_enabled':False})
            head=status.get('head')
            if seen_go and head and head['manifest_exact'] and head['stable'] and head['running'] and head['born_after_arm'] and not head['duplicate_env']:
                flags=head['flags'];arm=head['arm_event']['arm']
                candidate=arm=='A'
                expected={'VLLM_GLM53_PREP_FUSED':'1','VLLM_GLM53_SPEC_K':'5','VLLM_GLM53_EP_PREFILL_LOCAL':'0','VLLM_B12X_EP_WARM_COMPACT':'0',
                    'VLLM_B12X_EP_ZERO_WEIGHT_MICRO':'0','VLLM_GLM53_SKIP_UNUSED_GRAPH_PROFILE':'1',
                    'VLLM_GLM53_STARTUP_TRIM':'1','VLLM_GLM53_EP_TILED':'1','VLLM_GLM53_EP_DECODE_OPT':'1' if candidate else '0',
                    'VLLM_GLM53_TP_SF6_Q0':'0','VLLM_GLM53_B12X_STATIC_V2':'t,r,sf6'}
                eligible=arm in ('B','A','ABASE') and head['preparation']['mode']==('1') and head['speculation_exact'] and flags==expected and head['ep_topology_exact'] and head['image_exact'] and head['mm_limit']=={'image':4,'video':0}
                ready=head['graph_finished'] and head['startup_trim_complete'] and head['canary_pass'] and head['sf6_finalized_marker']
                phase='ready' if ready else 'prepared'
                key=arm+':'+phase
                if eligible and ready and key not in attempted:
                    attempted.add(key); event({'kind':'strict_snapshot_requested','arm':arm,'phase':phase,'head':head})
                    t=threading.Thread(target=snapshot,args=(arm,head,phase),daemon=True); t.start(); tasks.append(t)
            stopped.wait(60)
    finally:
        stopped.set()
        for p in processes:
            if p.poll() is None:
                try: os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError: pass
        for p in processes:
            try: p.wait(timeout=8)
            except subprocess.TimeoutExpired:
                try: os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                p.wait()
        for task in tasks: task.join(timeout=2)
        event({'kind':'observer_finished','attempted_arms':sorted(attempted),'owned_go_seen':seen_go})
        events.close()


if __name__=='__main__': main()
