"""Preserve initial archive, add observed partial-run scope; do not alter original metrics or helpers."""
import gzip,hashlib,json,re
from pathlib import Path
P=Path;sha=lambda raw:hashlib.sha256(raw).hexdigest()
root=P('/Users/ost/.worktrees/stkernel2/glm53-prefill-moe-pipeline-20260908')
d=root/'measurements/glm53_ep_tiled_20260909/ep76_onepass8'
capture=json.loads(P('/tmp/glm53-ep76-onepass8-completed-private/manifest.json').read_text())
runtime=json.loads(P('/tmp/glm53-ep76-runtime-binding8.json').read_text())
old_manifest=(d/'manifest.json').read_bytes();assert sha(old_manifest)=='ed4f21e5781df7ae2c63e0a771c2dd3aa471245d0d82b57e0a2d98f2f2f25bac'
for n,i in json.loads(old_manifest)['files'].items():assert sha((d/n).read_bytes())==i['stored_sha256']
assert sha(P('/tmp/glm53_collect_ep76_completed8.py').read_bytes())=='be51e3c76eb323b53a4d89f4c3f388850b8be3e3dc530cec3145378becfae733'
assert sha(P('/tmp/glm53_archive_ep76_completed8_local.py').read_bytes())=='8381f47caf4e23efb2f577b0bd1fba7f52e5a2899cc2ac5972c59b9ddec4447f'
c=json.loads((d/'comparison.json').read_text());assert c['canonical_original_order']==['EPDECODE76B'] and set(c['arms'])=={'B'} and c['target76_met'] is None
assert capture['terminal']==dict(phase='finished',returncode=1,payload_returncode=1,owned_holder=False)
row=c['canonical_rows'][0];q=row['requests'][6];diag=q['channel_diagnostics'];assert row['korean']['dirty']==1 and row['korean']['n']==8 and q['question']=='fixed-all' and q['rep']==1
assert diag['first_offending_channel']=='reasoning' and diag['combined_gated_counts']['cjk_mixed']==2 and 'Halvorsen博士' in diag['offenses'][0]['snippet']
stale=capture['files']['boot/boot-EPDECODE76A.log.gz']['original'];assert stale['mtime_ns']/1e9<runtime['started_at']
run=gzip.decompress((d/'fleet/run.log.gz').read_bytes()).decode();assert 'ABORT: pinned GMU=0.6329 exceeds measured memory budget 0.61' in run and 'ABORT: [EPDECODE76A] launcher failed 16:51:43' in run
f=P('/tmp/glm53-ep76-onepass8-launch-failure-private');fm=json.loads((f/'manifest.json').read_text())
assert sha((f/'manifest.json').read_bytes())=='e9d0be4c2d1bb1a4f5ff383504a0cf1353813e3c5175d64d7476e86e9f632487'
def write(n,raw):
 p=d/n;p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as s:s.write(raw)
def js(n,v):write(n,(json.dumps(v,ensure_ascii=False,indent=2,sort_keys=True)+'\n').encode())
for n in ('manifest.json','SHA256SUMS','README.md'):write('utilities/initial-archive/'+n+'.gz',gzip.compress((d/n).read_bytes(),mtime=0))
for n in ('glm53_collect_ep76_completed8.py','glm53_archive_ep76_completed8_local.py','glm53-ep76-audit-ready8.py','glm53-ep76-capture-launch-failure8.py'):
 write('utilities/'+n+'.gz',gzip.compress((P('/tmp')/n).read_bytes(),mtime=0))
write('B-ready/independent-audit.json',P('/tmp/glm53-ep76-onepass8-B-ready-audit.json').read_bytes())
for n,i in fm['files'].items():
 raw=(f/(n+'.gz')).read_bytes();assert sha(raw)==i['stored_sha256'] and sha(gzip.decompress(raw))==i['sha256'];write('launch-failure/copied-logs/'+n+'.gz',raw)
write('launch-failure/original-inventory.json',(f/'manifest.json').read_bytes())
historical=[]
for name in ('ep76_onepass3','ep76_onepass5'):
 p=root/'measurements/glm53_ep_tiled_20260909'/name/'comparison.json';data=json.loads(p.read_text())
 for rr in data.get('canonical_rows',[]):
  for idx,qq in enumerate(rr.get('requests',[])):
   for offense in qq.get('channel_diagnostics',{}).get('offenses',[]):
    if 'Halvorsen博士' in offense.get('snippet',''):historical.append(dict(path=str(p.relative_to(root)),sha256=sha(p.read_bytes()),name=rr.get('name'),request_index=idx,question=qq.get('question'),rep=qq.get('rep'),offense=offense))
js('B-channel-diagnostic.json',dict(scope='Diagnostic only. Original combined-text Korean gate stays failed; repeating a known name does not waive the gate.',canonical_jsonl_sha256=capture['files']['job/onepass.jsonl.gz']['original']['sha256'],request_index=6,question=q['question'],rep=q['rep'],output_sha256=q['output_sha256'],korean=row['korean'],channel_diagnostics=diag,prior_same_literal=historical))
js('partial-execution-scope.json',dict(schema=1,session=runtime['session'],revision=runtime['revision'],ticket=runtime['ticket'],terminal=capture['terminal'],completed_arms=['B'],candidate_measured=False,candidate_ready=False,pair_comparison_available=False,baseline_quality_accepted=False,default_adoption=False,original_comparison_sha256=sha((d/'comparison.json').read_bytes()),comparison_scope='Single-row ordered_request_hashes_equal/required_proofs_equal are vacuous prefix checks, not evidence of a B/A pair.',failure=dict(stage='A launcher memory preflight',observed_abort='pinned GMU=0.6329 exceeds measured memory budget 0.61',observed_node='10.10.10.4',free_gib=94.589225,anon_gib=15.061523,reference_node='10.10.10.3',reference_anon_gib=0.191886,run_log_sha256=capture['files']['fleet/run.log.gz']['original']['sha256'],scope='Pre-launch refusal; no A readiness or canonical row. Failure-handler log copies are not new A container identity.'),stale_optional_boot=dict(path='boot/boot-EPDECODE76A.log.gz',original=stale,run_started_at=runtime['started_at'],scope='Preserved stale file predating this reservation, explicitly excluded from A boot/execution evidence.'),independent_B_audit_sha256=sha(P('/tmp/glm53-ep76-onepass8-B-ready-audit.json').read_bytes())))
old=(d/'README.md').read_text();note='''\nThis run stopped after **B only**: payload/outer rc1. A was refused by memory preflight at16:51:43 before its new container started: srv4 free94.589225GiB, anon15.061523GiB; computed GMU0.61 was below pinned0.6329. There is no A result, A ready proof, or B/A comparison. The preserved optional `boot/boot-EPDECODE76A.log.gz` predates this reservation and is excluded from A evidence. Failure-handler copied logs also do not establish a new A boot.\n\nB pooled fixed decode73.77019897449412tok/s (74.675977/69.474628/77.628319), facts18/18, proof3/3, cold_compile=true. Korean quality failed1/8: fixed-all rep1 reasoning contains `Halvorsen博士` (two CJK characters); content and reasoning_content are empty in that response. Prior occurrences in v3/v5 are linked in `B-channel-diagnostic.json` and do not waive this gate. B ready4rank independently passes; this is not candidate acceptance. Single-row hash-equality fields in the original comparison are vacuous prefix checks, not a matched pair.\n\nInitial generated README/manifest/checksums are retained under `utilities/initial-archive/`; original comparison and canonical rows are unchanged. `partial-execution-scope.json` records these explicit evidence limits.\n'''
head,rest=old.split('\n',1);(d/'README.md').write_text(head+'\n'+note+rest)
js('utilities/partial-supplement-provenance.json',dict(schema=1,script_sha256=sha(P(__file__).read_bytes()),initial_manifest_sha256=sha(old_manifest),scope='Local append of exact failure copies, independent B audit and explicit partial-run interpretation; canonical dictionaries/helpers unchanged.'))
write('utilities/glm53-ep76-archive-partial8-supplement.py.gz',gzip.compress(P(__file__).read_bytes(),mtime=0))
patterns=(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'\bBearer\s+[A-Za-z0-9._~+/-]{12,}',rb'\bhf_[A-Za-z0-9]{20,}\b',rb'\bsk-[A-Za-z0-9_-]{20,}\b')
entries={}
for p in sorted(d.rglob('*')):
 if not p.is_file() or p.relative_to(d).as_posix() in ('manifest.json','SHA256SUMS'):continue
 packed=p.read_bytes();raw=gzip.decompress(packed) if p.suffix=='.gz' else packed;assert not any(re.search(pat,raw) for pat in patterns)
 entries[str(p.relative_to(d))]=dict(stored_bytes=len(packed),stored_sha256=sha(packed),original_bytes=len(raw),original_sha256=sha(raw))
(d/'manifest.json').write_text(json.dumps(dict(schema=1,source_revision=runtime['revision'],scope='Original partial evidence plus diagnostic interpretation; no A result or B/A acceptance',files=entries),sort_keys=True,indent=2)+'\n')
(d/'SHA256SUMS').write_text(''.join(i['stored_sha256']+'  '+n+'\n' for n,i in entries.items())+sha((d/'manifest.json').read_bytes())+'  manifest.json\n')
print(json.dumps(dict(path=str(d),files=len(entries),manifest_sha256=sha((d/'manifest.json').read_bytes()),B_only=True,canonical_rows_unchanged=True)))
