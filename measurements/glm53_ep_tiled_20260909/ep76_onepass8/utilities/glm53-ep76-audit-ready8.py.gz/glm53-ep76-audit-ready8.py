#!/usr/bin/env python3
"""Read only saved v8 rank snapshots; write only a separate compact local audit."""
import argparse, ast, datetime, gzip, hashlib, json, re, stat, subprocess, time
from pathlib import Path
P=argparse.ArgumentParser();P.add_argument('--arm',choices=('B','A','ABASE'),required=True)
P.add_argument('--snapshot',type=Path,required=True);args=P.parse_args()
T=Path('/tmp');ROOT=Path('/Users/ost/.worktrees/stkernel2/glm53-prefill-moe-pipeline-20260908')
REV='407271d9cf73f5db6192a8410c68f152e67301cb'
sha=lambda b:hashlib.sha256(b).hexdigest()
def stable(path):
    a=path.lstat();assert stat.S_ISREG(a.st_mode) and not path.is_symlink()
    raw=path.read_bytes();b=path.lstat()
    assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns)
    return raw
runtime_raw=stable(T/'glm53-ep76-runtime-binding8.json');runtime=json.loads(runtime_raw)
assert runtime['revision']==REV
helper_path=T/'glm53_ep76_snapshot8.py';helper=stable(helper_path)
assert sha(helper)==runtime['helpers'][helper_path.name]
outer=ast.parse(helper);node=next(ast.literal_eval(n.value) for n in outer.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='NODE')
names={'global_route_canary_contract','literal_canary_key','hybrid_rank_contract','canary_source_contract','canary_loader_contract','valid_sf6_finalized','exact_speculation','prep_configuration','exact_mm_limit','valid_startup_trim'}
chosen=[n for n in ast.parse(node).body if isinstance(n,ast.FunctionDef) and n.name in names]
assert {n.name for n in chosen}==names
ns={'time':time,'math':__import__('math'),'json':json};exec(compile(ast.Module(body=chosen,type_ignores=[]),'<saved snapshot pure predicates>','exec'),ns)
cache={}
def frozen(path):
    if path not in cache:cache[path]=subprocess.check_output(['git','-C',str(ROOT),'show',REV+':'+path])
    return cache[path]
manifest=frozen('build/glm53/manifest.tsv');rows=[l.split('\t') for l in manifest.decode().splitlines() if l and not l.startswith('#')]
assert len(rows)==73 and len({r[1] for r in rows})==73
mounts={target:sha(frozen('build/glm53/'+name)) for name,target,_ in rows}
expected_manifest=('# source_commit='+REV+'\n').encode()+manifest
loader_path=next(target for name,target,_ in rows if name=='glm53_ep_hybrid.py')
loader=frozen('build/glm53/glm53_ep_hybrid.py')
pins=next(ast.literal_eval(n.value) for n in ast.parse(loader).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='_RUNTIME_SOURCE_PINS');assert len(pins)==15
identity_raw=stable(args.snapshot/'identity.json');identity=json.loads(identity_raw)
assert identity['arm']==args.arm and identity['label']==args.snapshot.name.split('-live-',1)[1]
assert all(str(identity[k])==str(runtime[k]) for k in ('revision','session','ticket','owner_pid','owner_start_tick','source'))
assert identity['hybrid_loader_path']==loader_path and identity['hybrid_loader_sha256']==mounts[loader_path]
assert identity['hybrid_runtime_pins']==pins
files={}
for name,meta in identity['files'].items():
    assert Path(name).name==name and name.endswith('.gz')
    packed=stable(args.snapshot/name);raw=gzip.decompress(packed)
    assert sha(packed)==meta['stored_sha256'] and len(packed)==meta['stored_bytes']
    assert sha(raw)==meta['original_sha256'] and len(raw)==meta['original_bytes'];files[name]=raw
parser=frozen('bench/glm53_launch_metadata.py');assert sha(parser)==identity['parser_sha256']
assert stable(args.snapshot/'launch-parser.py')==parser
launch={};exec(compile(parser,'<frozen pure launch parser>','exec'),launch)
config_node=next(n for n in ast.walk(outer) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='config')
flag_expr=next(v for k,v in zip(config_node.value.keywords,[q.value for q in config_node.value.keywords]) if k.arg=='flags')
flag_ns={'args':args};expected_flags=eval(compile(ast.Expression(body=flag_expr),'<actual arm flag expectations>','eval'),flag_ns)
assert expected_flags['VLLM_GLM53_EP_HYBRID_TP2']=='1' and expected_flags['VLLM_GLM53_DROP_WEIGHT_CACHE']=='1'
assert expected_flags['VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP']==('1' if args.arm=='A' else '0')
def fixed(c):
    return {k:c[k] for k in ('Id','Created','Image','Config','HostConfig','RestartCount')}|{
        'Mounts':sorted(c['Mounts'],key=lambda m:json.dumps(m,sort_keys=True)),
        'StartedAt':c['State']['StartedAt'],'Pid':c['State']['Pid']}
def unique(items):
    d={}
    for k,v in items:
        assert k not in d;d[k]=v
    return d
def receipts(raw,prefix):
    result=[]
    for line in raw.splitlines():
        if prefix in line:
            r=json.loads(line.split(prefix,1)[1],object_pairs_hook=unique)
            result.append((line,r))
    return result
names=('local','10.10.10.1','10.10.10.3','10.10.10.4');assert set(identity['nodes'])==set(names)
summaries=[]
for rank,name in enumerate(names):
    v=identity['nodes'][name];before=json.loads(files[name+'.inspect.before.json.gz'])[0];after=json.loads(files[name+'.inspect.after.json.gz'])[0]
    assert fixed(before)==fixed(after) and v['running_start_config_stable'] is True
    assert before['Name']==after['Name']==('/glm53' if rank==0 else '/glm53-worker')
    assert before['State']['Running'] is after['State']['Running'] is True
    assert not before['State'].get('Paused') and not before['State'].get('Restarting')
    assert v['id']==before['Id']==after['Id'] and v['started_at']==before['State']['StartedAt']
    assert before['Image']==v['image']==runtime['approved_source']['image']
    assert v['source']==dict(manifest_sha256=sha(expected_manifest),mounts=mounts)
    assert files[name+'.manifest.tsv.gz']==expected_manifest
    actual_mounts=[m for m in before['Mounts'] if m['Destination'] in mounts]
    assert len(actual_mounts)==73 and {m['Destination'] for m in actual_mounts}==set(mounts)
    assert all(m['Type']=='bind' and m['RW'] is False and m['Source'].startswith('/home/choiceoh/overlays/glm53/') for m in actual_mounts)
    env={}
    for item in before['Config']['Env']:
        key,value=item.split('=',1);assert key not in env;env[key]=value
    assert v['flags']==expected_flags and all(env.get(k)==val for k,val in expected_flags.items())
    assert v['preparation']==ns['prep_configuration'](env,'1')
    topology=launch['launch_parallelism'](before['Config']['Cmd']);speculation=launch['launch_speculation'](before['Config']['Cmd'])
    assert topology==v['topology'] and topology['enabled'] is True and topology['node_rank']==rank
    assert topology['tensor_parallel_size']==topology['nnodes']==4
    assert speculation==v['speculation'] and ns['exact_speculation'](speculation,5,rank,topology['command_sha256'])
    payload=launch['_WRAPPER'].fullmatch(before['Config']['Cmd'][1])[1]
    script=__import__('base64').b64decode(payload,validate=True).decode();line=script[len(launch['_GID_PRELUDE']):].removesuffix('\n')
    argv=launch['_literal_argv'](line[:-len(launch['_REDIRECTION'])])
    assert ns['exact_mm_limit'](argv)==v['mm_limit']=={'image':4,'video':0}
    if rank==0:assert v['endpoint']=={'--host':'127.0.0.1','--port':'18000'}
    raw=files[name+'.serving.log.gz'];ready=v['readiness']
    assert ready['hybrid'] is True and ready['q0_dual_warp'] is (args.arm=='A') and ready['candidate'] is (args.arm=='A')
    assert ready['capture_phase']=='ready' and ready['graph_finished'] is True and ready['canary_fail_marker_present'] is False
    assert b'[ep-tiled-selftest]' not in raw and b'[ep-hybrid-selftest] FAIL' not in raw
    assert not re.search(rb'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)',raw)
    assert re.search(rb'Graph capturing finished in [0-9]+ secs, took ',raw)
    assert raw.endswith(b'\n') or not any(x in raw.rsplit(b'\n',1)[-1] for x in (b'[ep-tiled',b'[ep-hybrid',b'[prep-fused]',b'[glm53-startup-trim]'))
    selected=receipts(raw,b'[ep-hybrid-selftest] PASS ');assert len(selected)==1
    line,record=selected[0]
    assert ready['selected_canary_pass_records']==[dict(line_sha256=sha(line),receipt_sha256=sha(json.dumps(record,sort_keys=True,separators=(',',':')).encode()))]
    source_files=dict(mounts);source_files['/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/_moe_dynamic/gated.py']='993783308233288ddfa77293e9dbabdc825ba5bfdcc4dcc41e842a895ec33445'
    assert ns['global_route_canary_contract'](record,sha(frozen('build/glm53/moe_static_ep_tiled.py')),False,expected_hybrid=True,expected_q0_dual_warp=args.arm=='A',expected_rank=rank,source_files=source_files,expected_runtime_pins=pins,expected_loader_path=loader_path)
    born=datetime.datetime.fromisoformat(v['started_at'].replace('Z','+00:00')).timestamp()
    created=datetime.datetime.fromisoformat(v['created_at'].replace('Z','+00:00')).timestamp()
    assert born>=created>=identity['arm_event']['started_at'] and created<=record['started_at']<=record['completed_at']<=v['capture_finished_at']
    finals=receipts(raw,b'[ep-tiled-sf6] FINALIZED ');assert len(finals)==1 and ns['valid_sf6_finalized'](finals[0][1])
    assert ready['ep_sf6_finalized_records']==[dict(line_sha256=sha(finals[0][0]),receipt=finals[0][1])]
    trim=receipts(raw,b'[glm53-startup-trim] ');assert len(trim)==1 and ns['valid_startup_trim'](trim[0][1],rank,created)
    assert ready['startup_trim_records']==[dict(line_sha256=sha(trim[0][0]),receipt=trim[0][1])]
    summaries.append(dict(rank=rank,id=v['id'],started_at=v['started_at'],source_mounts=73,source_sha256=sha(expected_manifest),
        image=v['image'],hybrid=True,q0_dual_warp=args.arm=='A',decode_opt=False,drop_weight_cache='1',spec_k=5,
        canary_cases=len(record['cases']),candidate_checks=sum(len(c['candidate']) for c in record['cases']),
        control_checks=sum(sum(len(g) for g in c['controls']) for c in record['cases']),
        native_key_lengths={str(c['rows']):len(ns['literal_canary_key'](c['cache_evidence']['keys'][0])) for c in record['cases'] if c['rows']<=32},
        dynamic_key_lengths=sorted({len(ns['literal_canary_key'](key)) for c in record['cases'] if c['rows']>32 for key in c['cache_evidence']['keys']}),
        source_entries=len(record['source']['source']),loader_pins=len(record['source']['hybrid_loader_runtime']),
        sf6_finalized_layers=finals[0][1]['layers'],startup_trim_complete=True,
        preparation_failure_marker_present=bool(re.search(rb'\[prep-fused\].*(?:DRIFT|DISARM)',raw)),
        serving_log_sha256=sha(raw),canary_receipt_sha256=sha(json.dumps(record,sort_keys=True,separators=(',',':')).encode())))
assert stable(args.snapshot/'identity.json')==identity_raw and stable(helper_path)==helper
dest=T/('glm53-ep76-onepass8-'+args.arm+'-ready-audit.json');assert not dest.exists()
result=dict(status='PASS',arm=args.arm,snapshot=str(args.snapshot),identity_sha256=sha(identity_raw),runtime_binding_sha256=sha(runtime_raw),
    snapshot_helper_sha256=sha(helper),revision=REV,verified_at=time.time(),ranks=summaries,
    scope='Independent local verification of saved immutable ready prefixes only; no remote/inference/tests.',
    unresolved=['Ready snapshot does not prove completed onepass rows or per-request counters.',
        'Rank-local first-eligible-layer canaries do not independently prove final distributed output sum.',
        'PREP fields here are configuration only; fresh execution/quality/performance remain canonical onepass evidence.',
        'DROP_WEIGHT_CACHE1 proves configuration, not actual reclaimed RAM bytes.',
        'No new live health/current container state is inferred after the saved capture.'])
dest.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(dict(path=str(dest),sha256=sha(dest.read_bytes()),status=result['status'],ranks=summaries,unresolved=result['unresolved']),indent=2))
