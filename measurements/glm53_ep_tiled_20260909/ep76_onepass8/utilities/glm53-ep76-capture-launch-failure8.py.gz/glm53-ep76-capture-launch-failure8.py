import base64,gzip,hashlib,json,pathlib,subprocess
P=pathlib.Path
out=P('/tmp/glm53-ep76-onepass8-launch-failure-private');out.mkdir(exist_ok=False,mode=0o700)
code=r'''
import base64,gzip,hashlib,json,pathlib,stat,time
p=pathlib.Path('/home/choiceoh/glm53-logs/fail-EPDECODE76A-165142')
expected=['glm53.log.10.10.10.1','glm53.log.10.10.10.3','glm53.log.10.10.10.4','glm53.log.srv2']
assert sorted(x.name for x in p.iterdir())==expected
files={}
for n in expected:
 q=p/n;a=q.lstat();assert stat.S_ISREG(a.st_mode) and a.st_size<8*2**20
 raw=q.read_bytes();b=q.lstat();assert (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns)
 files[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mtime_ns':a.st_mtime_ns,'gzip':base64.b64encode(gzip.compress(raw,mtime=0)).decode()}
for n,item in files.items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==item['sha256']
print(json.dumps({'path':str(p),'captured_at':time.time(),'scope':'Failure-handler copied logs. No new A container identity is established by these files; some or all content may originate from the preceding B containers.','files':files}))
'''
r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','choiceoh@srv2','python3 -B -'],input=code.encode(),capture_output=True,timeout=45)
if r.returncode:(out/'failure.private.log').write_bytes(r.stderr);raise RuntimeError('read refused; failure retained')
m=json.loads(r.stdout)
for n,item in m['files'].items():
 packed=base64.b64decode(item.pop('gzip'));raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==item['sha256'] and len(raw)==item['bytes']
 (out/(n+'.gz')).write_bytes(packed);item['stored_sha256']=hashlib.sha256(packed).hexdigest();item['stored_bytes']=len(packed)
(out/'manifest.json').write_text(json.dumps(m,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(out),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'files':len(m['files'])}))
