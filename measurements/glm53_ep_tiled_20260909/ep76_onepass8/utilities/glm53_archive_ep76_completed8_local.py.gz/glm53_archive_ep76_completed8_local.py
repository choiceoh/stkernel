#!/usr/bin/env python3
"""Prepared only: archive terminal EP76 originals; derive metrics without rewriting gates."""
import ast, gzip, hashlib, json, math, os, re, stat
from pathlib import Path

SESSION = 'epdecode76onepass0910v8'
REV = '407271d9cf73f5db6192a8410c68f152e67301cb'
TICKET = '17890258792363139'
OWNER_PID = '2363139'
OWNER_START_TICK = '52827050'
SNAPSHOT_SHA = '538bae042688e19e24074e48e3bdfcd6584a0d36e3c66797f8bb1d7f5e4016a6'
OBSERVER_SHA = '73ab1f32fd85a995b4d4b2022724c51f82448fe7f61550e3da403a32475b5882'
PRIVATE = Path('/tmp/glm53-ep76-onepass8-completed-private')
DEST = Path('/Users/ost/.worktrees/stkernel2/glm53-prefill-moe-pipeline-20260908/measurements/glm53_ep_tiled_20260909/ep76_onepass8')
RUNTIME_BINDING = Path('/tmp/glm53-ep76-runtime-binding8.json')
RUNTIME_BINDING_SHA = 'b561999dbdf8b5fb5808548c7cd899af42ea1cb8c192de47d01d9bba4dcc5b5d'
COLLECTOR_SHA = 'be51e3c76eb323b53a4d89f4c3f388850b8be3e3dc530cec3145378becfae733'
CPU_RESULT_SHA = '134ace613b47afeae8fa7abc8fe5cb3355f68f185b4c84ef3b14a7ac79ab3f18'
CPU_OUTPUT = '/home/choiceoh/glm53-ep76-13-cpu-evidence'
EXPECTED_MOUNT_COUNT = 73
CPU_EXPECTED_TESTS = 239
CPU_EXPECTED_MOUNTED = 23
CPU_EXPECTED_CONTRACTS = 84
IMAGE = 'sha256:a3dd4c0f6cbb053097d65d10cd8ff8f6ae0cb9115cf0ff142e1cafe124c09211'
ARMS = ('B','A','ABASE')
NODES = ('local','10.10.10.1','10.10.10.3','10.10.10.4')
sha = lambda raw: hashlib.sha256(raw).hexdigest()

def need(value, reason):
    if not value: raise ValueError(reason)

def jsonl(raw):
    return [json.loads(line) for line in raw.splitlines() if line.strip()]

def fixed_identity(c):
    return {k:c[k] for k in ('Id','Created','Image','Config','HostConfig','RestartCount')} | {
        'Mounts':sorted(c['Mounts'],key=lambda m:json.dumps(m,sort_keys=True)),
        'StartedAt':c['State']['StartedAt'],'Pid':c['State']['Pid']}

def execution_summary(row, arm):
    """Observe canonical declarations/results; do not recompute judge acceptance."""
    required = {'VLLM_GLM53_EP_TILED','VLLM_GLM53_PREP_FUSED'}
    expected = required | {'VLLM_GLM53_EP_HYBRID_TP2'} | ({'VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP'} if arm=='A' else set())
    declared = row.get('required_proofs'); proof = row.get('proof'); knobs = row.get('knobs')
    declaration_ok = (type(declared) is list and len(declared)==2
                      and all(type(x) is str for x in declared) and set(declared)==required)
    proof_ok = (type(proof) is dict and set(proof)==expected
                and all(x is True for x in proof.values())
                and row.get('proof_ok')==str(len(expected))+'/'+str(len(expected)))
    knob_ok = (type(knobs) is dict and knobs.get('VLLM_GLM53_EP_DECODE_OPT','0')=='0'
               and knobs.get('VLLM_GLM53_EP_HYBRID_TP2')=='1'
               and knobs.get('VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP','0')==('1' if arm=='A' else '0'))
    prep=row.get('preparation'); prep_ok=type(prep) is dict and prep.get('verdict')=='PASS'
    return dict(expected_proof_count=len(expected),required_declaration_matches=declaration_ok,
                canonical_proof_map_matches=proof_ok,declared_hybrid_knob_matches=knob_ok,
                preparation_record_pass=prep_ok,decode_optimization_field_present='decode_optimization' in row,
                declared_execution_contract_pass=declaration_ok and proof_ok and prep_ok and knob_ok,
                scope='Canonical recorded results only; originals and rejection reasons retained. Hybrid execution proof is the original proof map, not a fabricated new metadata field. Ready cannot substitute for execution.')

def main():
    need(all(type(v) is int and v>0 for v in (CPU_EXPECTED_TESTS,CPU_EXPECTED_MOUNTED,CPU_EXPECTED_CONTRACTS,EXPECTED_MOUNT_COUNT)), 'unbound final source/CPU cardinality')
    need(re.fullmatch('[a-f0-9]{40}',REV) and all(x.isdecimal() and int(x)>0 for x in (TICKET,OWNER_PID,OWNER_START_TICK)) and all(re.fullmatch('[a-f0-9]{64}',x) for x in (SNAPSHOT_SHA,OBSERVER_SHA)),'unbound experiment')
    runtime_raw=RUNTIME_BINDING.read_bytes(); need(sha(runtime_raw)==RUNTIME_BINDING_SHA,'reviewed runtime binding differs')
    runtime=json.loads(runtime_raw)
    need(all(runtime.get(k)==v for k,v in dict(session=SESSION,revision=REV,ticket=TICKET,owner_pid=OWNER_PID,owner_start_tick=OWNER_START_TICK).items()),'runtime identity differs')
    manifest_raw=(PRIVATE/'manifest.json').read_bytes(); capture=json.loads(manifest_raw)
    need(capture.get('collector_sha256')==COLLECTOR_SHA,'reviewed terminal collector differs')
    binding=dict(session=SESSION,revision=REV,ticket=TICKET,owner_pid=OWNER_PID,owner_start_tick=OWNER_START_TICK)
    need(all(capture.get(k)==v for k,v in binding.items()),'private capture binding differs')
    need(capture['terminal']['phase']=='finished' and capture['terminal']['owned_holder'] is False,'capture is not released terminal evidence')
    def read(name):
        item=capture['files'][name]; path=PRIVATE/name
        need(not path.is_symlink() and stat.S_ISREG(path.stat().st_mode),'unsafe captured file')
        packed=path.read_bytes(); raw=gzip.decompress(packed)
        need(sha(packed)==item['stored']['sha256'] and len(packed)==item['stored']['bytes'] and sha(raw)==item['original']['sha256'] and len(raw)==item['original']['bytes'],'private capture hash differs')
        return raw
    # Verify all private original hashes, including excluded raw Docker records.
    for name in capture['files']: read(name)
    helper=read('utilities/snapshot.py.gz')
    need(sha(helper)==SNAPSHOT_SHA==capture['snapshot_sha256'],'snapshot verifier source differs')
    need(sha(read('utilities/observer.py.gz'))==OBSERVER_SHA==capture['observer_sha256'],'observer source differs')
    outer=ast.parse(helper)
    node=next(ast.literal_eval(n.value) for n in outer.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='NODE' for t in n.targets))
    names={'global_route_canary_contract','literal_canary_key','hybrid_rank_contract','canary_source_contract','canary_loader_contract','valid_sf6_finalized','exact_speculation','prep_configuration'}
    selected=[n for n in ast.parse(node).body if isinstance(n,ast.FunctionDef) and n.name in names]
    need({n.name for n in selected}==names,'reviewed pure helper functions missing')
    helpers={}; exec(compile(ast.Module(body=selected,type_ignores=[]),'<reviewed pure snapshot contract>','exec'),helpers)
    os.umask(0o022); DEST.mkdir(parents=True,exist_ok=False); provenance={}
    def write(name,raw,origin=None):
        need(not Path(name).is_absolute() and '..' not in Path(name).parts,'unsafe archive path')
        path=DEST/name; path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('xb') as stream: stream.write(raw)
        if origin is not None: provenance[name]=origin
    def write_json(name,obj): write(name,(json.dumps(obj,indent=2,sort_keys=True)+'\n').encode())
    def copy(name,target=None):
        raw=read(name); packed=(PRIVATE/name).read_bytes()
        write(target or name,packed,dict(capture['files'][name],scope='Original bytes; deterministic gzip storage'))
        return raw
    write('utilities/runtime-binding.json',runtime_raw,dict(original_path=str(RUNTIME_BINDING),sha256=RUNTIME_BINDING_SHA,scope='Original local binding record; collection-time utility, not measured source'))
    # Exact canonical row/proof/preparation/quality/request/window dictionaries stay in the original JSONL.
    for name in capture['files']:
        if name.startswith(('job/','source/','boot/','utilities/')) or name in ('fleet/run.log.gz','observer/events.jsonl.gz'):
            copy(name)
    pending_raw=read('fleet/pending.json.gz'); pending=json.loads(pending_raw)
    fields=('session','ticket','pid','start','started_at','payload_finished_at','finished_at','state','phase','payload_returncode','returncode','outcome','recovery_policy','recovery_deferred')
    write_json('terminal.json',dict(scope='Allowlisted terminal fields; raw pending remains private. Release is not public recovery.',original_sha256=sha(pending_raw),**binding,terminal=capture['terminal'],record={k:pending.get(k) for k in fields}))
    cpu_raw=read('job/cpu-result.json.gz'); cpu_binding=json.loads(read('job/cpu-result-binding.json.gz'))
    need(cpu_binding.get('revision')==REV and cpu_binding.get('sha256')==sha(cpu_raw) and cpu_binding.get('source_receipt_exact') is True,'CPU native receipt source/hash binding differs')
    need(sha(cpu_raw)==CPU_RESULT_SHA and cpu_binding.get('cpu_output')==CPU_OUTPUT and cpu_binding.get('cpu_host')=='10.10.10.4','actual fresh CPU origin differs')
    cpu=json.loads(cpu_raw); cpu_contracts_raw=read('job/cpu-contracts.json.gz'); cpu_contracts=json.loads(cpu_contracts_raw)
    cpu_validation=json.loads(read('job/cpu-artifacts-validation.json.gz'))
    need(cpu.get('verdict')=='PASS' and cpu.get('phase')=='complete' and cpu.get('cuda_initialized') is False and cpu.get('binding_runtime_rechecked') is True,'fresh CPU result scope differs')
    need(cpu.get('contracts')==dict(tests_run=CPU_EXPECTED_TESTS,failures=0,errors=0,skips=0),'fresh CPU contracts differ')
    need(len(cpu['mounted_sources'])==CPU_EXPECTED_MOUNTED and len(cpu['contract_sources'])==CPU_EXPECTED_CONTRACTS,'fresh CPU source cardinality differs')
    need({k:len(v) for k,v in cpu.items() if k.endswith('_passes')}==dict(baseline_static_passes=2,baseline_dynamic_passes=1,hybrid_static_passes=4,hybrid_dynamic_passes=1,hybrid_q0_dynamic_passes=1),'fresh hybrid compile groups differ')
    need(cpu.get('fresh_lowerings')==9 and cpu.get('same_source_baseline_lowerings')==3 and cpu.get('hybrid_lowerings')==6 and cpu.get('hybrid_q0_control_lowerings')==1 and cpu.get('hybrid_q0_candidate_lowerings')==1,'fresh lowering accounting differs')
    need(cpu_contracts.get('verdict')=='PASS' and all(cpu_contracts.get(k)==cpu[k] for k in ('contracts','selected_test_counts','binding_runtime','mounted_sources','contract_sources')),'original CPU contracts receipt differs')
    need(cpu_validation.get('source_revision')==REV and cpu_validation.get('result_sha256')==CPU_RESULT_SHA and cpu_validation.get('contracts_sha256')==sha(cpu_contracts_raw) and cpu_validation.get('source_receipt_exact') is True and cpu_validation.get('artifact_hashes_and_resource_logs_verified') is True,'original CPU admission artifact receipt differs')
    manifest_rows=[line.split('\t') for line in read('source/manifest.tsv.gz').decode().splitlines() if line and not line.startswith('#')]
    need(len(manifest_rows)==EXPECTED_MOUNT_COUNT and len({r[1] for r in manifest_rows})==EXPECTED_MOUNT_COUNT,'frozen manifest count/targets differ')
    loader_rows=[r for r in manifest_rows if r[0]=='glm53_ep_hybrid.py']; need(len(loader_rows)==1,'ambiguous hybrid loader mount')
    loader_path=loader_rows[0][1]; loader_raw=read('source/glm53_ep_hybrid.py.gz'); loader_sha=sha(loader_raw)
    pins=[ast.literal_eval(n.value) for n in ast.parse(loader_raw).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_RUNTIME_SOURCE_PINS' for t in n.targets)]
    need(len(pins)==1 and type(pins[0]) is dict and len(pins[0])==15,'frozen loader runtime pins differ'); pins=pins[0]
    decode_sha=sha(read('source/moe_static_ep_tiled.py.gz'))
    selftest_sha=sha(read('source/glm53_ep_tiled_selftest.py.gz'))
    expected_manifest=sha(('# source_commit='+REV+'\n').encode()+read('source/manifest.tsv.gz'))
    terminal_records_raw=read('job/onepass.jsonl.gz') if 'job/onepass.jsonl.gz' in capture['files'] else b''
    snapshot_results=[]; verified={}
    def verify_snapshot(entry,identity,files):
        arm=entry['arm']; kind=entry['capture_kind']; candidate=arm=='A'
        need(all(str(identity.get(k))==v for k,v in binding.items()) and identity.get('arm')==arm,'snapshot binding differs')
        need(set(identity['nodes'])==set(NODES),'four nodes missing')
        head=identity['nodes']['local']
        need(identity.get('label')==arm+'-'+kind+'-'+head['id'][:12],'capture label/container differs')
        need(identity['parser_sha256']==sha(read('source/bench/glm53_launch_metadata.py.gz')),'launch parser source differs')
        need(identity.get('hybrid_loader_path')==loader_path and identity.get('hybrid_loader_sha256')==loader_sha and identity.get('hybrid_runtime_pins')==pins,'snapshot frozen loader provenance differs')
        expected_flags={'VLLM_GLM53_SPEC_K':'5','VLLM_GLM53_PREP_FUSED':'1','VLLM_GLM53_DROP_WEIGHT_CACHE':'1',
            'VLLM_GLM53_EP_PREFILL_LOCAL':'0','VLLM_B12X_EP_WARM_COMPACT':'0','VLLM_B12X_EP_ZERO_WEIGHT_MICRO':'0',
            'VLLM_GLM53_TP_SF6_Q0':'0','VLLM_GLM53_EP_TILED':'1',
            'VLLM_GLM53_EP_DECODE_OPT':'0','VLLM_GLM53_EP_HYBRID_TP2':'1','VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP':'1' if candidate else '0',
            'VLLM_GLM53_B12X_STATIC_V2':'t,r,sf6','VLLM_GLM53_STARTUP_TRIM':'1','VLLM_GLM53_SKIP_UNUSED_GRAPH_PROFILE':'1'}
        for rank,node_name in enumerate(NODES):
            value=identity['nodes'][node_name]; topology=value['topology']; ready=value['readiness']
            before=json.loads(files[node_name+'.inspect.before.json.gz'])[0]
            after=json.loads(files[node_name+'.inspect.after.json.gz'])[0]
            need(fixed_identity(before)==fixed_identity(after),'full fixed Docker identity differs')
            need(before['State']['Running'] is True and after['State']['Running'] is True and before['Id']==value['id'] and before['State']['StartedAt']==value['started_at'],'container identity differs')
            need(value['image']==before['Image']==IMAGE and value['running_start_config_stable'] is True,'image/start stability differs')
            need(value['flags']==expected_flags and topology['enabled'] is True and topology['tensor_parallel_size']==topology['nnodes']==4 and type(topology['node_rank']) is int and topology['node_rank']==rank,'arm flags/topology differs')
            need(helpers['exact_speculation'](value['speculation'],5,rank,topology['command_sha256']),'actual speculation differs')
            env={}
            for item in before['Config']['Env']:
                key,val=item.split('=',1); need(key not in env,'duplicate environment'); env[key]=val
            need(all(env.get(k)==v for k,v in expected_flags.items()),'actual arm environment differs')
            need(value['preparation']==helpers['prep_configuration'](env,'1'),'actual preparation configuration differs')
            need(value['source']['manifest_sha256']==expected_manifest and len(value['source']['mounts'])==EXPECTED_MOUNT_COUNT and value['mm_limit']=={'image':4,'video':0},'mounted source/MM identity differs')
            need(ready.get('hybrid') is True and ready.get('q0_dual_warp') is candidate and ready['capture_phase']=='ready' and ready['graph_finished'] is True and ready['canary_fail_marker_present'] is False and ready['selected_canary_pass_records'],'ready evidence missing')
            if rank==0: need(value['endpoint']=={'--host':'127.0.0.1','--port':'18000'},'head endpoint differs')
            if arm in ARMS:
                raw=files[node_name+'.serving.log.gz']; marker=b'[ep-hybrid-selftest] PASS '
                other=b'[ep-tiled-selftest]'
                need(other not in raw and b'[ep-tiled-selftest] FAIL' not in raw and b'[ep-hybrid-selftest] FAIL' not in raw,'mixed geometry or failed canary marker')
                need(raw.endswith(b'\n') or not any(m in raw.rsplit(b'\n',1)[-1] for m in (b'[ep-tiled',b'[ep-hybrid',b'[prep-fused]',b'[glm53-startup-trim]')),'partial critical marker')
                lines=[line for line in raw.splitlines() if marker in line]
                need(len(lines)==1 and b'[ep-tiled-selftest] FAIL ' not in raw and not re.search(rb'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)',raw),'candidate marker ambiguity/failure')
                text=lines[0].split(marker,1)[1].decode(); receipt,end=json.JSONDecoder().raw_decode(text)
                source_files=dict(value['source']['mounts'])
                source_files['/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/_moe_dynamic/gated.py']='993783308233288ddfa77293e9dbabdc825ba5bfdcc4dcc41e842a895ec33445'
                need(source_files.get(loader_path)==loader_sha,'mounted loader helper differs')
                need(helpers['global_route_canary_contract'](receipt,decode_sha,False,expected_hybrid=True,expected_q0_dual_warp=candidate,expected_rank=rank,source_files=source_files,expected_runtime_pins=pins,expected_loader_path=loader_path),'global-route numerical/key/source/rank contract differs')
                need(receipt['source']['source']['tiled_selftest']['sha256']==selftest_sha,'selftest source differs')
                final=ready['ep_sf6_finalized_records']; need(len(final)==1 and helpers['valid_sf6_finalized'](final[0]['receipt']),'SF6 final release differs')
                target=arm+'-canary/'+node_name+'.PASS.json.gz'
                write(target,gzip.compress(text[:end].encode(),mtime=0),dict(log_original_sha256=sha(raw),marker_line_sha256=sha(lines[0]),capture_kind=kind,scope='Exact original JSON substring; first eligible layer only'))
        return dict(ready_four_rank_verified=True,completed_row_bound=False,configuration_only_prep=True,candidate_checks_per_rank=72,control_checks_per_rank=72,key_lengths={str(r):26 if r<=8 else 23 for r in (4,6,8,12,16,24,32)})
    for entry in capture['snapshots']:
        result={k:entry.get(k) for k in ('index','arm','phase','capture_kind','event_source','returncode','directory_missing')}; snapshot_results.append(result)
        prefix=entry['private_prefix']; originals={name.removeprefix(prefix+'/'):item for name,item in capture['files'].items() if name.startswith(prefix+'/')}
        write_json('snapshot-'+str(entry['index'])+'/private-original-hashes.json',dict(scope='Hashes only; raw Docker Env/Cmd/inspect and failure logs remain private',files=originals))
        # Preserve boot-bound log prefixes even if a later contract check rejects the snapshot.
        for name in originals:
            if name.endswith(('.serving.log.gz.gz','.docker.log.gz.gz','.manifest.tsv.gz.gz')):
                packed=read(prefix+'/'+name)
                write('snapshot-'+str(entry['index'])+'/'+name.removesuffix('.gz'),packed,dict(original_path=originals[name]['path'],stored_sha256=sha(packed)))
        if entry.get('returncode')!=0 or entry.get('phase')!='ready': result['validation']='NOT_READY_OR_CAPTURE_FAILED'; continue
        try:
            raw=read(prefix+'/identity.json.gz'); identity=json.loads(raw); files={}
            for name,item in identity['files'].items():
                packed=read(prefix+'/'+name+'.gz'); original=gzip.decompress(packed)
                need(sha(packed)==item['stored_sha256'] and sha(original)==item['original_sha256'] and len(packed)==item['stored_bytes'] and len(original)==item['original_bytes'],'snapshot original hash differs')
                files[name]=original
            key=(entry['arm'],entry['capture_kind']); need(key not in verified,'duplicate same-kind snapshot')
            detail=verify_snapshot(entry,identity,files)
            safe={k:identity[k] for k in ('schema','arm','revision','source','session','ticket','owner_pid','owner_start_tick','captured_at','parser_sha256','arm_event')}
            safe.update(hybrid_loader_path=identity['hybrid_loader_path'],hybrid_loader_sha256=identity['hybrid_loader_sha256'],hybrid_runtime_pins=identity['hybrid_runtime_pins'],scope='Allowlisted strict snapshot; ready prefixes are not completed worker counters. PREP execution requires canonical proof; no performance acceptance.',capture_kind=entry['capture_kind'],original_identity_sha256=sha(raw),nodes={})
            for node,value in identity['nodes'].items():
                safe['nodes'][node]={k:value[k] for k in ('id','created_at','started_at','image','capture_started_at','capture_finished_at','running_start_config_stable','topology','endpoint','mm_limit','flags','source','readiness','environment_sha256','log_source','speculation')}
                safe['nodes'][node]['preparation']={k:value['preparation'][k] for k in ('mode','kernel','shadow_every','selfcheck_every','defaulted','scope')}
            write_json(entry['arm']+'-'+entry['capture_kind']+'/identity.sanitized.json',safe)
            verified[key]=identity; result.update(validation='PASS',**detail)
        except (KeyError,ValueError,TypeError,IndexError,StopIteration) as exc:
            result.update(validation='REJECTED',reason_type=type(exc).__name__,reason=str(exc)[:120])
    write_json('snapshot-validation.json',dict(scope='Ready collection validation only; missing/rejected snapshots do not become PASS. No completed watcher or final worker counters are synthesized.',results=snapshot_results,missing_ready_arms=[arm for arm in ARMS if (arm,'ready') not in verified]))
    records_raw=terminal_records_raw
    rows=[]; record_error=None
    try: rows=jsonl(records_raw)
    except (ValueError,UnicodeError): record_error='canonical JSONL parse rejected; original retained'
    names=[row.get('name') if isinstance(row,dict) else None for row in rows]
    valid_prefix=bool(rows) and len(rows)<=3 and names==['EPDECODE76'+a for a in ARMS[:len(rows)]] and all(isinstance(row,dict) and row.get('session')==SESSION and row.get('git') in (REV,REV[:8]) for row in rows)
    comparison=dict(schema=1,**binding,objective='Fresh EP2TP2 E144/I1024 on B/A/ABASE; A alone Q0 dual-warp prefill. Native decode OPT0/K5/PREP1 unchanged. Canonical fixed1024 x3 retains absolute target >=76; prior78.93 is descriptive, not a fabricated noninferiority gate.',
        performance_acceptance=False,default_adoption=False,canonical_completed_prefix_valid=valid_prefix,record_error=record_error,
        canonical_original_order=names,canonical_rows=rows,canonical_verdicts=None,arms={},target76_met=None,
        scope='Original dictionaries preserved, including required_proofs, proof, preparation, decode_optimization, speculation, quality, channel diagnostics, hashes and all timing windows. Derived metrics are descriptive; no gate is rerun or rewritten.')
    if 'job/verdicts.jsonl.gz' in capture['files']:
        try: comparison['canonical_verdicts']=jsonl(read('job/verdicts.jsonl.gz'))
        except (ValueError,UnicodeError): comparison['verdict_parse_error']='original preserved'
    if valid_prefix:
        for index,row in enumerate(rows):
            arm=ARMS[index]; fixed=[q for q in row.get('requests',[]) if q.get('question')=='fixed-all' and q.get('min_tokens')==q.get('max_tokens')==1024]
            complete=len(fixed)==3 and all(q.get('completion_tokens')==1024 and type(q.get('decode_s')) in (int,float) and math.isfinite(q['decode_s']) and q['decode_s']>0 for q in fixed)
            item=dict(record_index=index,role='primary baseline' if arm=='B' else 'primary candidate' if arm=='A' else 'automatic baseline supplement',expected_spec_k=5,expected_prep_mode='1',fixed_three_complete=complete,pooled_decode_tok_s=None,fixed_request_decode_tok_s=None)
            item['execution_evidence']=execution_summary(row,arm)
            item['cold_compile_present']='cold_compile' in row
            item['cold_compile_original']=row.get('cold_compile')
            if complete:
                item.update(pooled_decode_tok_s=sum(q['completion_tokens']-1 for q in fixed)/sum(q['decode_s'] for q in fixed),fixed_request_decode_tok_s=[(q['completion_tokens']-1)/q['decode_s'] for q in fixed],formula='sum(completion_tokens-1)/sum(decode_s)',fixed_decode_tokens_excluding_first=3069)
            comparison['arms'][arm]=item
        comparison['ordered_request_hashes_equal']=all([q.get('request_sha256') for q in r.get('requests',[])]==[q.get('request_sha256') for q in rows[0].get('requests',[])] for r in rows[1:])
        comparison['required_proofs_equal']=all(r.get('required_proofs',[])==rows[0].get('required_proofs',[]) for r in rows[1:])
        a=comparison['arms'].get('A',{}).get('pooled_decode_tok_s'); b=comparison['arms'].get('B',{}).get('pooled_decode_tok_s')
        if a is not None: comparison['target76_met']=a>=76
        if a is not None and b is not None: comparison['A_vs_B_decode_pct']=(a/b-1)*100
    write_json('comparison.json',comparison)
    readme=f'''# EP76 onepass 8 — terminal evidence

Frozen `{REV}`, session `{SESSION}`. B and A are EP2TP2 E144/I1024, OPT0, SF6, DFlash K5 and PREP on. Only A sets `VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP=1`; B and optional normal ABASE explicitly retain0. Actual nondefault baseline knobs contain HYBRID1 only because the new flag's profile default is0. Both arms keep the same native decode path and explicitly set the merged profile default `VLLM_GLM53_DROP_WEIGHT_CACHE=1`; every rank's actual environment must match. This flag is omitted from scoped baseline knobs because it equals the profile default. A release marker does not prove reclaimed bytes. Prior v6 EP4/EP2TP2 results are separate.

Canonical completed names `{names}`, valid prefix `{valid_prefix}`, terminal rc `{capture['terminal']['returncode']}`, payload rc `{capture['terminal']['payload_returncode']}`. Original failed/partial rows, cold flags, quality/Korean/channel diagnostics, request/output hashes, proof declarations and canonical verdicts are preserved. Missing evidence is never reconstructed. The shared required EP/PREP declaration remains identical; B expects3/3 EP/PREP/HYBRID, A4/4 with the dedicated Q0 proof. Ready snapshots establish startup/configuration only; actual serving Q0 and fresh PREP evidence belong to canonical records.

Fixed decode remains `sum(completion_tokens-1)/sum(decode_s)` for three complete1024-token requests (numerator3069). A>=76 `{comparison['target76_met']}` is descriptive here; this archive grants no adoption or statistical improvement. Repeated2K versus single32K/128K and cold-baseline limitations remain unchanged. Previous78.93 is not silently converted into a noninferiority gate. Engine/speculative/PREP windows are not relabeled fixed-request counters.

Fresh CPU result/original contracts/artifact admission bind `{CPU_EXPECTED_TESTS}` tests, `{CPU_EXPECTED_MOUNTED}` mounted sources, `{CPU_EXPECTED_CONTRACTS}` contracts and9 new lowerings: EP4 baseline3, EP2TP2 baseline5, Q0 dual-warp dynamic1. Actual selected geometry/key/resource receipt is required; historical CPU11 cannot substitute. Raw resource facts and estimate-versus-actual limitations remain original. This compile evidence does not prove distributed loader numerics or performance.

Four-rank ready snapshots require schema2, source14, loader identity13, mounted loader helper and15 exact image runtime pins in both arms. Native global low4/6/8 keys26 and high12/16/24/32 keys23 are unchanged; dynamic B21/A22 requires the exact selected suffix and top q0_dual_warp bool. Twelve cases retain72candidate+72stock comparisons per rank. FINALIZED42 remains independent raw-owner release proof. Rank-local canary is not distributed collective verification. No worker final counters are synthesized.

Original JSONL/source/CPU/head boot/run logs/events and available ready snapshots have stored/original hashes. Raw Env/Cmd/inspect/failure logs remain private; durable output keeps allowlisted fields and original hashes. Release is not public recovery verification. Collection helpers are distinct from measured source. Run only after terminal and observer closure: `python3 /tmp/glm53_collect_ep76_completed8.py`, then `python3 /tmp/glm53_archive_ep76_completed8_local.py`.
'''
    write('README.md',readme.encode())
    write_json('provenance.json',dict(schema=1,**binding,runtime_binding_sha256=RUNTIME_BINDING_SHA,cpu_result_sha256=CPU_RESULT_SHA,remote_capture_manifest_sha256=sha(manifest_raw),collector_sha256=capture['collector_sha256'],archive_script_sha256=sha(Path(__file__).read_bytes()),snapshot_sha256=SNAPSHOT_SHA,files=provenance))
    # No raw Docker objects are selected above; this additional scan is a bounded heuristic.
    patterns=(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',rb'\bBearer\s+[A-Za-z0-9._~+/-]{12,}',rb'\bhf_[A-Za-z0-9]{20,}\b',rb'\bsk-[A-Za-z0-9_-]{20,}\b')
    entries={}
    for path in sorted(DEST.rglob('*')):
        if not path.is_file(): continue
        packed=path.read_bytes(); raw=gzip.decompress(packed) if path.suffix=='.gz' else packed
        need(not any(re.search(pattern,raw) for pattern in patterns),'potential credential; private review required')
        entries[str(path.relative_to(DEST))]=dict(stored_bytes=len(packed),stored_sha256=sha(packed),original_bytes=len(raw),original_sha256=sha(raw))
    write_json('manifest.json',dict(schema=1,source_revision=REV,scope='Original evidence plus descriptive derivation; no adoption or performance acceptance',files=entries))
    write('SHA256SUMS',(''.join(item['stored_sha256']+'  '+name+'\n' for name,item in entries.items())+sha((DEST/'manifest.json').read_bytes())+'  manifest.json\n').encode())
    print(json.dumps(dict(destination=str(DEST),verified_files=len(entries),manifest_sha256=sha((DEST/'manifest.json').read_bytes()),completed_prefix_valid=valid_prefix,target76_met=comparison['target76_met'],performance_acceptance=False)))

if __name__ == '__main__': main()
