#!/usr/bin/env python3
"""Prepared only: read terminal EP76 evidence over SSH into an immutable private copy."""
import ast, base64, gzip, hashlib, json, os, re, stat, subprocess
from pathlib import Path

SESSION = 'epdecode76onepass0910v8'
REV = '407271d9cf73f5db6192a8410c68f152e67301cb'
TICKET = '17890258792363139'
OWNER_PID = '2363139'
OWNER_START_TICK = '52827050'
SNAPSHOT_SHA = '538bae042688e19e24074e48e3bdfcd6584a0d36e3c66797f8bb1d7f5e4016a6'
OBSERVER_SHA = '73ab1f32fd85a995b4d4b2022724c51f82448fe7f61550e3da403a32475b5882'
DEST = Path('/tmp/glm53-ep76-onepass8-completed-private')
STREAMS = Path('/tmp/glm53-ep76-onepass8-streams')
OBSERVER = Path('/tmp/glm53_ep76_observer8.py')
SNAPSHOT = Path('/tmp/glm53_ep76_snapshot8.py')
SOURCE = '/home/choiceoh/stkernel-ep-tiled-0909-ring'
JOB = '/tmp/glm53-ep76-onepass-0910-8'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
REMOTE = r'''
import base64,gzip,hashlib,json,pathlib,stat,subprocess,time
P=pathlib.Path
sha=lambda raw:hashlib.sha256(raw).hexdigest()
fleet=P('/home/choiceoh/glm53-logs/fleet')
source=P(source_path)
job=P(job_path)
started=time.time()
def read(path):
 a=path.lstat()
 if not stat.S_ISREG(a.st_mode) or a.st_size>128*2**20:raise RuntimeError('unsafe/oversized evidence')
 raw=path.read_bytes(); b=path.lstat()
 if (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)!=(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns) or len(raw)!=a.st_size:raise RuntimeError('evidence changed while read')
 return raw,dict(bytes=len(raw),sha256=sha(raw),device=a.st_dev,inode=a.st_ino,mtime_ns=a.st_mtime_ns)
def source_check():
 if subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD']).decode().strip()!=revision:raise RuntimeError('frozen source differs')
 if subprocess.check_output(['git','-C',str(source),'status','--porcelain','--untracked-files=no']).strip():raise RuntimeError('frozen source dirty')
def released():
 holder=(fleet/'holder').read_text().strip().split('|') if (fleet/'holder').exists() else []
 if holder and (holder[0]==session or len(holder)>1 and holder[1]==owner_pid):raise RuntimeError('owned holder still active')
source_check(); released()
pending=fleet/'pending'/(sha(session.encode())+'.json')
pending_raw,pending_meta=read(pending); record=json.loads(pending_raw)
if (record.get('session')!=session or str(record.get('ticket'))!=ticket or str(record.get('pid'))!=owner_pid
 or str(record.get('start'))!=owner_start_tick or record.get('phase')!='finished'
 or type(record.get('returncode')) is not int or not 0<=record['returncode']<=255
 or record.get('payload_returncode') is not None and (type(record['payload_returncode']) is not int or not 0<=record['payload_returncode']<=255)):
 raise RuntimeError('terminal identity/status differs')
paths={'job/submission.json':job/'submission.json',
 'job/cpu-contracts.json':job/'cpu-contracts.json','job/cpu-artifacts-validation.json':job/'cpu-artifacts-validation.json',
 'job/cpu-result.json':job/'cpu-result.json','job/cpu-result-binding.json':job/'cpu-result-binding.json','fleet/pending.json':pending,
 'fleet/run.log':fleet/'run-logs'/(sha((session+'\0'+ticket).encode())+'.log'),
 'source/manifest.tsv':source/'build/glm53/manifest.tsv'}
for name in ('glm53_ep_tiled_selftest.py','moe_static_ep_tiled.py','moe_dynamic_ep_local.py','glm53_ep_tiled.py','glm53_prep_fused.py','deneb_boot_stamps.py','glm53_fp8_dense.py','glm53_ep_shard_geometry.py','glm53_ep_hybrid.py','glm53_ep_route_remap.py','moe_dispatch.py','flashinfer_b12x_moe.py','glm5next_model.py'):
 paths['source/'+name]=source/'build/glm53'/name
for name in ('glm53_launch_metadata.py','glm53_prep_proof.py','onepass.py','proof.py','judge.py','baseline.py','chain.sh','ab-lever.sh'):
 paths['source/bench/'+name]=source/'bench'/name
optional={**{'job/'+name:job/name for name in ('onepass.jsonl','verdicts.jsonl','pre-cancel-records.jsonl','cancel-request.json')},
 **{'boot/boot-EPDECODE76'+arm+'.log':P('/home/choiceoh/glm53-logs')/('boot-EPDECODE76'+arm+'.log') for arm in ('B','A','ABASE')}}
missing=[]
for name,path in optional.items():
 try:path.lstat()
 except FileNotFoundError:missing.append(name)
 else:paths[name]=path
files={}; total=0
for name,path in paths.items():
 raw,meta=read(path); total+=len(raw)
 if total>128*2**20:raise RuntimeError('evidence total bound')
 files[name]=dict(path=str(path),original=meta,gzip=base64.b64encode(gzip.compress(raw,mtime=0)).decode())
for name,path in paths.items():
 if read(path)[1]!=files[name]['original']:raise RuntimeError('evidence changed before transfer')
if files['fleet/pending.json']['original']!=pending_meta:raise RuntimeError('terminal changed during capture')
source_check(); released()
print(json.dumps(dict(schema=1,session=session,ticket=ticket,revision=revision,owner_pid=owner_pid,owner_start_tick=owner_start_tick,
 read_started=started,read_finished=time.time(),missing_optional=missing,
 terminal=dict(phase=record['phase'],returncode=record['returncode'],payload_returncode=record.get('payload_returncode'),owned_holder=False),files=files)))
'''

def stable(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size > 128 * 2**20:
        raise RuntimeError('unsafe local evidence')
    raw = path.read_bytes(); after = path.lstat()
    if (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns):
        raise RuntimeError('local evidence changed')
    return raw

def assignments(raw):
    out = {}
    for node in ast.parse(raw).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try: out[node.targets[0].id] = ast.literal_eval(node.value)
            except (ValueError, TypeError): pass
    return out

def main():
    if 'TO_BIND' in SOURCE or not re.fullmatch('[a-f0-9]{40}', REV) or not all(x.isdecimal() and int(x)>0 for x in (TICKET, OWNER_PID, OWNER_START_TICK)) or not all(re.fullmatch('[a-f0-9]{64}', x) for x in (SNAPSHOT_SHA, OBSERVER_SHA)):
        raise RuntimeError('bind exact revision/ticket/PID/start tick and reviewed bound snapshot SHA before collection')
    helper_raw = stable(SNAPSHOT); observer_raw = stable(OBSERVER)
    if sha(helper_raw) != SNAPSHOT_SHA or sha(observer_raw) != OBSERVER_SHA: raise RuntimeError('reviewed snapshot/observer helper differs')
    for raw in (helper_raw, observer_raw):
        cfg = assignments(raw)
        if any(cfg.get(k) != v for k,v in dict(REV=REV,TICKET=TICKET,OWNER_PID=OWNER_PID,OWNER_START_TICK=OWNER_START_TICK,SOURCE=SOURCE,JOB=JOB,SESSION=SESSION).items()):
            raise RuntimeError('helper experiment binding differs')
    events_raw = stable(STREAMS/'events.jsonl')
    events = [json.loads(line) for line in events_raw.splitlines()]
    if not events or events[-1].get('kind') != 'observer_finished': raise RuntimeError('wait for observer closure before collection')
    starts = [e for e in events if e.get('kind') == 'observer_start']
    if len(starts) != 1 or any(str(starts[0].get(k)) != v for k,v in dict(session=SESSION,ticket=TICKET,revision=REV,owner_start_tick=OWNER_START_TICK).items()):
        raise RuntimeError('observer experiment binding differs')
    os.umask(0o077); DEST.mkdir(mode=0o700, exist_ok=False)
    code = '\n'.join(k+'='+repr(v) for k,v in dict(session=SESSION,ticket=TICKET,revision=REV,owner_pid=OWNER_PID,owner_start_tick=OWNER_START_TICK,source_path=SOURCE,job_path=JOB).items())+'\n'+REMOTE
    result = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','choiceoh@srv2','python3 -B -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=100)
    if result.returncode:
        (DEST/'capture-failure.private.log').write_bytes(result.stderr)
        raise RuntimeError('terminal capture refused; private failure preserved')
    obj=json.loads(result.stdout); manifest={k:v for k,v in obj.items() if k!='files'}; manifest['files']={}; saved_bytes=0
    def save(name,raw,origin,packed=None,original_meta=None):
        nonlocal saved_bytes
        saved_bytes+=len(raw)
        if saved_bytes>512*2**20: raise RuntimeError('private capture total bound')
        if Path(name).is_absolute() or '..' in Path(name).parts: raise RuntimeError('unsafe relative name')
        packed=gzip.compress(raw,mtime=0) if packed is None else packed
        path=DEST/(name+'.gz'); path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
        with path.open('xb') as stream: stream.write(packed)
        manifest['files'][name+'.gz']=dict(path=origin,original=original_meta or dict(bytes=len(raw),sha256=sha(raw)),stored=dict(bytes=len(packed),sha256=sha(packed)))
    for name,item in obj['files'].items():
        packed=base64.b64decode(item['gzip'],validate=True); raw=gzip.decompress(packed)
        if sha(raw)!=item['original']['sha256'] or len(raw)!=item['original']['bytes']: raise RuntimeError('remote transport mismatch')
        save(name,raw,item['path'],packed,item['original'])
    save('observer/events.jsonl',events_raw,str(STREAMS/'events.jsonl'))
    save('utilities/snapshot.py',helper_raw,str(SNAPSHOT)); save('utilities/observer.py',observer_raw,str(OBSERVER))
    manifest['snapshot_sha256']=SNAPSHOT_SHA; manifest['observer_sha256']=OBSERVER_SHA; manifest['snapshots']=[]
    candidates=[dict(e,capture_kind=e.get('phase'),event_source='main-observer') for e in events if e.get('kind')=='strict_snapshot_finished']
    seen=set()
    for event in candidates:
        arm=event.get('arm'); phase=event.get('phase'); kind=event['capture_kind']; path=Path(event['path'])
        if arm not in ('B','A','ABASE') or kind not in ('prepared','ready') or not re.fullmatch('glm53-ep76-onepass8-live-'+arm+'-'+kind+'-[0-9a-f]{12}',path.name) or path.parent!=Path('/tmp'):
            raise RuntimeError('unexpected snapshot path')
        if str(path) in seen: continue  # Original event streams retain duplicate references.
        seen.add(str(path)); index=len(manifest['snapshots'])
        entry=dict(event,index=index,private_prefix='snapshots/'+str(index)); manifest['snapshots'].append(entry)
        if path.exists():
            if path.is_symlink() or not path.is_dir(): raise RuntimeError('unsafe snapshot directory')
            children=sorted(path.iterdir())
            if len(children)>40: raise RuntimeError('snapshot file-count bound')
            for child in children: save(entry['private_prefix']+'/'+child.name,stable(child),str(child))
        else: entry['directory_missing']=True
    if stable(STREAMS/'events.jsonl')!=events_raw: raise RuntimeError('observer changed after closure')
    manifest['collector_sha256']=sha(Path(__file__).read_bytes())
    (DEST/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
    print(json.dumps(dict(destination=str(DEST),files=len(manifest['files']),manifest_sha256=sha((DEST/'manifest.json').read_bytes()),terminal=manifest['terminal'])))

if __name__ == '__main__': main()
