#!/usr/bin/env python3
"""Private, immutable live-arm evidence; inspect/log reads only, no requests."""
import argparse
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys

REV = '407271d9cf73f5db6192a8410c68f152e67301cb'
TICKET = '17890258792363139'
OWNER_PID = '2363139'
OWNER_START_TICK = '52827050'

IMAGE = 'sha256:a3dd4c0f6cbb053097d65d10cd8ff8f6ae0cb9115cf0ff142e1cafe124c09211'
JOB = '/tmp/glm53-ep76-onepass-0910-8'
SOURCE = '/home/choiceoh/stkernel-ep-tiled-0909-ring'
SESSION = 'epdecode76onepass0910v8'
EXPECTED_MOUNT_COUNT = 73
NODE = r'''
def valid_sf6_finalized(receipt):
    expected={'layers':42,'raw_bytes_released':42*72*768*2048,
              'packed_bytes':42*72*768*1552,'storage_bytes_saved':42*72*768*(2048-1552)}
    return (isinstance(receipt,dict) and receipt.get('format')=='sf6_v1'
            and receipt.get('packed_only') is True and not any(k.endswith('error') for k in receipt)
            and all(type(receipt.get(k)) is int and receipt[k]==v for k,v in expected.items()))

def prep_configuration(env, expected):
    # These are the frozen module defaults when a knob is absent, not an
    # assertion that PREP ran. Canonical window proof owns execution evidence.
    defaults={'VLLM_GLM53_PREP_FUSED_KERNEL':'cuda',
              'VLLM_GLM53_PREP_FUSED_SHADOW_EVERY':'1',
              'VLLM_GLM53_PREP_FUSED_SELFCHECK_EVERY':'64'}
    if env.get('VLLM_GLM53_PREP_FUSED') != expected:
        raise RuntimeError('actual PREP mode differs')
    if any(env.get(key, value) != value for key,value in defaults.items()):
        raise RuntimeError('actual PREP backend/check cadence differs')
    return {'mode':expected,'kernel':'cuda','shadow_every':1,'selfcheck_every':64,
            'raw_environment':{key:env.get(key) for key in ('VLLM_GLM53_PREP_FUSED',*defaults)},
            'defaulted':[key for key in defaults if key not in env],
            'scope':'configured values only; canonical onepass proof establishes actual PREP execution'}

def exact_speculation(receipt, expected_k, expected_rank, command_sha):
    import re
    return (isinstance(receipt,dict) and set(receipt)=={'method','num_speculative_tokens','config_sha256','command_sha256','node_rank'}
            and receipt['method']=='dflash' and type(receipt['num_speculative_tokens']) is int
            and receipt['num_speculative_tokens']==expected_k and type(receipt['node_rank']) is int
            and receipt['node_rank']==expected_rank and receipt['command_sha256']==command_sha
            and all(isinstance(receipt[k],str) and re.fullmatch('[0-9a-f]{64}',receipt[k]) is not None
                    for k in ('config_sha256','command_sha256')))

def literal_canary_key(text):
    import ast
    tree=ast.parse(text,mode='eval')
    for node in ast.walk(tree):
        if isinstance(node,ast.Call):raise ValueError('call is not a cache-key literal')
        if isinstance(node,ast.Attribute) and not (isinstance(node.value,ast.Name) and node.value.id=='torch' and node.attr=='int32'):
            raise ValueError('unsupported cache-key attribute')
    class Normalize(ast.NodeTransformer):
        def visit_Attribute(self,node):return ast.copy_location(ast.Constant('torch.int32'),node)
    return ast.literal_eval(ast.fix_missing_locations(Normalize().visit(tree)))

def hybrid_rank_contract(receipt, expected_rank):
    identity=receipt.get('loader_identity')
    if (type(expected_rank) is not int or not 0<=expected_rank<4
            or type(identity) is not list or len(identity)!=13
            or identity[0]!='glm53_ep2_tp2_loader_v1'
            or any(type(v) is not int for v in identity[1:])):return False
    ep,tp=expected_rank//2,expected_rank%2
    expected=['glm53_ep2_tp2_loader_v1',288,144,4096,2048,1024,expected_rank,ep,tp,
              ep*144,(ep+1)*144,tp*1024,(tp+1)*1024]
    if identity!=expected:return False
    rank=receipt.get('rank_geometry')
    exact=dict(physical_rank=expected_rank,world_size=4,ep_size=2,ep_rank=ep,tp_size=2,tp_rank=tp,
               expert_start=ep*144,expert_stop=(ep+1)*144,intermediate_start=tp*1024,intermediate_stop=(tp+1)*1024,
               attention_shared_tp_size=4,terminal_output_sum_size=4,collective_execution_verified=False)
    return (type(rank) is dict and rank==exact and all(type(rank[k]) is type(v) for k,v in exact.items()))

def canary_source_contract(receipt, source_files, hybrid):
    import re
    prefix='/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/'
    names=dict(tiled_selftest='glm53_ep_tiled_selftest.py',numerical='glm53_ep_local_selftest.py',
               wrapper='flashinfer_b12x_moe.py',dispatch='moe_dispatch.py',local='moe_dynamic_ep_local.py',
               stock='_moe_dynamic/gated.py',tiled_owner='glm53_ep_tiled.py',tiled_decode='moe_static_ep_tiled.py')
    for name in ('moe_static_kernel_v4','moe_static_kernel_v5','moe_reform_sf_pack','moe_sf_pack','moe_dynamic_gated_sf6'):
        names[name]=name+'.py'
    if hybrid:names['shard_geometry']='glm53_ep_shard_geometry.py'
    sources=receipt.get('source',{}).get('source',{})
    if type(source_files) is not dict or type(sources) is not dict or set(sources)!=set(names):return False
    for name,relative in names.items():
        path=(prefix+relative if name!='wrapper' else
              '/usr/local/lib/python3.12/dist-packages/vllm/model_executor/layers/fused_moe/experts/flashinfer_b12x_moe.py')
        item=sources[name]
        if (type(item) is not dict or set(item)!={'path','sha256'} or item['path']!=path
                or path not in source_files or type(item['sha256']) is not str
                or re.fullmatch('[0-9a-f]{64}',item['sha256']) is None
                or source_files[path]!=item['sha256']):return False
    return True

def canary_loader_contract(receipt, source_files, runtime_pins, loader_path, hybrid):
    import re
    source=receipt.get('source',{})
    if not hybrid:
        return not any(k in source for k in ('hybrid_loader','hybrid_loader_runtime'))
    if (type(runtime_pins) is not dict or len(runtime_pins)!=15
            or type(loader_path) is not str or not loader_path.endswith('/glm53_ep_hybrid.py')
            or loader_path not in source_files):return False
    helper=source.get('hybrid_loader')
    if (type(helper) is not dict or set(helper)!={'path','sha256'}
            or helper['path']!=loader_path or type(helper['sha256']) is not str
            or re.fullmatch('[0-9a-f]{64}',helper['sha256']) is None
            or helper['sha256']!=source_files[loader_path]):return False
    sources=source.get('hybrid_loader_runtime')
    if type(sources) is not dict or set(sources)!=set(runtime_pins):return False
    root='/usr/local/lib/python3.12/dist-packages/vllm/'
    for relative,expected in runtime_pins.items():
        if (type(relative) is not str or re.fullmatch('model_executor/[A-Za-z0-9_/]+[.]py',relative) is None
                or '//' in relative or type(expected) is not str or re.fullmatch('[0-9a-f]{64}',expected) is None):return False
        item=sources[relative]
        if (type(item) is not dict or set(item)!={'path','sha256'}
                or item['path']!=root+relative or type(item['sha256']) is not str
                or re.fullmatch('[0-9a-f]{64}',item['sha256']) is None
                or item['sha256']!=expected):return False
    return True

def global_route_canary_contract(receipt, expected_decode_sha256, expected_decode_opt,
                                 *, expected_hybrid=False, expected_q0_dual_warp=False, expected_rank=None, source_files=None,
                                 expected_runtime_pins=None, expected_loader_path=None):
    try:
        import ast
        if (type(expected_decode_opt) is not bool or expected_decode_opt is not False
                or type(expected_hybrid) is not bool
                or type(expected_q0_dual_warp) is not bool
                or (expected_q0_dual_warp and not expected_hybrid)
                or type(expected_rank) is not int or not 0 <= expected_rank < 4): return False
        e, i = (144,1024) if expected_hybrid else (72,2048)
        if receipt.get('q0_dual_warp',False) is not expected_q0_dual_warp:return False
        if (type(receipt.get('schema')) is not int or receipt['schema'] != (2 if expected_hybrid else 1)
                or receipt.get('geometry') != dict(E=e,K=4096,I=i,top8=8)
                or receipt.get('performance_acceptance') is not False
                or receipt.get('full_sanitizer_acceptance') is not False): return False
        if not canary_source_contract(receipt,source_files,expected_hybrid): return False
        if not canary_loader_contract(receipt,source_files,expected_runtime_pins,expected_loader_path,expected_hybrid): return False
        if expected_hybrid:
            if not hybrid_rank_contract(receipt,expected_rank): return False
        elif any(k in receipt for k in ('loader_identity','rank_geometry')): return False
        if receipt['source']['source']['tiled_decode']['sha256'] != expected_decode_sha256: return False
        import math
        cases=(('mixed6',6),('balanced12',12),('concentrated24',24),('zeros32',32),
               ('remote33',33),('balanced2128',2128),('balanced4096',4096),
               ('concentrated6912',6912),('balanced8192',8192),
               ('mixed4',4),('balanced8',8),('concentrated16',16))
        if (receipt.get('verdict')!='PASS' or receipt.get('phase')!='complete'
                or receipt.get('actual_weight_owner') is not True or receipt.get('caller_preserved') is not True
                or receipt.get('actual_packed_owner') is not True
                or receipt.get('packed_before')!=receipt.get('packed_after')
                or any(k in receipt for k in ('error','cleanup_error','diagnostic_error'))
                or type(receipt.get('cases')) is not list or len(receipt['cases'])!=len(cases)):return False
        before=receipt.get('packed_before')
        if (not isinstance(before,dict) or before.get('raw_sources_retained') is not True
                or before.get('raw_release_acceptance') is not False
                or not isinstance(before.get('planes'),dict) or set(before['planes'])!={'fc1','fc2'}):return False
        import re
        for name,blocks in (('fc1',i//4),('fc2',i//8)):
            plane=before['planes'][name]
            if (not isinstance(plane,dict) or plane.get('shape')!=[e,blocks,1552]
                    or plane.get('dtype')!='torch.uint8' or type(plane.get('data_ptr')) is not int
                    or plane['data_ptr']<=0 or not isinstance(plane.get('sha256'),str)
                    or re.fullmatch('[0-9a-f]{64}',plane['sha256']) is None):return False
        if before['planes']['fc1']['data_ptr']==before['planes']['fc2']['data_ptr']:return False
        pc=before.get('preparation_contract',{})
        expected_pc=dict(both_planes_enabled=True,stage_raw_bytes=2048,stage_packed_bytes=1552,
                         fc1_stages=e*(i//4),fc2_stages=e*(i//8),
                         raw_bytes=113246208,packed_bytes=85819392)
        if any(type(pc.get(k)) is not type(v) or pc[k]!=v for k,v in expected_pc.items()):return False
        def metrics(item,names):
            return (isinstance(item,dict) and type(item.get('bad_rows')) is int and item['bad_rows']==0
                    and all(type(item.get(k)) in (int,float) and math.isfinite(item[k]) and item[k]>=0 for k in names)
                    and not any(k in item for k in ('error','cleanup_error','diagnostic_error')))
        for cell,(name,rows) in zip(receipt['cases'],cases):
            if (not isinstance(cell,dict) or cell.get('case')!=name or type(cell.get('rows')) is not int
                    or cell['rows']!=rows or cell.get('phase')!='complete' or cell.get('verdict')!='PASS'
                    or any(k in cell for k in ('error','cleanup_error','diagnostic_error','first_failure_rows'))):return False
            graph=rows<=33 or rows==8192
            if cell.get('graph_replay') is not graph:return False
            labels=('C1-eager','C2-graph-current' if graph else 'C2-eager','C3-graph-side' if graph else 'C3-side')
            phases=[phase+'-'+label for phase in ('initial','changed') for label in labels]
            candidates=cell.get('candidate');controls=cell.get('controls')
            if type(candidates) is not list or len(candidates)!=6:return False
            if type(controls) is not list or len(controls)!=2 or any(type(x) is not list or len(x)!=3 for x in controls):return False
            if not all(metrics(x,('max_row_relative_l2','max_row_relative_abs','stock_max_row_relative_l2','stock_max_row_relative_abs'))
                       and x.get('phase')==phase for x,phase in zip(candidates,phases)):return False
            if not all(metrics(x,('max_row_relative_l2','max_row_relative_abs')) for group in controls for x in group):return False
        seen=set()
        for cell in receipt['cases']:
            rows=cell['rows']
            if rows>32:
                keys=cell['cache_evidence']['keys']
                if type(keys) is not list or not keys or len(keys)!=len(set(keys)):return False
                for value in keys:
                    key=literal_canary_key(value)
                    tail=('glm53_ep_prefill_local_fp32_v2','glm53_ep_tiled_sf6_v1')
                    if expected_hybrid:tail+=('glm53_ep2tp2_tiled_e144_i1024_v1',)
                    if expected_q0_dual_warp:tail+=('glm53_ep2tp2_q0_dual_warp_v1',)
                    if (type(key) is not tuple or len(key)!=18+len(tail)
                            or key[:7]!=('dynamic','fp4','nvfp4',e,4096,i,8)
                            or key[9]!='torch.int32' or key[10:16]!=(False,True,'swigluoai_uninterleave',1.,0.,10.)
                            or key[17] is not True or key[18:]!=tail):return False
                continue
            if type(rows) is not int or rows not in (4,6,8,12,16,24,32) or rows in seen: return False
            seen.add(rows)
            expected=('glm53_ep_static_tiled_fp32_v1',rows,256,48,'torch.int32',False,True,
                      (16,128,256) if rows<=8 else (32,64,512),
                      (16,256,128) if rows<=8 else (32,128,128),
                      'nvfp4','sf6_v1','swigluoai_uninterleave',1.,0.,10.,
                      'bf16_scatter' if rows<=8 else 'fp32_scatter')
            if rows<=8: expected+=('glm53_ep_static_sf6_a_ring_v1','glm53_ep_static_sf6_word_unpack_v1','glm53_ep_static_bf16_scatter_v1')
            expected+=('glm53_ep_static_fused_route_v1',288,'torch.int32',0)
            if expected_hybrid: expected+=('glm53_ep2tp2_tiled_e144_i1024_v1',144,1024)
            if cell['cache_evidence'].get('decode_opt') is not (rows<=8 and expected_decode_opt):return False
            keys=cell['cache_evidence']['keys']
            if type(keys) is not list or len(keys)!=1 or not isinstance(keys[0],str):return False
            actual=ast.literal_eval(keys[0])
            if type(actual) is not tuple or actual!=expected:return False
        return seen=={4,6,8,12,16,24,32}
    except (KeyError,TypeError,ValueError,SyntaxError,AttributeError): return False

def exact_mm_limit(argv):
    values=[]
    for index,arg in enumerate(argv):
        key,equal,value=arg.partition('=')
        if key!='--limit-mm-per-prompt': continue
        if not equal:
            if index+1>=len(argv): raise RuntimeError('missing multimodal limit value')
            value=argv[index+1]
        values.append(json.loads(value))
    if len(values)!=1 or not isinstance(values[0],dict):
        raise RuntimeError('missing or duplicate multimodal limit')
    value=values[0]
    if set(value)!={'image','video'} or any(type(v) is not int or v<0 for v in value.values()):
        raise RuntimeError('multimodal limits must be exact nonnegative integer image/video fields')
    return value
import math
def valid_startup_trim(receipt,rank,created):
    try:
        if (type(receipt.get('schema')) is not int or receipt['schema']!=1
                or receipt.get('verdict')!='COMPLETE' or type(receipt.get('rank')) is not int
                or receipt['rank']!=rank or receipt.get('measurement_errors')!=[]
                or any(k in receipt for k in ('error','failed_stage'))): return False
        stages=receipt['stages']
        if ([x['stage'] for x in stages]!=['synchronize','gc_collect','empty_cache','malloc_trim']
                or any(x['status']!='COMPLETE' or 'error' in x for x in stages)
                or type(stages[-1]['returned']) is not int or stages[-1]['returned'] not in (0,1)
                or type(stages[1]['collected']) is not int or stages[1]['collected']<0): return False
        for phase in ('before','after'):
            if set(receipt[phase])!={'allocated','reserved','mem_available','vm_rss'}: return False
            if any(type(v) is not int or v<0 for v in receipt[phase].values()): return False
        started,finished=receipt['started_at'],receipt['completed_at']
        if any(type(v) not in (int,float) or not math.isfinite(v) for v in (started,finished)): return False
        return created<=started<=finished<=time.time()
    except (KeyError,TypeError,ValueError,AttributeError): return False
import base64,datetime,gzip,hashlib,json,os,re,stat,subprocess,tempfile,time
from pathlib import Path
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def command(argv):
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    need(p.returncode==0,'read command failed')
    need(len(p.stdout)<=16*2**20,'command output too large')
    return p.stdout
def inspect(ref):
    raw=command(['docker','inspect',ref]); values=json.loads(raw)
    need(len(values)==1,'container inspect not unique')
    return values[0],raw
def bounded(path,maximum=32*2**20):
    path=Path(path); a=path.lstat()
    need(stat.S_ISREG(a.st_mode) and a.st_size<=maximum,'unsafe or oversized file')
    raw=path.read_bytes(); b=path.lstat()
    need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns),'file changed')
    return raw
def active(c):
    need(c['State']['Running'] is True and not c['State'].get('Paused') and not c['State'].get('Restarting'),'container not actively running')
    need(c['Image']==cfg['image'],'wrong pinned image')
def fixed(c):
    # Docker returns Mounts in varying order. Compare every original mount
    # field and duplicate exactly, with only this unordered list canonicalized.
    return {k:c[k] for k in ('Id','Created','Image','Config','HostConfig','RestartCount')} | {'Mounts':sorted(c['Mounts'],key=lambda m:json.dumps(m,sort_keys=True)), 'StartedAt':c['State']['StartedAt'],'Pid':c['State']['Pid']}
def source_evidence(c):
    manifest=bounded('/home/choiceoh/overlays/glm53/manifest.tsv')
    need(sha(manifest)==cfg['manifest_sha256'],'deployed source manifest differs')
    found={}
    for mount in c['Mounts']:
        dest=mount['Destination']
        if dest in cfg['mounts']:
            need(dest not in found and mount['Type']=='bind' and mount['RW'] is False,'ambiguous or writable overlay mount')
            need(mount['Source'].startswith('/home/choiceoh/overlays/glm53/'),'unexpected overlay source')
            found[dest]=sha(bounded(mount['Source']))
    need(found==cfg['mounts'],'mounted overlay source differs')
    return {'manifest_sha256':sha(manifest),'mounts':found}
started=time.time(); c,before=inspect(cfg['name']); active(c)
need(c['Name']=='/'+cfg['name'] and len(c['Id'])==64,'wrong container name/ID')
container_born=datetime.datetime.fromisoformat(c['State']['StartedAt'].replace('Z','+00:00')).timestamp()
container_created=datetime.datetime.fromisoformat(c['Created'].replace('Z','+00:00')).timestamp()
need(container_born>=container_created>=cfg['arm_event']['started_at'],'container creation/start predates or contradicts the selected canonical arm')
if cfg['rank']==0:
    need(c['Id']==cfg['head_id'] and c['State']['StartedAt']==cfg['head_started_at'],'observed head identity changed')
namespace={'__name__':'snapshot_launch_parser'}
exec(compile(base64.b64decode(cfg['parser']),'<frozen-launch-parser>','exec'),namespace)
topology=namespace['launch_parallelism'](c['Config']['Cmd'])
need(topology['enabled']==cfg['ep'] and topology['tensor_parallel_size']==4 and topology['nnodes']==4 and topology['node_rank']==cfg['rank'],'wrong EP/topology')
payload=namespace['_WRAPPER'].fullmatch(c['Config']['Cmd'][1])[1]
script=base64.b64decode(payload,validate=True).decode()
line=script[len(namespace['_GID_PRELUDE']):].removesuffix('\n')
argv=namespace['_literal_argv'](line[:-len(namespace['_REDIRECTION'])])
mm_limit=exact_mm_limit(argv)
need(mm_limit==cfg['mm_limit'],'actual multimodal image/video limits differ')
speculation=namespace['launch_speculation'](c['Config']['Cmd'])
need(exact_speculation(speculation,cfg['spec_k'],cfg['rank'],topology['command_sha256']),'actual DFlash K/config differs')
env={}
for item in c['Config']['Env']:
    key,value=item.split('=',1); need(key and key not in env,'duplicate environment key'); env[key]=value
for key,value in cfg['flags'].items(): need(env.get(key)==value,'unexpected required arm flag: '+key)
prep=prep_configuration(env,'1')
endpoint={}
for i,arg in enumerate(argv):
    key,equal,value=arg.partition('=')
    if key in ('--host','--port'):
        need(key not in endpoint,'duplicate endpoint option')
        endpoint[key]=value if equal else argv[i+1]
if cfg['rank']==0: need(endpoint=={'--host':'127.0.0.1','--port':'18000'},'wrong private head endpoint')
source=source_evidence(c)
mounts=[m for m in c['Mounts'] if m['Destination']=='/glmlogs']
need(len(mounts)==1 and mounts[0]['Type']=='bind','serving log bind missing')
path=Path(mounts[0]['Source'])/'glm53.log'; a=path.lstat()
boot=datetime.datetime.fromisoformat(c['State']['StartedAt'].replace('Z','+00:00')).timestamp()
need(stat.S_ISREG(a.st_mode) and 0<a.st_size<=128*2**20 and a.st_mtime>=boot,'unsafe, stale or oversized serving log')
with path.open('rb') as stream: log=stream.read(a.st_size)
b=path.lstat()
need(len(log)==a.st_size and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) and b.st_size>=a.st_size,'serving log rotated or truncated')
graph=bool(re.search(rb'Graph capturing finished in [0-9]+ secs, took ',log))
if cfg['capture_phase']=='ready': need(graph,'graph capture is not complete on this node')
marker=b'[ep-hybrid-selftest] PASS ' if cfg['hybrid'] else b'[ep-tiled-selftest] PASS '
other=b'[ep-tiled-selftest]' if cfg['hybrid'] else b'[ep-hybrid-selftest]'
need(other not in log,'canary marker belongs to another geometry')
need(not any(m in log for m in (b'[ep-tiled-selftest] FAIL',b'[ep-hybrid-selftest] FAIL')),'canary failure occurred in this boot')
if log and not log.endswith(b'\n'):
    tail=log.rsplit(b'\n',1)[-1]
    need(not any(m in tail for m in (b'[ep-tiled',b'[ep-hybrid',b'[prep-fused]',b'[glm53-startup-trim]')),'partial proof marker at snapshot boundary')
source_files=dict(cfg['mounts'])
source_files['/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/_moe_dynamic/gated.py']='993783308233288ddfa77293e9dbabdc825ba5bfdcc4dcc41e842a895ec33445'
pass_records=[]; finalized=[]
for raw_line in log.splitlines():
    if marker in raw_line:
        receipt,_=json.JSONDecoder().raw_decode(raw_line.split(marker,1)[1].decode())
        need(isinstance(receipt,dict) and receipt.get('verdict')=='PASS' and receipt.get('phase')=='complete','invalid selected canary PASS receipt')
        if cfg['ep']:
            need(global_route_canary_contract(receipt,cfg['mounts']['/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/moe_static_ep_tiled.py'],cfg['decode_opt'],expected_hybrid=cfg['hybrid'],expected_q0_dual_warp=cfg['q0_dual_warp'],expected_rank=cfg['rank'],source_files=source_files,expected_runtime_pins=cfg['hybrid_runtime_pins'],expected_loader_path=cfg['hybrid_loader_path']),'candidate global-route cases/key/source evidence differs')
        need(type(receipt.get('started_at')) in (int,float) and type(receipt.get('completed_at')) in (int,float) and container_created <= receipt['started_at'] <= receipt['completed_at'] <= time.time(),'canary receipt predates this boot or has invalid timing')
        pass_records.append({'line_sha256':sha(raw_line),'receipt_sha256':sha(json.dumps(receipt,sort_keys=True,separators=(',',':')).encode())})
    if b'[ep-tiled-sf6] FINALIZED ' in raw_line:
        receipt,_=json.JSONDecoder().raw_decode(raw_line.split(b'[ep-tiled-sf6] FINALIZED ',1)[1].decode())
        finalized.append({'line_sha256':sha(raw_line),'receipt':receipt})
fail_marker_present=marker.replace(b'PASS ',b'FAIL ') in log
if cfg['capture_phase']=='ready':
    need(len(pass_records)==1 and not fail_marker_present,'selected canary is absent/duplicate or failed')
    if cfg['ep']:
        need(len(finalized)==1 and valid_sf6_finalized(finalized[0]['receipt']),'EP tiled SF6 finalized receipt absent/invalid/duplicate')
        need(not re.search(rb'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)',log),'EP tiled SF6 release failure')
trim_marker=b'[glm53-startup-trim] '; trim_records=[]
for raw_line in log.splitlines():
    if trim_marker not in raw_line:continue
    receipt,_=json.JSONDecoder().raw_decode(raw_line.split(trim_marker,1)[1].decode())
    if cfg['capture_phase']=='ready': need(valid_startup_trim(receipt,cfg['rank'],container_created),'startup trim is not complete on this rank')
    trim_records.append({'line_sha256':sha(raw_line),'receipt':receipt})
if cfg['capture_phase']=='ready': need(len(trim_records)==1,'startup trim requires exactly one complete receipt per rank')

with tempfile.TemporaryFile() as stream:
    result=subprocess.run(['docker','logs','--timestamps','--since',c['State']['StartedAt'],c['Id']],stdout=stream,stderr=stream,timeout=30)
    need(result.returncode==0,'docker log read failed')
    size=stream.tell(); need(size<=128*2**20,'docker logs too large')
    stream.seek(0); docker_log=stream.read()
again,after=inspect(c['Id']); by_name,_=inspect(cfg['name']); active(again); active(by_name)
need(fixed(c)==fixed(again)==fixed(by_name),'container/start/config changed during capture')
need(source_evidence(again)==source,'source changed during capture')
files={'inspect.before.json':before,'inspect.after.json':after,'serving.log':log,'docker.log':docker_log,
       'manifest.tsv':bounded('/home/choiceoh/overlays/glm53/manifest.tsv')}
summary={'node':cfg['node'],'id':c['Id'],'created_at':c['Created'],'started_at':c['State']['StartedAt'],'image':c['Image'],
         'capture_started_at':started,'capture_finished_at':time.time(),'running_start_config_stable':True,
         'topology':topology,'preparation':prep,'speculation':speculation,'flags':cfg['flags'],'endpoint':endpoint,'mm_limit':mm_limit,'source':source,
         'readiness':{'graph_finished':graph,'candidate':cfg['candidate'],'hybrid':cfg['hybrid'],'q0_dual_warp':cfg['q0_dual_warp'],'selected_canary_pass_records':pass_records,'canary_fail_marker_present':fail_marker_present,'ep_sf6_finalized_records':finalized,'capture_phase':cfg['capture_phase'],'startup_trim_records':trim_records},
         'environment_sha256':sha(json.dumps(env,sort_keys=True,separators=(',',':')).encode()),
         'log_source':{'path':str(path),'device':a.st_dev,'inode':a.st_ino,'captured_prefix_bytes':len(log),
                       'size_after':b.st_size,'mtime_ns_before':a.st_mtime_ns,'mtime_ns_after':b.st_mtime_ns},
         'scope':'live prefix snapshot; traffic may still be in progress; no quality/performance acceptance'}
print(json.dumps({'summary':summary,'files':{k:{'sha256':sha(v),'bytes':len(v),'gzip':base64.b64encode(gzip.compress(v,mtime=0)).decode()} for k,v in files.items()}}))
'''

REMOTE = r'''

def current_arm_event(session, ticket, owner_pid):
    import datetime, hashlib, json, pathlib, re, stat
    fleet=pathlib.Path('/home/choiceoh/glm53-logs/fleet')
    pending=json.loads((fleet/'pending'/(hashlib.sha256(session.encode()).hexdigest()+'.json')).read_text())
    if pending.get('session')!=session or str(pending.get('ticket'))!=ticket or str(pending.get('pid'))!=str(owner_pid) or str(pending.get('start'))!=cfg['owner_start_tick']:
        raise RuntimeError('arm reservation identity differs')
    fields=pathlib.Path('/proc/'+str(owner_pid)+'/stat').read_bytes().rsplit(b')',1)[1].split()
    if fields[0]==b'Z' or fields[19].decode('ascii')!=str(pending.get('start')):
        raise RuntimeError('arm supervisor start differs or exited')
    if pending.get('payload_returncode') is not None or pending.get('returncode') is not None:
        raise RuntimeError('arm payload is already terminal')
    holder=(fleet/'holder').read_text().strip().split('|')
    if len(holder)<2 or holder[:2]!=[session,str(owner_pid)]:
        raise RuntimeError('arm is not held by this supervisor')
    path=fleet/'run-logs'/(hashlib.sha256((session+'\0'+ticket).encode()).hexdigest()+'.log')
    before=path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_size>16*2**20:
        raise RuntimeError('unsafe or oversized canonical run log')
    with path.open('rb') as stream: raw=stream.read(before.st_size)
    after=path.lstat()
    if len(raw)!=before.st_size or (before.st_dev,before.st_ino)!=(after.st_dev,after.st_ino) or after.st_size<before.st_size:
        raise RuntimeError('canonical run log changed identity')
    if raw and not raw.endswith(b'\n'): raw=raw.rsplit(b'\n',1)[0]+b'\n' if b'\n' in raw else b''
    events=list(re.finditer(rb'(?m)^== ([0-9]{2}:[0-9]{2}:[0-9]{2}) (?:arm (?P<regular>[^ :\r\n]+):[^\r\n]*|defaults arm (?P<automatic>[^ \r\n]+) \(baseline sample [0-9]+/[0-9]+ on this build; the verdict needs it\))$',raw))
    expected=['EPDECODE76'+arm for arm in ('B','A','ABASE')]
    names=[(e['regular'] or e['automatic']).decode() for e in events]
    if (not names or names!=expected[:len(names)]
            or any(bool(e['automatic']) != (name=='EPDECODE76ABASE') for e,name in zip(events,names))):
        raise RuntimeError('canonical arm order/type is absent or differs')
    event=events[-1]; hour,minute,second=map(int,event[1].split(b':'))
    now=datetime.datetime.now().astimezone()
    born=now.replace(hour=hour,minute=minute,second=second,microsecond=0)
    if born>now: born-=datetime.timedelta(days=1)
    if (now-born).total_seconds()>3*3600:
        raise RuntimeError('arm event is stale or clock differs')
    marker={'path':str(path),'device':before.st_dev,'inode':before.st_ino,'offset':event.start(),'line':event[0].decode()}
    return dict(arm=names[-1].removeprefix('EPDECODE76'),started_at=born.timestamp(),
                started_at_local=born.isoformat(),key=hashlib.sha256(json.dumps(marker,sort_keys=True).encode()).hexdigest(),**marker)
import base64,gzip,hashlib,json,os,stat,subprocess,time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
os.umask(0o077)
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
    if not ok: raise RuntimeError(msg)
def run(argv):
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    need(p.returncode==0,'source read command failed'); return p.stdout
def holder():
    raw=Path('/home/choiceoh/glm53-logs/fleet/holder').read_bytes()
    need(raw.decode().strip().split('|')[0]==cfg['session'],'different active fleet holder')
    return raw
def source_check():
    need(run(['git','-C',cfg['source'],'rev-parse','HEAD']).decode().strip()==cfg['revision'],'frozen HEAD differs')
    need(not run(['git','-C',cfg['source'],'status','--porcelain','--untracked-files=no']).strip(),'frozen tracked source dirty')
def write(path,data):
    with path.open('xb') as stream: stream.write(data)
    path.chmod(0o600)
before_holder=holder(); source_check()
arm_event=current_arm_event(cfg['session'],cfg['ticket'],cfg['owner_pid'])
need(arm_event['arm']==cfg['arm'] and arm_event['key']==cfg['arm_event_key'],'selected canonical arm changed')
cfg['arm_event']=arm_event
job=Path(cfg['job']); need(job.is_dir() and not job.is_symlink(),'job directory absent/unsafe')
dest=job/('live-'+cfg['label']); dest.mkdir(mode=0o700,exist_ok=False)
source=Path(cfg['source']); manifest=(source/'build/glm53/manifest.tsv').read_bytes()
expected=b'# source_commit='+cfg['revision'].encode()+b'\n'+manifest
mounts={}; hybrid_loaders=[]
for line in manifest.decode().splitlines():
    if not line or line.startswith('#'): continue
    name,target,group=line.split('\t')
    need('/' not in name and name not in ('.','..') and target not in mounts,'unsafe/duplicate manifest entry')
    mounts[target]=sha((source/'build/glm53'/name).read_bytes())
    if name=='glm53_ep_hybrid.py':hybrid_loaders.append((name,target))
need(type(cfg['expected_mount_count']) is int and cfg['expected_mount_count']>=14
     and len(mounts)==cfg['expected_mount_count'],'selected source mount count differs')
need('/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/glm53_ep_shard_geometry.py' in mounts,
     'hybrid geometry helper is absent from frozen manifest')
need(len(hybrid_loaders)==1,'frozen manifest requires exactly one hybrid loader helper')
import ast,re
helper_name,hybrid_loader_path=hybrid_loaders[0]
helper=(source/'build/glm53'/helper_name).read_bytes()
need(sha(helper)==mounts[hybrid_loader_path],'hybrid helper bytes changed')
assignments=[n for n in ast.parse(helper).body if isinstance(n,ast.Assign)
             and any(isinstance(t,ast.Name) and t.id=='_RUNTIME_SOURCE_PINS' for t in n.targets)]
need(len(assignments)==1,'hybrid runtime source pin declaration missing/duplicate')
hybrid_runtime_pins=ast.literal_eval(assignments[0].value)
need(type(hybrid_runtime_pins) is dict and len(hybrid_runtime_pins)==15
     and all(type(k) is str and re.fullmatch('model_executor/[A-Za-z0-9_/]+[.]py',k) and '//' not in k
             and type(v) is str and re.fullmatch('[0-9a-f]{64}',v)
             for k,v in hybrid_runtime_pins.items()),'invalid frozen hybrid runtime pins')
parser=(source/'bench/glm53_launch_metadata.py').read_bytes()
need(parser==run(['git','-C',str(source),'show',cfg['revision']+':bench/glm53_launch_metadata.py']),'launch parser differs')
common=dict(cfg,parser=base64.b64encode(parser).decode(),manifest_sha256=sha(expected),mounts=mounts,
            hybrid_runtime_pins=hybrid_runtime_pins,hybrid_loader_path=hybrid_loader_path)
nodes=('local','10.10.10.1','10.10.10.3','10.10.10.4')
def capture(pair):
    rank,node=pair
    data=dict(common,node=node,rank=rank,name='glm53' if rank==0 else 'glm53-worker')
    code='cfg='+repr(data)+'\n'+node_code
    cmd=['python3','-B','-'] if rank==0 else ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','choiceoh@'+node,'python3 -B -']
    result=subprocess.run(cmd,input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=150)
    if result.returncode:
        write(dest/(node+'.failure.private.log'),result.stderr)
        raise RuntimeError('node snapshot failed: '+node)
    obj=json.loads(result.stdout); entries={}
    for name,item in obj['files'].items():
        need(name in ('inspect.before.json','inspect.after.json','serving.log','docker.log','manifest.tsv'),'unexpected capture path')
        packed=base64.b64decode(item['gzip'],validate=True); raw=gzip.decompress(packed)
        need(len(raw)==item['bytes'] and sha(raw)==item['sha256'],'capture transport hash differs')
        relative=node+'.'+name+'.gz'; write(dest/relative,packed)
        entries[relative]={'original_sha256':sha(raw),'original_bytes':len(raw),'stored_sha256':sha(packed),'stored_bytes':len(packed)}
    return node,obj['summary'],entries
with ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(capture,enumerate(nodes)))
after_holder=holder(); need(before_holder==after_holder,'holder changed during capture'); source_check()
need(current_arm_event(cfg['session'],cfg['ticket'],cfg['owner_pid'])['key']==cfg['arm_event_key'],'canonical arm changed during capture')
write(dest/'holder.before.private',before_holder); write(dest/'holder.after.private',after_holder)
write(dest/'launch-parser.py',parser)
identity={'schema':1,'arm':cfg['arm'],'label':cfg['label'],'revision':cfg['revision'],'source':cfg['source'],
          'session':cfg['session'],'ticket':cfg['ticket'],'owner_pid':cfg['owner_pid'],'owner_start_tick':cfg['owner_start_tick'],
          'arm_event':arm_event,'captured_at':time.time(),'parser_sha256':sha(parser),
          'hybrid_loader_path':hybrid_loader_path,'hybrid_loader_sha256':mounts[hybrid_loader_path],
          'hybrid_runtime_pins':hybrid_runtime_pins,
          'nodes':{n:s for n,s,_ in results},'files':{k:v for _,_,es in results for k,v in es.items()}}
write(dest/'identity.json',(json.dumps(identity,indent=2,sort_keys=True)+'\n').encode())
files={}
for path in sorted(dest.iterdir()):
    need(path.is_file() and not path.is_symlink(),'unsafe saved capture')
    raw=path.read_bytes(); files[path.name]={'sha256':sha(raw),'data':base64.b64encode(raw).decode()}
print(json.dumps({'identity':identity,'remote_directory':str(dest),'files':files}))
'''


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--arm',choices=('B','A','ABASE'),required=True)
    p.add_argument('--revision',required=True)
    p.add_argument('--session',required=True)
    p.add_argument('--suffix',default='')
    p.add_argument('--capture-phase',choices=('prepared','ready'),required=True)
    p.add_argument('--head-id',required=True)
    p.add_argument('--head-started-at',required=True)
    p.add_argument('--arm-event-key',required=True)
    p.add_argument('--syntax-check',action='store_true')
    args=p.parse_args()
    if not re.fullmatch('[a-f0-9]{40}',args.revision): p.error('full revision required')
    if not re.fullmatch('[a-f0-9]{64}',args.head_id) or not re.fullmatch('[a-f0-9]{64}',args.arm_event_key): p.error('exact head and arm event identities required')
    if args.session != SESSION: p.error('wrong or unbound hybrid session')
    if args.suffix and not re.fullmatch('[A-Za-z0-9][A-Za-z0-9_-]{0,39}',args.suffix): p.error('unsafe suffix')
    label=args.arm+('-'+args.suffix if args.suffix else '')
    config=dict(arm=args.arm,label=label,revision=args.revision,session=args.session,job=JOB,source=SOURCE,
                image=IMAGE,ticket=TICKET,owner_pid=OWNER_PID,owner_start_tick=OWNER_START_TICK,head_id=args.head_id,
                head_started_at=args.head_started_at,arm_event_key=args.arm_event_key,
                spec_k=5,capture_phase=args.capture_phase,ep=True,candidate=args.arm=='A',hybrid=True,q0_dual_warp=args.arm=='A',decode_opt=False,expected_mount_count=EXPECTED_MOUNT_COUNT,mm_limit={'image':4,'video':0},flags={
                    'VLLM_GLM53_SPEC_K':'5',
                    'VLLM_GLM53_PREP_FUSED':'1',
                    'VLLM_GLM53_DROP_WEIGHT_CACHE':'1',
                    'VLLM_GLM53_EP_PREFILL_LOCAL':'0',
                    'VLLM_B12X_EP_WARM_COMPACT':'0',
                    'VLLM_B12X_EP_ZERO_WEIGHT_MICRO':'0',
                    'VLLM_GLM53_TP_SF6_Q0':'0',
                    'VLLM_GLM53_EP_TILED':'1',
                    'VLLM_GLM53_EP_DECODE_OPT':'0',
                    'VLLM_GLM53_EP_HYBRID_TP2':'1',
                    'VLLM_GLM53_EP_HYBRID_Q0_DUAL_WARP':'1' if args.arm=='A' else '0',
                    'VLLM_GLM53_B12X_STATIC_V2':'t,r,sf6',
                    'VLLM_GLM53_STARTUP_TRIM':'1',
                    'VLLM_GLM53_SKIP_UNUSED_GRAPH_PROFILE':'1'})
    code='cfg='+repr(config)+'\nnode_code='+repr(NODE)+'\n'+REMOTE
    ast.parse(NODE); ast.parse(code)
    if args.syntax_check:
        print(json.dumps({'syntax':'PASS','arm':args.arm,'label':label,'remote_execution':False})); return
    if args.revision!=REV or not re.fullmatch('[a-f0-9]{40}',REV) or not TICKET.isdecimal() or not OWNER_PID.isdecimal() or int(OWNER_PID)<=0 or not OWNER_START_TICK.isdecimal() or type(EXPECTED_MOUNT_COUNT) is not int or EXPECTED_MOUNT_COUNT<14 or 'TO_BIND' in (SOURCE+JOB+SESSION) or not SOURCE.startswith('/home/choiceoh/') or not JOB.startswith('/tmp/'):
        p.error('bind actual ep76-onepass6 revision, ticket, owner PID and start tick before capture')
    os.umask(0o077)
    local=Path('/tmp')/('glm53-ep76-onepass8-live-'+label)
    local.mkdir(mode=0o700,exist_ok=False)
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','choiceoh@srv2','python3 -B -'],
                          input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=210)
    if result.returncode:
        (local/'failure.private.log').write_bytes(result.stderr)
        (local/'failure.private.log').chmod(0o600)
        raise RuntimeError('snapshot rejected; private failure log: '+str(local/'failure.private.log'))
    obj=json.loads(result.stdout)
    for name,item in obj['files'].items():
        if Path(name).name!=name or name in ('.','..'): raise RuntimeError('unsafe received path')
        raw=base64.b64decode(item['data'],validate=True)
        if hashlib.sha256(raw).hexdigest()!=item['sha256']: raise RuntimeError('received hash differs')
        target=local/name
        with target.open('xb') as stream: stream.write(raw)
        target.chmod(0o600)
    print(json.dumps({'arm':args.arm,'revision':args.revision,'remote_directory':obj['remote_directory'],
                      'local_directory':str(local),'identity_sha256':hashlib.sha256((local/'identity.json').read_bytes()).hexdigest(),
                      'nodes':{n:{k:s[k] for k in ('id','started_at','image','running_start_config_stable')} for n,s in obj['identity']['nodes'].items()}}))


if __name__=='__main__':
    try: main()
    except Exception as exc:
        print(str(exc),file=sys.stderr)
        raise SystemExit(1)
