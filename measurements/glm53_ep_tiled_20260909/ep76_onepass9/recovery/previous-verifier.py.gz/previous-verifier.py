#!/usr/bin/env python3
"""Conditional v8 public EP K5/PREP default proof; run on srv2 only after accepted merge/recovery.

Both --approved-source and --controller-source are mandatory full commit IDs. This helper keeps them unbound and rejects placeholders.
The live SPEC_K=5 and PREP on/cuda/every1/64 checks attest configuration; actual draft execution belongs
to the preceding accepted canonical onepass counter proof, not this GET-only snapshot.
Prepared against candidate388aabdd; no current candidate commit is pre-approved by this helper.
Approved source/controller/receipt remain mandatory unbound CLI arguments; PREP stdout logging does not change the public configuration-only proof scope.

No inference requests, imports of serving packages, writes, or lifecycle calls.
The only HTTP request is GET /health. Raw Docker configuration stays in memory. Node errors expose only allowlisted
codes/stages and approved field names. Mount order is normalized without dropping fields.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

sys.dont_write_bytecode = True
PINNED_IMAGE = 'sha256:a3dd4c0f6cbb053097d65d10cd8ff8f6ae0cb9115cf0ff142e1cafe124c09211'
EXPECTED_MOUNTED_FILES = 71
EXPECTED_CURRENT_BOOTS = {'0': {'id': 'b58a3dba15c344bfa23ab24c8a729fe7f3d8aa4877704c3a35cec70d509d77b7', 'started_at': '2026-09-10T06:23:18.649787695Z'}, '1': {'id': '9ff8100ca133f23d6156a3f56d60bd237c7681c2672e202b325dc4acc642f444', 'started_at': '2026-09-10T06:23:18.146859432Z'}, '2': {'id': '4601c65a6acc8d12d0b9ff6be9437ecf09ed489072b76edce423f9fc2536f60a', 'started_at': '2026-09-10T06:23:18.208186331Z'}, '3': {'id': '5e0366e052a68d7883d74f5f18a3b9b7f0c89fd3f47029bd6137781a1e47c927', 'started_at': '2026-09-10T06:23:18.17361639Z'}}
CONTROLLER = Path('/home/choiceoh/stkernel')

SAFE_NODE_CODES = ['CONTAINER_NOT_RUNNING', 'CONTAINER_OOM_MARKER', 'CONTAINER_SNAPSHOT_CHANGED', 'DOCKER_TIMESTAMP_INVALID', 'DOCKER_TIMESTAMP_ORDER', 'ENDPOINT_MISMATCH', 'ENDPOINT_OPTION_INVALID', 'ENVIRONMENT_DUPLICATE', 'ENVIRONMENT_INVALID', 'EXTRA_GLM_ENVIRONMENT', 'FILE_MISSING', 'HEAD_CACHE_RECEIPT_MISMATCH', 'HEAD_STAMP_MISMATCH', 'HEAD_STAMP_POSTDATES_BOOT', 'IMAGE_TAG_MISMATCH', 'MOUNT_DUPLICATE', 'NODE_NO_SAFE_RECEIPT', 'NODE_RECEIPT_INVALID', 'OVERLAY_MOUNT_MISMATCH', 'PARSE_REJECTED', 'PERMISSION_DENIED', 'PREDICATE_REJECTED', 'PROFILE_DEFAULT_MISMATCH', 'PUBLIC_HEALTH_FAILED', 'READ_COMMAND_FAILED', 'READ_COMMAND_TIMEOUT', 'RUNNING_IMAGE_MISMATCH', 'SOURCE_HASH_MISMATCH', 'SOURCE_PATH_INVALID', 'SOURCE_POSTDATES_BOOT', 'SOURCE_READ_CHANGED', 'SOURCE_SNAPSHOT_CHANGED', 'TOPOLOGY_MISMATCH', 'UNEXPECTED_NODE_EXCEPTION']
SAFE_NODE_STAGES = ['container-inspect', 'container-postcheck', 'environment', 'head-cache-receipt', 'head-health', 'head-stamp', 'image-check', 'input', 'launch-parser', 'mount-table', 'source-files', 'source-mounts', 'source-postcheck']

STARTUP_CODES = ['EP_FAILURE_MARKER', 'EP_PASS_RECEIPT_COUNT', 'SF6_RELEASE_REJECTED', 'EP_RECEIPT_REJECTED', 'EP_RECEIPT_BOOT_MISMATCH', 'SF6_PACKED_OWNER_REJECTED', 'EP_SOURCE_RECEIPT_REJECTED', 'EP_CACHE_KEY_REJECTED', 'EP_CASE_SET_REJECTED', 'EP_CASE_REJECTED', 'EP_CONTROLS_REJECTED', 'EP_GRAPH_NOT_READY', 'EP_STARTUP_ORDER_REJECTED']
SAFE_NODE_CODES += STARTUP_CODES + ['MODEL_ARGUMENT_MISMATCH','MODEL_MOUNT_MISMATCH','LOG_MOUNT_MISMATCH','LOG_INVALID','LOG_CHANGED','SPECULATION_CONFIG_MISMATCH','PREP_CONFIGURATION_MISMATCH','PREP_FAILURE_MARKER']
SAFE_NODE_STAGES += ['startup-log','startup-receipts','startup-log-postcheck']

STARTUP_HELPERS = r'''
def preparation_configuration(env):
    defaults={'VLLM_GLM53_PREP_FUSED_KERNEL':'cuda',
              'VLLM_GLM53_PREP_FUSED_SHADOW_EVERY':'1',
              'VLLM_GLM53_PREP_FUSED_SELFCHECK_EVERY':'64'}
    if env.get('VLLM_GLM53_PREP_FUSED')!='1' or any(env.get(k,v)!=v for k,v in defaults.items()):
        raise ValueError('PREP_CONFIGURATION_MISMATCH')
    return dict(mode='1',kernel='cuda',shadow_every=1,selfcheck_every=64,
                defaulted=[key for key in defaults if key not in env],
                execution_proved=False,
                scope='Configured values only. Accepted canonical required PREP proof owns execution evidence; this GET-only snapshot cannot replace it.')

def preparation_log_clean(log):
    import re
    return not any(re.search(r'DISARM|DRIFT|plan build failed|fused prepare failed|CUDA kernel unavailable|extension has no run_prep',line)
                   for line in log.splitlines() if '[prep-fused]' in line)

def global_route_canary_key(receipt, expected_decode_sha256):
    try:
        import ast
        if receipt['source']['source']['tiled_decode']['sha256'] != expected_decode_sha256: return False
        seen=set()
        for cell in receipt['cases']:
            rows=cell['rows']
            if rows>32: continue
            if type(rows) is not int or rows not in (4,6,8,12,16,24,32) or rows in seen: return False
            seen.add(rows)
            expected=('glm53_ep_static_tiled_fp32_v1',rows,256,48,'torch.int32',False,True,
                      (16,128,256) if rows<=8 else (32,64,512),
                      (16,256,128) if rows<=8 else (32,128,128),
                      'nvfp4','sf6_v1','swigluoai_uninterleave',1.,0.,10.,
                      'bf16_scatter' if rows<=8 else 'fp32_scatter')
            if rows<=8: expected+=('glm53_ep_static_sf6_a_ring_v1','glm53_ep_static_sf6_word_unpack_v1','glm53_ep_static_bf16_scatter_v1')
            expected+=('glm53_ep_static_fused_route_v1',288,'torch.int32',0)
            keys=cell['cache_evidence']['keys']
            if type(keys) is not list or len(keys)!=1 or not isinstance(keys[0],str):return False
            actual=ast.literal_eval(keys[0])
            if type(actual) is not tuple or actual!=expected:return False
        return seen=={4,6,8,12,16,24,32}
    except (KeyError,TypeError,ValueError,SyntaxError,AttributeError): return False

CASES = {'mixed6':6,'balanced12':12,'concentrated24':24,'zeros32':32,
         'remote33':33,'balanced2128':2128,'balanced4096':4096,
         'concentrated6912':6912,'balanced8192':8192,
         'mixed4':4,'balanced8':8,'concentrated16':16}

def ep_startup_evidence(log, source_files, start, now, proof):
    """Pure receipt verification; numerical metrics are source-bound summaries."""
    import hashlib, json, math, re
    def need(ok, code):
        if not ok: raise ValueError(code)
    def number(value): return type(value) in (int,float) and math.isfinite(value) and value>=0
    need('[ep-hybrid' not in log and '[ep-tiled-selftest] FAIL' not in log and
         not re.search(r'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)', log), 'EP_FAILURE_MARKER')
    records=proof['_json_marker_receipts'](log,'[ep-tiled-selftest] PASS ')
    final=proof['_json_marker_receipts'](log,'[ep-tiled-sf6] FINALIZED ')
    need(records is not None and len(records)==1, 'EP_PASS_RECEIPT_COUNT')
    need(final is not None and len(final)==1 and final[0].get('layers')==42 and
         type(final[0]['layers']) is int and proof['_ep_tiled_sf6_release_proof'](log), 'SF6_RELEASE_REJECTED')
    r=records[0]
    need(r.get('schema')==1 and type(r['schema']) is int and r.get('verdict')=='PASS' and
         r.get('phase')=='complete' and r.get('actual_weight_owner') is True and
         r.get('caller_preserved') is True and r.get('geometry')==dict(E=72,K=4096,I=2048,top8=8) and
         r.get('performance_acceptance') is False and r.get('full_sanitizer_acceptance') is False and
         not any(k in r for k in ('error','cleanup_error','diagnostic_error')), 'EP_RECEIPT_REJECTED')
    need(number(r.get('started_at')) and number(r.get('completed_at')) and
         start <= r['started_at'] <= r['completed_at'] <= now, 'EP_RECEIPT_BOOT_MISMATCH')
    need(proof['_ep_tiled_sf6_proof'](r), 'SF6_PACKED_OWNER_REJECTED')
    sources=r.get('source',{}).get('source',{})
    expected_names={'tiled_selftest','numerical','wrapper','dispatch','local','stock','tiled_owner',
                    'tiled_decode','moe_static_kernel_v4','moe_static_kernel_v5','moe_reform_sf_pack',
                    'moe_sf_pack','moe_dynamic_gated_sf6'}
    need(isinstance(sources,dict) and set(sources)==expected_names, 'EP_SOURCE_RECEIPT_REJECTED')
    basenames=dict(tiled_selftest='glm53_ep_tiled_selftest.py',numerical='glm53_ep_local_selftest.py',
                   wrapper='flashinfer_b12x_moe.py',dispatch='moe_dispatch.py',local='moe_dynamic_ep_local.py',
                   stock='gated.py',tiled_owner='glm53_ep_tiled.py',tiled_decode='moe_static_ep_tiled.py')
    for name in expected_names-set(basenames): basenames[name]=name+'.py'
    for name,item in sources.items():
        need(isinstance(item,dict) and set(item)=={'path','sha256'} and
             isinstance(item['path'],str) and item['path'].rsplit('/',1)[-1]==basenames[name] and
             item['path'] in source_files and isinstance(item['sha256'],str) and
             re.fullmatch(r'[0-9a-f]{64}',item['sha256']) is not None and
             source_files[item['path']]==item['sha256'], 'EP_SOURCE_RECEIPT_REJECTED')
    need(global_route_canary_key(r,sources['tiled_decode']['sha256']), 'EP_CACHE_KEY_REJECTED')
    cases=r.get('cases')
    need(type(cases) is list and len(cases)==12 and
         all(isinstance(c,dict) and c.get('case') in CASES for c in cases) and
         [(c['case'],c.get('rows')) for c in cases]==list(CASES.items()), 'EP_CASE_SET_REJECTED')
    for c in cases:
        need(type(c.get('rows')) is int and c['rows']==CASES[c['case']] and
             proof['_ep_tiled_case_proof'](c), 'EP_CASE_REJECTED')
        controls=c.get('controls')
        need(type(controls) is list and len(controls)==2 and
             all(type(items) is list and len(items)==3 for items in controls), 'EP_CONTROLS_REJECTED')
        for item in [v for group in controls for v in group]:
            need(isinstance(item,dict) and type(item.get('bad_rows')) is int and item['bad_rows']==0 and
                 all(number(item.get(k)) for k in ('max_row_relative_l2','max_row_relative_abs')) and
                 not any(k in item for k in ('error','cleanup_error','diagnostic_error')), 'EP_CONTROLS_REJECTED')
        for item in c['candidate']:
            need(all(number(item.get(k)) for k in ('max_row_relative_l2','max_row_relative_abs',
                 'stock_max_row_relative_l2','stock_max_row_relative_abs')), 'EP_CASE_REJECTED')
    need(bool(re.search(r'Graph capturing finished in [0-9]+ secs, took ', log)), 'EP_GRAPH_NOT_READY')
    # Canonical order is before-relayout canary -> final model release -> serving graph capture.
    need(log.index('[ep-tiled-selftest] PASS ') < log.index('[ep-tiled-sf6] FINALIZED ') <
         re.search(r'Graph capturing finished in [0-9]+ secs, took ',log).start(), 'EP_STARTUP_ORDER_REJECTED')
    return dict(canary_sha256=hashlib.sha256(json.dumps(r,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                source_receipt_sha256=hashlib.sha256(json.dumps(sources,sort_keys=True).encode()).hexdigest(),
                cases=12,candidate_checks=72,stock_control_checks=72,
                native_key_lengths={'4':23,'6':23,'8':23,'12':20,'16':20,'24':20,'32':20},
                actual_packed_owner=True,caller_preserved=True,sf6_finalized=final[0],
                graph_finished=True,started_at=r['started_at'],completed_at=r['completed_at'],
                scope='source-bound startup numerical and SF6 release proof; no new inference or performance acceptance')

'''

NODE = r'''
import json, re, sys, subprocess
STAGE = 'input'
class NodeRejected(Exception):
    def __init__(self, code, field=None):
        self.code, self.field = code, field
        super().__init__(code)
SAFE_MESSAGES = {'container not running normally': 'CONTAINER_NOT_RUNNING', 'container OOM marker': 'CONTAINER_OOM_MARKER', 'invalid Docker timestamp': 'DOCKER_TIMESTAMP_INVALID', 'running image differs': 'RUNNING_IMAGE_MISMATCH', 'node image tag differs': 'IMAGE_TAG_MISMATCH', 'created after start': 'DOCKER_TIMESTAMP_ORDER', 'wrong topology': 'TOPOLOGY_MISMATCH', 'missing or duplicate public endpoint option': 'ENDPOINT_OPTION_INVALID', 'wrong public endpoint': 'ENDPOINT_MISMATCH', 'malformed environment': 'ENVIRONMENT_INVALID', 'conflicting duplicate environment': 'ENVIRONMENT_DUPLICATE', 'extra GLM candidate environment': 'EXTRA_GLM_ENVIRONMENT', 'duplicate mount destination': 'MOUNT_DUPLICATE', 'deployed source is not a regular local path': 'SOURCE_PATH_INVALID', 'file changed during read': 'SOURCE_READ_CHANGED', 'head boot stamp differs': 'HEAD_STAMP_MISMATCH', 'head boot stamp postdates start': 'HEAD_STAMP_POSTDATES_BOOT', 'head compile receipt differs': 'HEAD_CACHE_RECEIPT_MISMATCH', 'deployed files changed across snapshot': 'SOURCE_SNAPSHOT_CHANGED', 'public head health failed': 'PUBLIC_HEALTH_FAILED', 'container identity changed across snapshot': 'CONTAINER_SNAPSHOT_CHANGED'}
SAFE_MESSAGES.update({**{code:code for code in ('EP_FAILURE_MARKER','EP_PASS_RECEIPT_COUNT')},'actual DFlash configuration differs':'SPECULATION_CONFIG_MISMATCH','model argument differs':'MODEL_ARGUMENT_MISMATCH','model mount differs':'MODEL_MOUNT_MISMATCH','serving log mount differs':'LOG_MOUNT_MISMATCH','serving log invalid':'LOG_INVALID','serving log changed':'LOG_CHANGED'})
SAFE_PREFIXES = {'profile default differs: ': 'PROFILE_DEFAULT_MISMATCH', 'deployed source hash differs: ': 'SOURCE_HASH_MISMATCH', 'deployment postdates container start: ': 'SOURCE_POSTDATES_BOOT', 'wrong overlay bind: ': 'OVERLAY_MOUNT_MISMATCH'}
def predicate_error(message):
    if message in SAFE_MESSAGES:
        return NodeRejected(SAFE_MESSAGES[message])
    for prefix, code in SAFE_PREFIXES.items():
        if message.startswith(prefix):
            field = message[len(prefix):]
            # Names only; never include environment values, paths or stderr.
            if re.fullmatch(r'[A-Za-z0-9_.-]{1,160}', field):
                return NodeRejected(code, field)
            return NodeRejected(code)
    return NodeRejected('PREDICATE_REJECTED')

try:

    import base64, datetime, hashlib, json, pathlib, re, shlex, subprocess, sys, time, urllib.request
    p=json.load(sys.stdin)
    exec(compile(p['startup_helpers'],'local/startup_helpers.py','exec'),globals())
    def check(ok, message):
     if not ok: raise predicate_error(message)
    def digest(data): return hashlib.sha256(data).hexdigest()
    def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
    def run(args): return subprocess.check_output(args,text=True,stderr=subprocess.DEVNULL,timeout=15).strip()
    def inspect():
     c=json.loads(run(['docker','inspect',p['name']]))[0]
     check(c['State']['Running'] and not c['State']['Paused'] and not c['State']['Restarting'], 'container not running normally')
     check(not c['State']['OOMKilled'], 'container OOM marker')
     return c
    def identity(c):
     return {k:c[k] for k in ('Id','Image','Created','Config','HostConfig')} | {'Mounts':sorted(c['Mounts'],key=lambda m:json.dumps(m,sort_keys=True)), 'StartedAt':c['State']['StartedAt'],'Pid':c['State']['Pid']}
    def ns(value):
     m=re.fullmatch(r'(.+?)(?:\.(\d{1,9}))?Z',value)
     check(m is not None,'invalid Docker timestamp')
     seconds=int(datetime.datetime.fromisoformat(m[1]).replace(tzinfo=datetime.timezone.utc).timestamp())
     return seconds*10**9+int((m[2] or '').ljust(9,'0'))
    started=time.time()
    STAGE='container-inspect'
    c=inspect(); before=identity(c)
    expected=p['expected_current_boots'][str(p['rank'])]
    check(c['Id']==expected['id'] and c['State']['StartedAt']==expected['started_at'],'container identity changed across snapshot')
    STAGE='image-check'
    check(c['Image']==p['image_id'],'running image differs')
    check(run(['docker','image','inspect','--format','{{.Id}}',p['image']])==p['image_id'],'node image tag differs')
    start_ns=ns(c['State']['StartedAt'])
    check(ns(c['Created'])<=start_ns,'created after start')
    STAGE='launch-parser'
    scope={}; exec(compile(p['parser'],'approved/glm53_launch_metadata.py','exec'),scope)
    topology=scope['launch_parallelism'](c['Config']['Cmd'])
    check((topology['enabled'],topology['tensor_parallel_size'],topology['nnodes'],topology['node_rank'])==(True,4,4,p['rank']),'wrong topology')
    script=base64.b64decode(scope['_WRAPPER'].fullmatch(c['Config']['Cmd'][1])[1]).decode()
    line=script[len(scope['_GID_PRELUDE']):].removesuffix('\n')
    argv=scope['_literal_argv'](line[:-len(scope['_REDIRECTION'])])
    def option(key):
     result=[]
     for i,arg in enumerate(argv):
      if arg==key: result.append(argv[i+1])
      elif arg.startswith(key+'='): result.append(arg[len(key)+1:])
     check(len(result)==1,'missing or duplicate public endpoint option')
     return result[0]
    check(option('--host')=='0.0.0.0' and option('--port')=='8000','wrong public endpoint')
    check(argv[2]==p['model_container'],'model argument differs')
    speculation=scope['launch_speculation'](c['Config']['Cmd'])
    check(speculation.get('method')=='dflash' and type(speculation.get('num_speculative_tokens')) is int and speculation['num_speculative_tokens']==5 and type(speculation.get('node_rank')) is int and speculation['node_rank']==p['rank'] and speculation.get('command_sha256')==topology['command_sha256'] and all(isinstance(speculation.get(k),str) and re.fullmatch('[0-9a-f]{64}',speculation[k]) for k in ('config_sha256','command_sha256')),'actual DFlash configuration differs')
    STAGE='environment'
    env={}
    for row in c['Config'].get('Env',[]):
     key,sep,value=row.partition('=')
     check(bool(sep),'malformed environment')
     check(key not in env or env[key]==value,'conflicting duplicate environment')
     env[key]=value
    for key,value in p['defaults'].items():
     check(env.get(key,'')==value,'profile default differs: '+key)
    check(not (set(k for k in env if k.startswith('VLLM_GLM53_'))-set(p['defaults'])),'extra GLM candidate environment')
    check(env.get('VLLM_GLM53_EP_DECODE_OPT','0')=='0' and env.get('VLLM_GLM53_EP_HYBRID_TP2','0')=='0','extra GLM candidate environment')
    inactive_candidate_flags={k:dict(actual=env.get(k),effective='0',basis='Exact approved EP4 source plus baseline startup keys; absent flags remain recorded as absent') for k in ('VLLM_GLM53_EP_DECODE_OPT','VLLM_GLM53_EP_HYBRID_TP2')}
    try: preparation=preparation_configuration(env)
    except ValueError: raise NodeRejected('PREP_CONFIGURATION_MISMATCH')
    STAGE='mount-table'
    mounts={}
    for m in c['Mounts']:
     check(m['Destination'] not in mounts,'duplicate mount destination')
     mounts[m['Destination']]=m
    model_mount=mounts.get(p['model_container'])
    check(model_mount is not None and model_mount['Type']=='bind' and model_mount['Source']==p['model_host'] and model_mount['RW'] is False,'model mount differs')
    directory=pathlib.Path(p['directory'])
    def files():
     out={}
     for name,want in p['files'].items():
      f=directory/name
      check(f.resolve()==f and f.is_file(),'deployed source is not a regular local path')
      st=f.stat(); data=f.read_bytes(); end=f.stat()
      check((st.st_ino,st.st_size,st.st_mtime_ns)==(end.st_ino,end.st_size,end.st_mtime_ns),'file changed during read')
      check(digest(data)==want,'deployed source hash differs: '+name)
      check(st.st_mtime_ns<=start_ns,'deployment postdates container start: '+name)
      out[name]=[digest(data),st.st_size,st.st_mtime_ns,st.st_ino]
     return out
    STAGE='source-files'
    first_files=files()
    STAGE='source-mounts'
    for name,target in p['targets'].items():
     m=mounts.get(target)
     check(m is not None and m['Type']=='bind' and m['Source']==str(directory/name) and m['RW'] is False,'wrong overlay bind: '+name)
    STAGE='head-stamp'
    if p['rank']==0:
     stamp=pathlib.Path('/home/choiceoh/glm53-cache/.overlay-sha')
     check(stamp.read_text().strip()==p['files']['manifest.tsv'],'head boot stamp differs')
     check(stamp.stat().st_mtime_ns<=start_ns,'head boot stamp postdates start')
     STAGE='head-cache-receipt'
     cache=json.loads(pathlib.Path('/home/choiceoh/glm53-cache/.compile-overlay.json').read_text())
     check(cache['version']==1 and cache['deployment_sha256']==p['files']['manifest.tsv'],'head compile receipt differs')
    STAGE='startup-log'
    import stat
    log_mount=mounts.get('/glmlogs')
    check(log_mount is not None and log_mount['Type']=='bind' and log_mount['Source']=='/home/choiceoh/glm53-logs','serving log mount differs')
    log_path=pathlib.Path(log_mount['Source'])/'glm53.log'
    a=log_path.lstat()
    check(stat.S_ISREG(a.st_mode) and log_path.resolve()==log_path and 0<a.st_size<=128*2**20 and a.st_mtime_ns>=start_ns,'serving log invalid')
    with log_path.open('rb') as stream: log_bytes=stream.read(a.st_size)
    b=log_path.lstat()
    check(len(log_bytes)==a.st_size and (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino) and b.st_size>=a.st_size,'serving log changed')
    check(b'[ep-tiled-selftest] FAIL' not in log_bytes and not re.search(rb'\[ep-tiled-sf6\]\s+(?:FAIL|FAILED|ERROR)',log_bytes),'EP_FAILURE_MARKER')
    # Only complete lines enter JSON parsing; any incomplete target receipt is rejected.
    log_text=log_bytes.decode('utf-8',errors='replace')
    if not preparation_log_clean(log_text): raise NodeRejected('PREP_FAILURE_MARKER')
    if not log_text.endswith('\n'):
     tail=log_text.rsplit('\n',1)[-1]
     if '[prep-fused]' in tail: raise NodeRejected('PREP_FAILURE_MARKER')
     check(not any(marker in tail for marker in ('[ep-tiled-selftest]','[ep-tiled-sf6]')),'EP_PASS_RECEIPT_COUNT')
     log_text=log_text.rsplit('\n',1)[0]+'\n' if '\n' in log_text else ''
    STAGE='startup-receipts'
    proof={'__name__':'approved_public_startup_proof','__file__':'approved/bench/proof.py'}
    exec(compile(p['proof'],'approved/bench/proof.py','exec'),proof)
    try: startup=ep_startup_evidence(log_text,p['canary_sources'],start_ns/1e9,time.time(),proof)
    except ValueError as exc: raise NodeRejected(str(exc) if str(exc) in p['startup_codes'] else 'EP_RECEIPT_REJECTED')
    # Preserve the entire captured prefix; append is allowed, overwrite/truncate is not.
    STAGE='startup-log-postcheck'
    with log_path.open('rb') as stream: second_prefix=stream.read(a.st_size)
    d=log_path.lstat()
    check((a.st_dev,a.st_ino)==(d.st_dev,d.st_ino) and d.st_size>=a.st_size and second_prefix==log_bytes,'serving log changed')
    startup['log_prefix_sha256']=digest(log_bytes)
    startup['log_prefix_bytes']=len(log_bytes)
    startup['log_inode']=a.st_ino
    STAGE='source-postcheck'
    check(first_files==files(),'deployed files changed across snapshot')
    STAGE='head-health'
    if p['rank']==0:
     with urllib.request.urlopen('http://127.0.0.1:8000/health',timeout=5) as response:
      check(response.status==200,'public head health failed')
    STAGE='container-postcheck'
    after=inspect(); check(before==identity(after),'container identity changed across snapshot')
    print(json.dumps({'rank':p['rank'],'node':p['node'],'id':c['Id'],'created_at':c['Created'],'started_at':c['State']['StartedAt'],'image':c['Image'],'source':p['source'],'manifest_sha256':p['files']['manifest.tsv'],'file_count':len(p['targets']),'files_equal_approved':True,'mounts_readonly_exact':True,'mtimes_precede_start':True,'defaults_match':True,'inactive_candidate_flags':inactive_candidate_flags,'preparation':preparation,'speculation':speculation,'startup':startup,'topology':topology,'identity_sha256':digest(canonical(before)),'files_metadata_sha256':digest(canonical(first_files)),'started':started,'finished':time.time(),'verdict':'PASS'}))

except Exception as exc:
    if isinstance(exc, NodeRejected):
        code, field = exc.code, exc.field
    else:
        field = None
        code = ('FILE_MISSING' if isinstance(exc, FileNotFoundError) else
                'PERMISSION_DENIED' if isinstance(exc, PermissionError) else
                'READ_COMMAND_TIMEOUT' if isinstance(exc, subprocess.TimeoutExpired) else
                'READ_COMMAND_FAILED' if isinstance(exc, subprocess.CalledProcessError) else
                'PARSE_REJECTED' if isinstance(exc, (ValueError, KeyError, TypeError, IndexError)) else
                'UNEXPECTED_NODE_EXCEPTION')
    record = dict(verdict='REJECTED', code=code, stage=STAGE)
    if field is not None:
        record['field'] = field
    print(json.dumps(record,sort_keys=True),flush=True)
    raise SystemExit(1)
'''


def run(args, *, cwd=CONTROLLER):
    return subprocess.check_output(args, cwd=cwd, text=True,
                                   stderr=subprocess.DEVNULL, timeout=120).strip()


def literal(profile, key):
    rows = re.findall(r'^' + re.escape(key) + r'=(.*)$', profile, re.M)
    if len(rows) == 1 and rows[0] == '':
        return ''
    words = shlex.split(rows[0], comments=True) if len(rows) == 1 else []
    if len(words) != 1 or '$' in words[0] or '`' in words[0]:
        raise ValueError('unsupported profile declaration: ' + key)
    return words[0]


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--receipt', required=True)
    ap.add_argument('--approved-source', required=True, help='full merged recovery source; placeholders rejected before any reads')
    ap.add_argument('--controller-source', required=True,
                    help='separately approved full controller commit; may differ from recovery source')
    args = ap.parse_args()
    begun = time.time()
    APPROVED = args.approved_source
    if not re.fullmatch(r'[a-f0-9]{40}', APPROVED) or APPROVED=='0'*40:
        raise ValueError('full approved source required; placeholders are refused')
    if not re.fullmatch(r'[a-f0-9]{40}', args.controller_source) or args.controller_source=='0'*40:
        raise ValueError('full controller source required')
    if run(['git', 'rev-parse', 'HEAD']) != args.controller_source or run(['git', 'status', '--porcelain']):
        raise ValueError('central controller is not clean approved source')
    approved = json.loads(run(['python3', '-B', str(CONTROLLER/'bench/fleet_validation.py'),
                              'verify-recovery', '--receipt', args.receipt, '--format', 'json']))
    if approved['source'] != APPROVED:
        raise ValueError('recovery receipt selects another source')
    repo = Path(approved['repo']).resolve()
    sys.path.insert(0, str(repo/'bench'))
    import onepass_deploy as deployment
    if deployment.source_revision(repo) != APPROVED:
        raise ValueError('approved checkout source differs')
    directory = deployment.overlay_directory(repo, {})
    deployed = deployment.deployed(repo, directory, APPROVED)
    if not deployed:
        raise ValueError('head deployment differs from approved source')
    selected = deployment.selected_manifest(repo, deployment.selected_modules(repo))
    if len(selected) != EXPECTED_MOUNTED_FILES:
        raise ValueError('approved selected mounted-file count differs')
    files = {name: hashlib.sha256((directory/name).read_bytes()).hexdigest()
             for name in ('manifest.tsv', *selected)}
    profile = (repo/'profiles/glm53.env').read_text()
    defaults = {key: literal(profile, key) for key in re.findall(r'^(VLLM_[A-Z0-9_]+)=', profile, re.M)}
    defaults['VLLM_GLM53_SPEC_K'] = literal(profile, 'SPEC_K')
    if (literal(profile,'ENABLE_EP'), defaults.get('VLLM_GLM53_EP_TILED'), defaults.get('VLLM_GLM53_TP_SF6_Q0')) != ('1','1','0'):
        raise ValueError('approved EP default triple differs')
    if literal(profile,'SPEC_K') != '5':
        raise ValueError('approved EP DFlash K differs')
    if defaults.get('VLLM_GLM53_B12X_STATIC_V2') != 't,r,sf6':
        raise ValueError('approved SF6 static mode differs')
    if defaults.get('VLLM_GLM53_PREP_FUSED') != '1':
        raise ValueError('approved PREP default differs')
    image = literal(profile, 'PROFILE_IMAGE')
    image_id = run(['docker', 'image', 'inspect', '--format', '{{.Id}}', image])
    if image_id != PINNED_IMAGE:
        raise ValueError('invalid profile image identity')
    canary_sources={row[0]:files[name] for name,row in selected.items()}
    # Stock gated source is image-owned, not an overlay. It is pinned by the candidate's source contract.
    canary_sources['/usr/local/lib/python3.12/dist-packages/flashinfer/fused_moe/cute_dsl/blackwell_sm12x/_moe_dynamic/gated.py']='993783308233288ddfa77293e9dbabdc825ba5bfdcc4dcc41e842a895ec33445'
    payload = dict(expected_current_boots=EXPECTED_CURRENT_BOOTS,directory=str(directory), source=APPROVED, defaults=defaults,
                   image=image, image_id=image_id, files=files,
                   model_host=literal(profile,'PROFILE_MODEL_PATH'),model_container='/models/glm-5.3-flash-nvfp4',
                   proof=(repo/'bench/proof.py').read_text(),startup_helpers=STARTUP_HELPERS,
                   startup_codes=STARTUP_CODES,canary_sources=canary_sources,
                   targets={name: row[0] for name, row in selected.items()},
                   parser=(repo/'bench/glm53_launch_metadata.py').read_text())
    nodes = [(0, '10.10.10.2'), (1, '10.10.10.1'), (2, '10.10.10.3'), (3, '10.10.10.4')]
    def sample(item):
        rank, node = item
        command = ['python3', '-B', '-c', NODE]
        if rank:
            command = ['ssh', '-T', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=5',
                       'choiceoh@'+node, shlex.join(command)]
        result = subprocess.run(command, input=json.dumps(dict(payload, rank=rank, node=node,
                                name='glm53' if rank==0 else 'glm53-worker')),
                                capture_output=True, text=True, timeout=90)
        if result.returncode:
            error = dict(rank=rank, node=node, verdict='REJECTED',
                         code='NODE_NO_SAFE_RECEIPT', stage='input', exit_code=result.returncode)
            try:
                value = json.loads(result.stdout)
                if (isinstance(value, dict) and value.get('verdict') == 'REJECTED'
                        and value.get('code') in SAFE_NODE_CODES
                        and value.get('stage') in SAFE_NODE_STAGES
                        and set(value) <= {'verdict','code','stage','field'}):
                    error.update(code=value['code'],stage=value['stage'])
                    field = value.get('field')
                    if (isinstance(field,str) and re.fullmatch(r'[A-Za-z0-9_.-]{1,160}',field)
                            and (field in payload['defaults'] or field in payload['files'])):
                        error['field'] = field
            except (ValueError, TypeError):
                pass
            # Never render subprocess stderr or an unknown failure payload.
            return error
        value = json.loads(result.stdout)
        if value.get('verdict') != 'PASS' or value.get('rank') != rank or value.get('node') != node:
            return dict(rank=rank,node=node,verdict='REJECTED',code='NODE_RECEIPT_INVALID',stage='input')
        return value
    with ThreadPoolExecutor(max_workers=4) as pool:
        nodes_result = list(pool.map(sample, nodes))
    rejected = [row for row in nodes_result if row['verdict'] != 'PASS']
    if rejected:
        print(json.dumps(dict(verdict='REJECTED',source=APPROVED,
                              controller_source=args.controller_source,nodes=nodes_result,
                              scope='bounded verifier result; rejected node reasons are allowlisted and contain no raw config or stderr'),sort_keys=True))
        return 1
    approved_after=json.loads(run(['python3','-B',str(CONTROLLER/'bench/fleet_validation.py'),'verify-recovery','--receipt',args.receipt,'--format','json']))
    if approved_after != approved:
        raise ValueError('authenticated recovery receipt changed during snapshot')
    if deployment.source_revision(repo) != APPROVED or deployment.deployed(repo, directory, APPROVED) != deployed:
        raise ValueError('approved source or head deployment changed during snapshot')
    if run(['git', 'rev-parse', 'HEAD']) != args.controller_source or run(['git', 'status', '--porcelain']):
        raise ValueError('central controller changed during snapshot')
    print(json.dumps(dict(verdict='PASS', source=APPROVED, controller_source=args.controller_source, receipt=args.receipt,
                          started=begun, finished=time.time(), nodes=nodes_result,
                          public_head_health=200, preparation_execution_acceptance=False, startup_numerics='4 ranks x 72 candidate checks', sf6_finalized_layers_per_rank=42, performance_acceptance=False, scope='four approved EP boot/source/config/startup snapshots plus head health; no inference, performance, sanitizer, or other-service continuity claim'),
                     sort_keys=True))


if __name__ == '__main__':
    try:
        raise SystemExit(main() or 0)
    except Exception as exc:
        # Exceptions generated by this helper are safe; third-party exceptions
        # may embed subprocess argv or file content and must stay private.
        message = type(exc).__name__
        print(json.dumps({'verdict':'REJECTED','reason':message}), flush=True)
        raise SystemExit(1)
