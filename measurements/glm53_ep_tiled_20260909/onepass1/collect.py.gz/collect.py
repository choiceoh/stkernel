#!/usr/bin/env python3
"""Read-only collection of the terminal, failed canonical EP tiled SF6 attempt."""
import base64,gzip,hashlib,json,os,stat,subprocess,time
from pathlib import Path
ROOT=Path('/Users/ost/.worktrees/stkernel2/glm53-prefill-moe-pipeline-20260908')
DEST=ROOT/'measurements/glm53_ep_tiled_20260909/onepass1'
REV='f6b0934eb3d14b46cc58c29f6c9983f776eed250'
SESSION='eptiledsf60909v1';TICKET='17889403431195582';PID=1195582;START='44273126'
JOB='/tmp/glm53-ep-tiled-sf6-onepass-0909-1';SOURCE='/home/choiceoh/stkernel-ep-tiled-0909-sf6'
NODES=('local','10.10.10.1','10.10.10.3','10.10.10.4')
SNAPS={'B1':'/tmp/glm53-ep-tiled-sf6-onepass1-live-B1-ready-b879815e1127','A':'/tmp/glm53-ep-tiled-sf6-onepass1-live-A-ready-013297457bbb'}
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def read(p):
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode) and a.st_size<=32*2**20,'unsafe/large file '+str(p));b=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns),'file changed '+str(p));return b
REMOTE=r'''
from pathlib import Path
import base64,gzip,hashlib,json,os,stat,subprocess,time
sha=lambda b:hashlib.sha256(b).hexdigest()
def need(ok,msg):
 if not ok:raise RuntimeError(msg)
def read(p):
 p=Path(p);a=p.lstat();need(stat.S_ISREG(a.st_mode) and a.st_size<=32*2**20,'unsafe/large file');b=p.read_bytes();z=p.lstat();need((a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns)==(z.st_dev,z.st_ino,z.st_size,z.st_mtime_ns),'file changed');return b
def cmd(args):return subprocess.check_output(args,stderr=subprocess.DEVNULL,timeout=20)
f=Path('/home/choiceoh/glm53-logs/fleet');j=Path(job);s=Path(source);raw={}
pending_path=f/'pending'/(sha(session.encode())+'.json');pb=read(pending_path);p=json.loads(pb)
need(p['session']==session and str(p['ticket'])==ticket and p['pid']==pid and str(p['start'])==start,'wrong reservation')
need(p['state']=='finished' and p['phase']=='finished' and p['returncode']==4 and p['payload_returncode']==4,'not expected terminal failure')
holder=(f/'holder').read_text() if (f/'holder').exists() else None
need(holder is None or holder.split('|')[:2]!=[session,str(pid)],'still owned')
need(cmd(['git','-C',source,'rev-parse','HEAD']).decode().strip()==revision,'source HEAD differs')
need(not cmd(['git','-C',source,'status','--porcelain','--untracked-files=no']).strip(),'source dirty')
raw['lifecycle/pending.json']=pb
for name in ('submission.json','submit.exit.json','submit.stdout','submit.stderr','onepass.jsonl','verdicts.jsonl','cpu2/result.json','cpu2/contracts.json'):
 raw['job/'+name]=read(j/name)
runlog=f/'run-logs'/(sha((session+'\0'+ticket).encode())+'.log')
raw['lifecycle/run.log']=read(runlog)
for arm in ('B0','B1','A'):raw['head/boot-EPTILEDSF6'+arm+'.log']=read(Path('/home/choiceoh/glm53-logs')/('boot-EPTILEDSF6'+arm+'.log'))
for name in ('idle-recovery.json','runner-idle-recovery-20260909.json'):
 if (f/name).exists():raw['lifecycle/'+name]=read(f/name)
manifest=read(s/'build/glm53/manifest.tsv');raw['source/manifest.tsv']=manifest
mounted={}
for line in manifest.decode().splitlines():
 if not line or line.startswith('#'):continue
 name,target,group=line.split('\t');need('/'not in name and name not in ('.','..') and target not in mounted,'unsafe manifest')
 b=read(s/'build/glm53'/name);need(b==cmd(['git','-C',source,'show',revision+':build/glm53/'+name]),'mounted source differs from git')
 mounted[target]=sha(b)
 if name in selected:raw['source/'+name]=b
for rel in ('bench/onepass.py','bench/bracket.py','bench/chain.sh','bench/ab-lever.sh','bench/glm53_launch_metadata.py','bench/proof.py','bench/judge.py','profiles/glm53.env'):
 b=read(s/rel);need(b==cmd(['git','-C',source,'show',revision+':'+rel]),'frozen source differs');raw['source/'+rel]=b
need(read(pending_path)==pb,'terminal record changed while reading')
for rel in ('onepass.jsonl','verdicts.jsonl'):need(read(j/rel)==raw['job/'+rel],'final results changed')
need(cmd(['git','-C',source,'rev-parse','HEAD']).decode().strip()==revision,'source HEAD changed')
state={'at':time.time(),'session':session,'ticket':ticket,'owner_pid':pid,'owner_start_tick':start,'own_holder':False,'holder':holder,'returncode':4,'payload_returncode':4,'phase':p['phase'],'state':p['state'],'finished_at':p['finished_at'],'recovery_policy':p.get('recovery_policy'),'recovery_deferred':p.get('recovery_deferred'),'public_recovery_health_verified':False,'scope':'read-only terminal snapshot; current idle state is not proof of public endpoint health','source':source,'revision':revision,'mounted_sources':mounted}
print(json.dumps({'state':state,'files':{k:{'sha256':sha(v),'bytes':len(v),'gzip':base64.b64encode(gzip.compress(v,mtime=0)).decode()}for k,v in raw.items()}}))
'''

def main():
 os.umask(0o077);need(not DEST.exists(),'archive exists')
 snapshots={a:json.loads(read(Path(p)/'identity.json'))for a,p in SNAPS.items()}
 selected={Path(v['path']).name for v in extract_canary(Path(SNAPS['A'])/'local.serving.log.gz')['source']['source'].values()}
 code='session='+repr(SESSION)+'\nticket='+repr(TICKET)+'\npid='+repr(PID)+'\nstart='+repr(START)+'\njob='+repr(JOB)+'\nsource='+repr(SOURCE)+'\nrevision='+repr(REV)+'\nselected='+repr(selected)+'\n'+REMOTE
 r=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','choiceoh@srv2','python3 -B -'],input=code.encode(),capture_output=True,timeout=90)
 need(r.returncode==0,'remote collection failed: '+r.stderr.decode(errors='replace')[-2000:]);obj=json.loads(r.stdout)
 raw={}
 for name,v in obj['files'].items():
  b=gzip.decompress(base64.b64decode(v['gzip'],validate=True));need(len(b)==v['bytes'] and sha(b)==v['sha256'],'transport hash differs');raw[name]=b
 need(raw['job/onepass.jsonl']==read('/tmp/glm53-ep-tiled-sf6-onepass1-final-records.jsonl'),'root final record copy differs')
 records=[json.loads(l) for l in raw['job/onepass.jsonl'].splitlines()];need([v['name'] for v in records]==['EPTILEDSF6B0','EPTILEDSF6B1','EPTILEDSF6A'],'unexpected arms/order')
 need(all(v['git']==REV[:8] and v['session']==SESSION and v['korean']['dirty']==1 and v['quality']=={'ok':18,'total':18} for v in records),'record identity/quality differs')
 need(b'defaults arm EPTILEDSF6ABASE' not in raw['lifecycle/run.log'],'ABASE unexpectedly ran')
 rows=[];canaries={};binding={}
 for arm,identity in snapshots.items():
  base=Path(SNAPS[arm]);need(identity['revision']==REV and identity['ticket']==TICKET and identity['owner_pid']==str(PID),'snapshot experiment differs')
  record=next(v for v in records if v['name']=='EPTILEDSF6'+arm)
  need(record['boot_id']==identity['nodes']['local']['id']+'|'+identity['nodes']['local']['started_at'],'measurement boot not snapshot boot')
  for n,v in identity['nodes'].items():
   need(v['source']['mounts']==obj['state']['mounted_sources'],'snapshot sources not frozen source')
   need(v['running_start_config_stable'] and v['readiness']['graph_finished'] and len(v['readiness']['startup_trim_records'])==1,'snapshot not ready')
   before=json.loads(gzip.decompress(read(base/(n+'.inspect.before.json.gz'))))[0];after=json.loads(gzip.decompress(read(base/(n+'.inspect.after.json.gz'))))[0]
   need(fixed(before)==fixed(after),'private config/start drift')
   for suffix in ('serving.log','docker.log','manifest.tsv'):
    rel=n+'.'+suffix+'.gz';packed=read(base/rel);entry=identity['files'][rel]
    need(sha(packed)==entry['stored_sha256'] and sha(gzip.decompress(packed))==entry['original_sha256'],'snapshot original or stored hash differs')
    raw['snapshots/'+arm+'/'+n+'.'+suffix]=gzip.decompress(packed)
   if arm=='A':
    c=extract_canary(base/(n+'.serving.log.gz'));need(c['verdict']=='PASS' and c['phase']=='complete' and c['actual_packed_owner'] and c['caller_preserved'],'canary incomplete')
    need(c['packed_before']==c['packed_after'],'packed owner changed')
    names=['mixed6','balanced12','concentrated24','zeros32','remote33','balanced2128','balanced4096','concentrated6912','balanced8192']
    need([x['case']for x in c['cases']]==names,'canary fixtures differ')
    for cell in c['cases']:
     need(cell['verdict']=='PASS' and cell['phase']=='complete' and len(cell['candidate'])==6 and all(z['bad_rows']==0 for z in cell['candidate']),'candidate numeric failure/missing')
     need(len(cell['controls'])==2 and all(len(g)==3 and all(z['bad_rows']==0 for z in g) for g in cell['controls']),'control failure/missing')
    for value in c['source']['source'].values():
     if value['path'] in obj['state']['mounted_sources']:need(value['sha256']==obj['state']['mounted_sources'][value['path']],'canary source differs')
     else:need(value['sha256']=='993783308233288ddfa77293e9dbabdc825ba5bfdcc4dcc41e842a895ec33445','unexpected unmounted canary source')
    fin=v['readiness']['ep_sf6_finalized_records'];need(len(fin)==1 and fin[0]['receipt']=={'format':'sf6_v1','layers':42,'packed_bytes':3604414464,'packed_only':True,'raw_bytes_released':4756340736,'storage_bytes_saved':1151926272},'SF6 finalization differs')
    raw['canary/'+n+'.json']=json_bytes(c);canaries[n]={'candidate_checks':54,'control_checks':54,'verdict':'PASS','receipt_sha256':sha(json_bytes(c)),'finalized':fin[0]['receipt']}
  raw['snapshots/'+arm+'/identity.json']=read(base/'identity.json')
  raw['snapshots/'+arm+'/launch-parser.py']=read(base/'launch-parser.py')
  binding[arm]={'identity_sha256':sha(read(base/'identity.json')),'boot_matches_record':True,'private_full_config_before_after_exact':True,'all_71_mounted_sources_exact':True}
 for v in records:
  fixeds=[x for x in v['requests'] if x.get('fixed_decode')];need(len(fixeds)==3 and [x['rep']for x in fixeds]==[0,1,2] and all(x['completion_tokens']==1024 and x['min_tokens']==x['max_tokens']==1024 for x in fixeds),'fixed1024 incomplete')
  pooled=sum(x['completion_tokens']-1 for x in fixeds)/sum(x['decode_s']for x in fixeds)
  rows.append({'arm':v['name'],'cold_compile':v.get('cold_compile',False),'quality':v['quality'],'korean':v['korean'],'prefill':v['prefill'],'fixed_tok_s':[x['decode_tok_s']for x in fixeds],'fixed_pooled_tok_s':pooled,'fixed_pooled_step_s':v['decode']['fixed_pooled_step_s'],'request_hashes':[x['request_sha256']for x in fixeds],'quality_acceptance':False})
 events=[]
 for directory,tag in [('/tmp/glm53-ep-tiled-sf6-onepass1-streams','streams'),('/tmp/glm53-ep-tiled-sf6-onepass1-abase-observer','abase-observer')]:
  d=Path(directory);pid=int(read(d/'observer.pid'))
  try:os.kill(pid,0)
  except ProcessLookupError:pass
  else:raise RuntimeError('observer still running')
  es=[json.loads(l)for l in read(d/'events.jsonl').splitlines()];need(es[-1]['kind']=='observer_finished','observer not closed')
  for p in d.iterdir():
   if p.name.endswith('.raw') or p.name in ('events.jsonl','helper-identity.json') or p.suffix=='.py':raw[tag+'/'+p.name]=read(p)
  events.append({'pid':pid,'kind':tag,'finished':es[-1],'stream_end':[x for x in es if x['kind']=='stream_end']})
 # Preserve the rejected early capture; never promote it into valid boot evidence.
 raw['collection-error/A-initial-prepared-failure.log']=read('/tmp/glm53-ep-tiled-sf6-onepass1-live-A-prepared-013297457bbb/failure.private.log')
 summary={'schema':1,'experiment':SESSION,'revision':REV,'verdict':'FAIL','canonical_exit':4,'performance_acceptance':False,'decode_nonregression':False,'quality_acceptance':False,'ep_tiled_sf6_startup_and_storage_proof':'PASS','B0_four_rank_snapshot_available':False,'ABASE_ran':False,'snapshots':binding,'canaries':canaries,'arms':rows,'observers':events,'terminal':obj['state'],'scope':'Descriptive measurements only: every arm fails the existing Korean gate; B0 is cold and has unstable step rate. No new GPU/HTTP work; no gate relaxation. CPU capsule and serving CUDA package versions are distinct.'}
 raw['summary.json']=json_bytes(summary)
 DEST.mkdir(parents=True,exist_ok=False);manifest={}
 for name,b in sorted(raw.items()):
  relative=Path(name);need(not relative.is_absolute() and '..'not in relative.parts,'unsafe archive path')
  compress=relative.suffix in ('.log','.raw','.py','.sh','.jsonl') or name.startswith('source/')
  stored=gzip.compress(b,mtime=0) if compress else b;target=DEST/(name+'.gz' if compress else name);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(stored)
  manifest[str(target.relative_to(DEST))]={'original_sha256':sha(b),'original_bytes':len(b),'stored_sha256':sha(stored),'stored_bytes':len(stored),'gzip':compress}
 (DEST/'manifest.json').write_bytes(json_bytes({'schema':1,'files':manifest,'scope':'Original bytes are unchanged. Deterministic gzip only; raw Docker inspect/Env/Cmd excluded; their original hashes remain in strict snapshot identity.'}))
 b1=rows[1];a=rows[2]
 table='\n'.join('| '+r['arm']+' | '+', '.join(f'{n:.2f}'for n in r['fixed_tok_s'])+f" | {r['fixed_pooled_tok_s']:.2f} | {r['fixed_pooled_step_s']:.3f} | 18/18 | 1/8 |"for r in rows)
 readme=f'''# EP tiled + SF6 canonical onepass 1 — FAIL\n\nFrozen source `{REV}`; session `{SESSION}`, ticket `{TICKET}`, owner `{PID}`/start `{START}`. The canonical B0 → B1 → A run ended with payload/outer status **4** at 2026-09-09 17:19:58 KST. Every arm passed factual checks 18/18 and failed the existing Korean gate 1/8 (two CJK characters). ABASE did not run. No gate or result was changed.\n\n| Arm | Fixed1024 tok/s, three requests | Pooled tok/s | Fixed-window step/s | Facts | Korean dirty |\n|---|---|---:|---:|---:|---:|\n{table}\n\nDecode non-regression is not established: A is {(a['fixed_pooled_tok_s']/b1['fixed_pooled_tok_s']-1)*100:.2f}% versus B1 in direct pooled tok/s and {(a['fixed_pooled_step_s']/b1['fixed_pooled_step_s']-1)*100:.2f}% in fixed-window step/s. B0 is cold and its step rate dropped during the fixed requests; it is not a valid acceptance baseline. All rows above are descriptive because all arms failed quality. Speculative acceptance counters cover the whole onepass window and must not be treated as exact fixed-request acceptance.\n\nA prefill observations: actual 2,128 tokens warm TTFT {a['prefill'][0]['warm_s']:.6f}s / {a['prefill'][0]['warm_tok_s']:.2f} tok/s; 32,545 tokens single combined-request TTFT {a['prefill'][1]['cold_s']:.6f}s / {a['prefill'][1]['cold_tok_s']:.2f} tok/s; 128,559 tokens single combined-request TTFT {a['prefill'][2]['cold_s']:.6f}s / {a['prefill'][2]['cold_tok_s']:.2f} tok/s. These observations do not establish an accepted performance improvement.\n\nFour A ranks emitted complete 9-case startup canary PASS receipts (54 candidate and 54 control comparisons per rank), exact packed-owner preservation, graph capture and startup-trim completion. Each rank finalized 42 SF6 owners: 4,756,340,736 raw bytes released, 3,604,414,464 packed bytes retained, 1,151,926,272 bytes saved. The EP tiled serving lane proof passed 1/1. This is startup numerical/ownership/storage evidence, not sanitizer or throughput acceptance.\n\nB1 and A four-rank ready snapshots bind exact container/start/image/runtime command identity and all 71 mounted-source hashes to the frozen source. B0's head boot log and canonical record were retained, but no four-rank B0 snapshot was captured. A's first prepared snapshot rejected an empty startup log; the failure is retained separately. Raw private Docker inspect/Env/Cmd are excluded.\n\nBoth passive observers exited on terminal/release; their original events and raw stream chunks are preserved with source scripts. Streams include multiple boots and are explicitly unassigned until matched to strict boot snapshots. The fleet holder was absent at collection; recovery was deferred to the idle controller. The captured idle state is not a public health check, and public recovery completion is not claimed.\n\n`job/` keeps the original onepass, verdict, submission and CPU2 receipts; `source/` keeps exact selected mounted/canonical source bytes and the full manifest; `snapshots/`, `canary/`, `head/`, and `streams/` retain runtime evidence. `manifest.json` records original and stored byte counts/SHA-256. Logs, source and JSONL use deterministic gzip with unchanged original bytes. No new benchmark, HTTP request, compilation or service mutation was performed by this collector.\n'''
 (DEST/'README.md').write_text(readme)
 sums=''.join(sha(read(p))+'  '+str(p.relative_to(DEST))+'\n'for p in sorted(DEST.rglob('*'))if p.is_file())
 (DEST/'SHA256SUMS').write_text(sums)
 print(json.dumps({'archive':str(DEST),'files':len(manifest),'bytes':sum(v['stored_bytes']for v in manifest.values()),'summary_sha256':sha(read(DEST/'summary.json')),'manifest_sha256':sha(read(DEST/'manifest.json')),'terminal':{k:obj['state'][k]for k in ('returncode','payload_returncode','own_holder','recovery_deferred')}}))

def json_bytes(v):return (json.dumps(v,indent=2,sort_keys=True)+'\n').encode()
def fixed(c):return {k:c[k]for k in ('Id','Created','Image','Config','HostConfig','RestartCount')}|{'Mounts':sorted(c['Mounts'],key=lambda v:json.dumps(v,sort_keys=True)),'StartedAt':c['State']['StartedAt'],'Pid':c['State']['Pid']}
def extract_canary(path):
 b=gzip.decompress(read(path));need(b'[ep-tiled-selftest] FAIL 'not in b,'canary FAIL marker');out=[]
 for l in b.splitlines():
  if b'[ep-tiled-selftest] PASS 'in l:out.append(json.JSONDecoder().raw_decode(l.split(b'[ep-tiled-selftest] PASS ',1)[1].decode())[0])
 need(len(out)==1,'missing/duplicate canary');return out[0]
if __name__=='__main__':main()
