#!/usr/bin/env python3
"""Owned completed-row -> unchanged strict snapshot; no workload or fleet mutation."""
import ast, base64, hashlib, json, os, signal, subprocess, sys, threading, time
from pathlib import Path
OBS=Path('/tmp/glm53_ep_prep_observer7.py')
SNAP=Path('/tmp/glm53_ep_prep_snapshot7.py')
OUT=Path('/tmp/glm53-ep-prep-onepass7-completed-snapshots')
SESSION='eptiledprep0910v7'
REV='96a8cab45a1eb049298315a77ed881ee74f04f9b'
TICKET='1788996973440247'
OWNER_PID='440247'
START='49936373'
SOURCE='/home/choiceoh/stkernel-ep-tiled-0909-ring'
JOB='/tmp/glm53-ep-prep-onepass-0910-7'
ARMS=('S','B','A','ABASE')
REMOTE=r'''
s=state()
p=pathlib.Path(job+'/onepass.jsonl')
out={'status':s,'records':None,'head':None}
if p.exists():
 a=p.lstat()
 if not __import__('stat').S_ISREG(a.st_mode) or a.st_size>4*2**20:raise RuntimeError('unsafe/oversized canonical rows')
 with p.open('rb') as f:raw=f.read(a.st_size)
 b=p.lstat()
 if len(raw)!=a.st_size or (a.st_dev,a.st_ino)!=(b.st_dev,b.st_ino) or b.st_size<a.st_size:raise RuntimeError('canonical file changed identity')
 # Only whole appended rows are completed. Preserve the exact complete prefix.
 raw=raw if raw.endswith(b'\n') else (raw.rsplit(b'\n',1)[0]+b'\n' if b'\n' in raw else b'')
 digest=hashlib.sha256(raw).hexdigest()
 if raw and digest!=last_digest:
  rows=[json.loads(line) for line in raw.splitlines() if line.strip()]
  expected=['EPTILEDPREP7'+arm for arm in ('S','B','A','ABASE')]
  if (not rows or len(rows)>4 or any(type(row) is not dict for row in rows)
      or [r.get('name') for r in rows]!=expected[:len(rows)]
      or any(r.get('session')!=session or r.get('git') not in (revision,revision[:8]) for r in rows)):
   raise RuntimeError('canonical completed prefix identity differs')
  out['records']={'sha256':digest,'bytes':len(raw),'data':base64.b64encode(raw).decode(),
                  'last':{k:rows[-1].get(k) for k in ('name','boot_id','session','git')}}
  if s['own'] and s['go'] and not s['terminal']:
   try:
    event=current_arm_event(session,ticket,owner_pid)
    c=json.loads(subprocess.check_output(['docker','inspect','glm53'],stderr=subprocess.DEVNULL,timeout=8))[0]
    dt=__import__('datetime').datetime
    born=dt.fromisoformat(c['State']['StartedAt'].replace('Z','+00:00')).timestamp()
    created=dt.fromisoformat(c['Created'].replace('Z','+00:00')).timestamp()
    row=rows[-1]
    if (row['name']!='EPTILEDPREP7'+event['arm'] or row.get('boot_id')!=c['Id']+'|'+c['State']['StartedAt']
        or not c['State']['Running'] or not born>=created>=event['started_at']):
     raise RuntimeError('completed row is not current fresh arm/container')
    if current_arm_event(session,ticket,owner_pid)['key']!=event['key']:raise RuntimeError('arm changed before snapshot dispatch')
    out['head']={'arm':event['arm'],'id':c['Id'],'started_at':c['State']['StartedAt'],'arm_event_key':event['key']}
   except Exception as exc:out['capture_declined']=type(exc).__name__+': '+str(exc)
print(json.dumps(out))
'''
def literals(path):
 tree=ast.parse(path.read_bytes());result={}
 for node in tree.body:
  if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
   try:result[node.targets[0].id]=ast.literal_eval(node.value)
   except (ValueError,TypeError):pass
 return result

def main():
 os.umask(0o077)
 constants=literals(OBS);snap=literals(SNAP)
 exact={'SESSION':SESSION,'REV':REV,'TICKET':TICKET,'OWNER_PID':OWNER_PID,'OWNER_START_TICK':START,'SOURCE':SOURCE}
 for key,value in exact.items():
  if constants.get(key)!=value:raise RuntimeError('bound observer differs: '+key)
 for key in ('REV','TICKET','OWNER_PID','OWNER_START_TICK','SOURCE'):
  if snap.get(key)!=exact[key]:raise RuntimeError('bound snapshot differs: '+key)
 common=constants['COMMON'];ast.parse(common);ast.parse(REMOTE)
 OUT.mkdir(mode=0o700,exist_ok=False)
 (OUT/'watcher.pid').write_text(str(os.getpid())+'\n')
 binding=dict(session=SESSION,revision=REV,ticket=TICKET,owner_pid=OWNER_PID,owner_start_tick=START,
              source=SOURCE,job=JOB,observer_sha256=hashlib.sha256(OBS.read_bytes()).hexdigest(),
              snapshot_sha256=hashlib.sha256(SNAP.read_bytes()).hexdigest(),
              watcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              interval_seconds=3,deadline=time.time()+3600,scope='Completed-row-bound strict snapshots; PREP execution proof remains canonical. Root may already capture S.')
 (OUT/'manifest.json').write_text(json.dumps(binding,indent=2)+'\n')
 events=(OUT/'events.jsonl').open('x',buffering=1);lock=threading.Lock();stop=threading.Event();threads=[];children=[];attempted=set();last='';previous=None
 def event(kind,**kw):
  with lock:events.write(json.dumps(dict(kind=kind,at=time.time(),**kw))+'\n')
 def terminate(*args):stop.set()
 signal.signal(signal.SIGTERM,terminate);signal.signal(signal.SIGINT,terminate)
 def capture(head):
  arm=head['arm'];suffix='completed-'+head['id'][:12]
  dest=Path('/tmp/glm53-ep-prep-onepass7-live-'+arm+'-'+suffix)
  remote=JOB+'/live-'+arm+'-'+suffix
  if dest.exists():
   event('snapshot_already_requested',arm=arm,path=str(dest),remote_directory=remote);return
  if hashlib.sha256(SNAP.read_bytes()).hexdigest()!=binding['snapshot_sha256']:
   event('snapshot_rejected',arm=arm,reason='bound helper changed');return
  argv=[sys.executable,str(SNAP),'--arm',arm,'--revision',REV,'--session',SESSION,
        '--capture-phase','ready','--suffix',suffix,'--head-id',head['id'],
        '--head-started-at',head['started_at'],'--arm-event-key',head['arm_event_key']]
  path=OUT/(arm+'.snapshot.private.log')
  event('snapshot_requested',arm=arm,head=head,path=str(dest),remote_directory=remote)
  with path.open('xb') as log:
   p=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);children.append(p)
   try:rc=p.wait(timeout=240)
   except subprocess.TimeoutExpired:
    os.killpg(p.pid,signal.SIGTERM)
    try:rc=p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);rc=p.wait()
  event('snapshot_finished',arm=arm,returncode=rc,path=str(dest),remote_directory=remote,log_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 event('watcher_start',pid=os.getpid(),binding=binding)
 try:
  while not stop.is_set() and time.time()<binding['deadline']:
   started=time.monotonic()
   variables=dict(session=SESSION,ticket=TICKET,revision=REV,source=SOURCE,owner_pid=OWNER_PID,owner_start_tick=START,job=JOB,last_digest=last)
   code='import base64\n'+'\n'.join(k+'='+repr(v) for k,v in variables.items())+'\n'+common+REMOTE
   try:
    result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=5','choiceoh@srv2','python3 -B -'],input=code.encode(),stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
    if result.returncode:
     error=OUT/('read-error-'+str(time.time_ns())+'.private.log');error.write_bytes(result.stderr)
     event('read_error',returncode=result.returncode,path=str(error));stop.wait(3);continue
    value=json.loads(result.stdout);status=value['status']
    compact={k:status.get(k) for k in ('own','go','terminal','phase','state','payload_returncode','returncode')}
    if compact!=previous:event('status',status=compact);previous=compact
    records=value.get('records')
    if records:
     raw=base64.b64decode(records['data'],validate=True)
     if len(raw)!=records['bytes'] or hashlib.sha256(raw).hexdigest()!=records['sha256']:raise RuntimeError('row transport differs')
     recordpath=OUT/('records-'+records['sha256']+'.jsonl');recordpath.write_bytes(raw);last=records['sha256']
     event('completed_prefix',path=str(recordpath),sha256=last,last_record=records['last'],capture_declined=value.get('capture_declined'))
     head=value.get('head')
     if head and head['arm'] not in attempted:
      attempted.add(head['arm']);t=threading.Thread(target=capture,args=(head,));t.start();threads.append(t)
    if status['terminal'] or not status['own']:
     event('terminal_or_release',status=compact);break
   except Exception as exc:event('iteration_error',error=type(exc).__name__+': '+str(exc))
   stop.wait(max(0,3-(time.monotonic()-started)))
 finally:
  # Existing immutable captures may finish their bounded read after terminal.
  for t in threads:t.join(timeout=255)
  event('watcher_finished',attempted_arms=sorted(attempted),deadline_reached=time.time()>=binding['deadline'])
  events.close()
 print(json.dumps({'finished':True,'path':str(OUT),'attempted':sorted(attempted)}),flush=True)
if __name__=='__main__':main()
